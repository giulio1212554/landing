/* ============================================
   ISCHIA DIGITAL — Main JS
   Intro + Tracking + Forms + Demo launcher
   ============================================ */

(function () {
  'use strict';

  const KEYS = {
    visits: 'id_visits',
    pageViews: 'id_pageviews',
    demos: 'id_demos',
    appointments: 'id_appointments',
    messages: 'id_messages',
    adminAuth: 'id_admin_auth',
    introSeen: 'id_intro_seen'
  };

  function get(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch {
      return fallback;
    }
  }

  function set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function track(event, data) {
    data = data || {};
    const now = new Date().toISOString();
    if (event === 'pageview') {
      const views = get(KEYS.pageViews, []);
      views.push({ path: location.pathname + location.search, ts: now });
      set(KEYS.pageViews, views);
      set(KEYS.visits, get(KEYS.visits, 0) + 1);
    }
    if (event === 'demo') {
      const demos = get(KEYS.demos, []);
      demos.push({ name: data.name, ts: now, url: data.url || '' });
      set(KEYS.demos, demos);
    }
    if (event === 'appointment') {
      const list = get(KEYS.appointments, []);
      list.push(Object.assign({}, data, { ts: now, id: Date.now().toString(36) }));
      set(KEYS.appointments, list);
    }
    if (event === 'message') {
      const list = get(KEYS.messages, []);
      list.push(Object.assign({}, data, { ts: now, id: Date.now().toString(36) }));
      set(KEYS.messages, list);
    }
  }

  const INTRO_MESSAGES = [
    'Non sei arrivato qui per caso.\nSei stato selezionato.',
    'Questo non è un portfolio pubblico.\nÈ un accesso riservato.',
    'Hai superato il filtro.\nOra parliamo di lavoro serio.',
    'Pochi progetti.\nMassima attenzione.',
    'Benvenuto.\nSei sulla lista giusta.'
  ];

  const DEMO_URLS = {
    'Ischia Rent': 'demos-live/wheels/index.html',
    'Project Lab': 'demos-live/project-lab/index.html',
    'Nonna Sofia': 'demos-live/nonna-sofia/index.html'
  };

  function runIntro() {
    var overlay = document.getElementById('intro-overlay');
    if (!overlay) return;
    if (sessionStorage.getItem(KEYS.introSeen) === '1') {
      overlay.classList.add('hidden');
      document.body.style.overflow = '';
      return;
    }
    document.body.style.overflow = 'hidden';
    var stageMsg = document.getElementById('intro-stage-msg');
    var stageWelcome = document.getElementById('intro-stage-welcome');
    var msgEl = document.getElementById('intro-random-msg');
    var msg = INTRO_MESSAGES[Math.floor(Math.random() * INTRO_MESSAGES.length)];
    if (msgEl) {
      msgEl.textContent = msg;
      msgEl.style.color = '#e8ffe8';
      msgEl.style.webkitTextFillColor = '#e8ffe8';
    }
    // Mostra subito il messaggio (niente delay lungo)
    setTimeout(function () {
      if (stageMsg) stageMsg.classList.add('active');
    }, 100);
    // Poi passa al benvenuto
    setTimeout(function () {
      if (stageMsg) {
        stageMsg.classList.remove('active');
        stageMsg.classList.add('leave');
      }
      setTimeout(function () {
        if (stageMsg) stageMsg.style.display = 'none';
        if (stageWelcome) stageWelcome.classList.add('active');
      }, 600);
    }, 2600);
  }

  window.finishIntro = function () {
    if (typeof chiudiIntro === 'function') { chiudiIntro(); return; }
    var overlay = document.getElementById('intro-overlay');
    if (!overlay) return;
    overlay.classList.add('hidden');
    document.body.style.overflow = '';
    sessionStorage.setItem(KEYS.introSeen, '1');
  };

  window.skipIntro = function () {
    finishIntro();
  };

  window.openDemo = function (name) {
    var url = DEMO_URLS[name];
    track('demo', { name: name, url: url || '' });
    if (!url) {
      alert('Demo non configurata.');
      return;
    }
    window.open(url, '_blank');
    // demo statica: si apre subito, zero install
  };

  function showToast(text) {
    var t = document.getElementById('id-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'id-toast';
      t.style.cssText =
        'position:fixed;bottom:28px;left:50%;transform:translateX(-50%);' +
        'background:#0d120d;border:1px solid rgba(0,255,65,0.25);color:#c8f0c8;padding:14px 22px;' +
        'border-radius:12px;font-size:0.85rem;z-index:10000;max-width:92%;' +
        'white-space:pre-line;text-align:center;box-shadow:0 12px 40px rgba(0,0,0,0.5);' +
        'opacity:0;transition:opacity 0.3s;line-height:1.5';
      document.body.appendChild(t);
    }
    t.textContent = text;
    t.style.opacity = '1';
    clearTimeout(t._tid);
    t._tid = setTimeout(function () {
      t.style.opacity = '0';
    }, 6000);
  }

  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) {
            e.target.classList.add('visible');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    els.forEach(function (el) {
      io.observe(el);
    });
  }

  function initHeader() {
    var header = document.querySelector('.header');
    if (!header) return;
    window.addEventListener(
      'scroll',
      function () {
        header.classList.toggle('scrolled', window.scrollY > 40);
      },
      { passive: true }
    );
  }

  function openModal(id) {
    var m = document.getElementById(id);
    if (m) m.classList.add('active');
  }
  function closeModal(id) {
    var m = document.getElementById(id);
    if (m) m.classList.remove('active');
  }
  window.openAppointment = function () {
    openModal('modal-appointment');
  };
  window.openMessage = function () {
    openModal('modal-message');
  };
  window.closeModal = closeModal;

  function initForms() {
    var apptForm = document.getElementById('form-appointment');
    if (apptForm) {
      apptForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var data = Object.fromEntries(new FormData(apptForm).entries());
        track('appointment', data);
        apptForm.innerHTML =
          '<div class="form-success"><div class="icon">✓</div><h3>Richiesta inviata</h3>' +
          '<p style="color:var(--text-muted);margin-top:8px">Ti risponderemo per confermare l’appuntamento.</p></div>';
      });
    }
    var msgForm = document.getElementById('form-message');
    if (msgForm) {
      msgForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var data = Object.fromEntries(new FormData(msgForm).entries());
        track('message', data);
        msgForm.innerHTML =
          '<div class="form-success"><div class="icon">✓</div><h3>Messaggio inviato</h3>' +
          '<p style="color:var(--text-muted);margin-top:8px">Grazie. Ti risponderemo a breve.</p></div>';
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    track('pageview');
    // intro gestita inline in index.html
    initReveal();
    initHeader();
    initForms();
    document.querySelectorAll('.modal-overlay').forEach(function (ov) {
      ov.addEventListener('click', function (e) {
        if (e.target === ov) ov.classList.remove('active');
      });
    });
    // no page-enter: causava schermo nero
  });
})();
