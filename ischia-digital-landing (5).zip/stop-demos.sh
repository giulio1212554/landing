#!/bin/bash
for port in 5173 5174 5175; do
  if [ -f /tmp/id-demo-$port.pid ]; then
    kill $(cat /tmp/id-demo-$port.pid) 2>/dev/null || true
    rm -f /tmp/id-demo-$port.pid
    echo "Fermato porta $port"
  fi
done
echo "Demo fermate."
