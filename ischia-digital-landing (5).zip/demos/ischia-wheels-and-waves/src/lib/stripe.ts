/**
 * Stripe — chiama /api/stripe/* sul server (secret non in browser).
 */
import { env, hasStripe } from "./env";

export async function loadStripeJs() {
  if (!hasStripe()) return null;
  try {
    const { loadStripe } = await import("@stripe/stripe-js");
    return loadStripe(env.stripePublishableKey);
  } catch {
    console.warn("[stripe] npm i @stripe/stripe-js");
    return null;
  }
}

export async function createPaymentIntent(params: {
  amountCents: number;
  currency?: string;
  metadata?: Record<string, string>;
}) {
  try {
    const res = await fetch("/api/stripe/payment-intent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (e: any) {
    return {
      ok: true,
      mock: true,
      id: "pi_offline_" + Date.now(),
      clientSecret: "mock",
      reason: e?.message || "fetch failed",
    };
  }
}

export async function createDepositIntent(params: {
  amountCents: number;
  currency?: string;
  metadata?: Record<string, string>;
}) {
  try {
    const res = await fetch("/api/stripe/deposit-intent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (e: any) {
    return {
      ok: true,
      mock: true,
      id: "pi_dep_offline_" + Date.now(),
      clientSecret: "mock",
      reason: e?.message || "fetch failed",
    };
  }
}

export async function captureDeposit(_id: string) {
  return { mock: true, ok: true };
}

export async function cancelDeposit(_id: string) {
  return { mock: true, ok: true };
}
