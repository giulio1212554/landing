/**
 * Store centralizzato per Ischia Rent.
 * Tutto il contenuto del sito (veicoli, pacchetti, sconti, extra, testi)
 * è modificabile dall'admin e persistito in localStorage.
 * Approccio: single source of truth + React Context.
 */

import vespa from "@/assets/vespa.png";
import fiat from "@/assets/fiat500.png";
import gommone from "@/assets/gommone.png";

export type Cat = "scooter" | "auto" | "gommoni";
export type Lang = "it" | "en" | "de";

export interface Vehicle {
  id: string;
  cat: Cat;
  name: string;
  img: string;
  badge?: string;
  /** Prezzo listino attuale (basePrice * seasonMultiplier) */
  price: number;
  /** Prezzo base di listino (prima dei moltiplicatori stagione) */
  basePrice: number;
  /** 1 = normale, 1.2 = alta, 0.8 = bassa — non cumulativo */
  seasonMultiplier: number;
  desc?: string;
  specs: string[];
  available: boolean;
  /** @deprecated non usato per KPI; tenuto per compatibilità */
  activeRentals: number;
  deposit?: number;
  quantity?: number;
}

export interface Extra {
  id: string;
  name: string;
  price: number;
  desc?: string;
  active: boolean;
}

export interface Package {
  id: string;
  name: string;
  vehicleIds: string[];
  discountPct: number;
  daysMin: number;
  active: boolean;
  desc?: string;
}

export interface SiteContent {
  heroTitle: string;
  heroSubtitle: string;
  /** Link wa.me completo — obbligatorio in produzione (configurabile da admin) */
  whatsapp: string;
  mapsUrl: string;
  valueProps: { title: string; text: string }[];
  seoKeywords: string[];
  /** Badge hero (es. "Ischia · Estate") — non hardcodare l'anno */
  seasonBadge: string;
}

export interface Booking {
  id: string;
  vehicleId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  pickup: string;
  return: string;
  pickupLocation: string;
  extras: string[];
  total: number;
  deposit: number;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  createdAt: string;
  lang: Lang;
  documentsUploaded?: boolean;
  contractSigned?: boolean;
  privacyAccepted?: boolean;
  checkIn?: CheckInRecord;
  checkOut?: CheckInRecord;
}

export interface CheckInRecord {
  photos: string[];
  notes: string;
  items: boolean[];
  at: string;
}

/** Recensione (unica fonte di verità; ex ReviewItem) */
export interface Review {
  id: string;
  author: string;
  rating: number;
  text: string;
  source: "google" | "tripadvisor";
  date: string;
}

/** @deprecated alias — usa Review */
export type ReviewItem = Review;

export interface AppState {
  vehicles: Vehicle[];
  extras: Extra[];
  packages: Package[];
  content: SiteContent;
  bookings: Booking[];
  reviews: Review[];
  lang: Lang;
  /** @deprecated plaintext rimosso — migrato a hash */
  adminPin?: string;
  /** SHA-256 hex (salt:pin) */
  adminPinHash: string;
  adminPinSalt: string;
  /** true finché l'admin non imposta un PIN personalizzato */
  pinMustChange: boolean;
}

export const DEFAULT_STATE: AppState = {
  adminPinHash: "",
  adminPinSalt: "",
  pinMustChange: true,
  lang: "it",
  vehicles: [
    {
      id: "1",
      cat: "scooter",
      name: "Vespa Primavera 125",
      img: vespa,
      badge: "Più Richiesto",
      price: 35,
      basePrice: 35,
      seasonMultiplier: 1,
      specs: ["125cc", "2 Caschi Inclusi", "Km Illimitati"],
      available: true,
      activeRentals: 4,
      deposit: 200,
      quantity: 4,
    },
    {
      id: "2",
      cat: "scooter",
      name: "Honda SH 150",
      img: "/placeholder.svg",
      badge: "Zero Deposito",
      price: 40,
      basePrice: 40,
      seasonMultiplier: 1,
      specs: ["150cc", "2 Caschi Inclusi", "Km Illimitati"],
      available: true,
      activeRentals: 2,
      deposit: 0,
      quantity: 2,
    },
    {
      id: "3",
      cat: "auto",
      name: "Fiat 500 Cabrio",
      img: fiat,
      badge: "Più Richiesto",
      price: 69,
      basePrice: 69,
      seasonMultiplier: 1,
      specs: ["4 Posti", "Benzina", "Km Illimitati"],
      available: true,
      activeRentals: 3,
      deposit: 500,
      quantity: 2,
    },
    {
      id: "4",
      cat: "gommoni",
      name: "Gommone 5m · 40cv",
      img: gommone,
      badge: "Senza Patente",
      price: 120,
      basePrice: 120,
      seasonMultiplier: 1,
      specs: ["6 Persone", "Ancora + Telo", "40cv"],
      available: true,
      activeRentals: 1,
      deposit: 300,
      quantity: 1,
    },
  ],
  extras: [
    { id: "e1", name: "Casco extra", price: 5, desc: "Casco aggiuntivo", active: true },
    { id: "e2", name: "Carburante incluso", price: 25, desc: "Pieno di benzina", active: true },
    { id: "e3", name: "Consegna/Ritiro Hotel", price: 15, desc: "Porto o hotel", active: true },
    { id: "e4", name: "Skipper gommone", price: 80, desc: "Skipper professionista ½ giornata", active: true },
    { id: "e5", name: "Tour guidato", price: 50, desc: "Tour dell'isola con guida", active: true },
  ],
  packages: [
    {
      id: "p1",
      name: "Vespa + Gommone 3 giorni",
      vehicleIds: ["1", "4"],
      discountPct: 10,
      daysMin: 3,
      active: true,
      desc: "Sconto 10% se prenoti Vespa + Gommone per almeno 3 giorni",
    },
  ],
  content: {
    heroTitle: "Esplora Ischia in Totale Libertà",
    heroSubtitle: "Noleggio Auto, Scooter e Gommoni con Consegna Diretta al Porto di Ischia",
    whatsapp: "",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Molo+Iasolino+Porto+di+Ischia",
    seasonBadge: "Ischia · Noleggio",
    valueProps: [
      { title: "Consegna al Molo", text: "Il tuo mezzo al molo di sbarco in 2 minuti." },
      { title: "Prenotazione online", text: "Prenota online: acconto e cauzione pre-autorizzata in sicurezza." },
      { title: "Kasko & H24", text: "Polizza Kasko e assistenza H24 sull'isola." },
    ],
    seoKeywords: [
      "noleggio gommone Ischia porto",
      "noleggio fiat 500 vintage Ischia",
      "noleggio scooter Ischia",
      "noleggio vespa Ischia",
    ],
  },
  bookings: [],
  reviews: [
    { id: "r1", author: "Cliente (esempio)", rating: 5, text: "[Esempio] Vespa consegnata al molo in pochi minuti.", source: "google", date: "2025-09-12" },
    { id: "r2", author: "Cliente (esempio)", rating: 5, text: "[Esempio] Fiat 500 cabrio ideale per l'isola.", source: "google", date: "2025-08-28" },
    { id: "r3", author: "Cliente (esempio)", rating: 5, text: "[Esempio] Gommone con skipper: giornata ottima.", source: "tripadvisor", date: "2025-07-15" },
  ],
};

/** Chiave attuale storage (include versione schema) */
export const STORAGE_KEY = "ischia-rent-state-v3";
/** Schema corrente del payload persistito */
export const SCHEMA_VERSION = 3;
/** Chiavi legacy da migrare / ripulire */
const LEGACY_STORAGE_KEYS = ["ischia-rent-state-v2", "ischia-rent-state"];

export type PersistedPayload = {
  schemaVersion: number;
  state: AppState;
};

/** Normalizza veicolo legacy (senza basePrice) */
export function normalizeVehicle(v: Partial<Vehicle> & { id: string; name: string; cat: Cat; price: number }): Vehicle {
  const base = typeof v.basePrice === "number" && v.basePrice > 0 ? v.basePrice : Math.max(1, v.price || 1);
  const mult = typeof v.seasonMultiplier === "number" && v.seasonMultiplier > 0 ? v.seasonMultiplier : 1;
  const price = Math.max(1, Math.round(base * mult));
  return {
    id: v.id,
    cat: v.cat,
    name: v.name,
    img: v.img || "",
    badge: v.badge,
    price,
    basePrice: base,
    seasonMultiplier: mult,
    desc: v.desc,
    specs: v.specs || [],
    available: v.available !== false,
    activeRentals: v.activeRentals ?? 0,
    deposit: sanitizeNonNeg(v.deposit),
    quantity: v.quantity,
  };
}

/** Prezzo/cauzione: niente NaN, 0 o negativi per il prezzo; cauzione >= 0 */
export function sanitizePrice(n: unknown): number {
  const x = typeof n === "number" ? n : Number(n);
  if (!Number.isFinite(x) || x <= 0) return 1;
  return Math.round(x);
}

export function sanitizeNonNeg(n: unknown): number {
  const x = typeof n === "number" ? n : Number(n);
  if (!Number.isFinite(x) || x < 0) return 0;
  return Math.round(x);
}

/**
 * Applica moltiplicatore stagione in modo NON cumulativo.
 * pct +20 → mult 1.2; pct -20 → mult 0.8; pct 0 → mult 1.
 * price = round(basePrice * mult)
 */
export function applySeasonMultiplier(vehicles: Vehicle[], mult: number): Vehicle[] {
  const m = mult > 0 ? mult : 1;
  return vehicles.map((v) => {
    const base = v.basePrice > 0 ? v.basePrice : v.price;
    return {
      ...v,
      basePrice: base,
      seasonMultiplier: m,
      price: Math.max(1, Math.round(base * m)),
    };
  });
}

/** @deprecated usa applySeasonMultiplier — mantenuto per compatibilità */
export const applyPriceChange = (vehicles: Vehicle[], pct: number): Vehicle[] => {
  if (pct > 0) return applySeasonMultiplier(vehicles, 1.2);
  if (pct < 0) return applySeasonMultiplier(vehicles, 0.8);
  return applySeasonMultiplier(vehicles, 1);
};

export function setVehicleBasePrice(v: Vehicle, base: number): Vehicle {
  const basePrice = sanitizePrice(base);
  const mult = v.seasonMultiplier > 0 ? v.seasonMultiplier : 1;
  return { ...v, basePrice, price: Math.max(1, Math.round(basePrice * mult)) };
}

/** Rimuove veicolo: avvisa se ha prenotazioni attive; toglie id dai pacchetti */
export function removeVehicleFromState(
  vehicles: Vehicle[],
  packages: Package[],
  bookings: Booking[],
  vehicleId: string
): { vehicles: Vehicle[]; packages: Package[]; blocked: boolean; activeCount: number } {
  const now = Date.now();
  const activeCount = bookings.filter(
    (b) =>
      b.vehicleId === vehicleId &&
      (b.status === "pending" || b.status === "confirmed") &&
      new Date(b.return).getTime() >= now
  ).length;
  if (activeCount > 0) {
    return { vehicles, packages, blocked: true, activeCount };
  }
  return {
    vehicles: vehicles.filter((v) => v.id !== vehicleId),
    packages: packages.map((p) => ({
      ...p,
      vehicleIds: p.vehicleIds.filter((id) => id !== vehicleId),
    })),
    blocked: false,
    activeCount: 0,
  };
}


/** Migra payload grezzo (qualsiasi versione) → AppState corrente */
export function migrateState(raw: unknown): AppState {
  if (!raw || typeof raw !== "object") return { ...DEFAULT_STATE };

  const obj = raw as Record<string, unknown>;
  // Formato v3: { schemaVersion, state }
  const candidate =
    typeof obj.schemaVersion === "number" && obj.state && typeof obj.state === "object"
      ? (obj.state as Partial<AppState>)
      : (obj as Partial<AppState>);

  const vehiclesRaw = candidate.vehicles?.length ? candidate.vehicles : DEFAULT_STATE.vehicles;
  const vehicles = vehiclesRaw.map((v) => normalizeVehicle(v as any));

  const hasHash = Boolean(candidate.adminPinHash && candidate.adminPinSalt);
  const pinMustChange = hasHash ? Boolean(candidate.pinMustChange) : true;

  return {
    ...DEFAULT_STATE,
    ...candidate,
    vehicles,
    extras: candidate.extras?.length ? candidate.extras : DEFAULT_STATE.extras,
    packages: candidate.packages?.length ? candidate.packages : DEFAULT_STATE.packages,
    content: { ...DEFAULT_STATE.content, ...candidate.content },
    bookings: candidate.bookings ?? [],
    reviews: candidate.reviews?.length ? candidate.reviews : DEFAULT_STATE.reviews,
    adminPinHash: hasHash ? String(candidate.adminPinHash) : "",
    adminPinSalt: hasHash ? String(candidate.adminPinSalt) : "",
    pinMustChange,
    adminPin: undefined,
  };
}

/**
 * Legge localStorage. Sicuro solo lato client (dopo mount).
 * Non chiamare durante il render SSR iniziale.
 */
export function loadState(): AppState {
  if (typeof window === "undefined") return { ...DEFAULT_STATE };
  try {
    let raw = localStorage.getItem(STORAGE_KEY);
    // fallback legacy keys
    if (!raw) {
      for (const k of LEGACY_STORAGE_KEYS) {
        raw = localStorage.getItem(k);
        if (raw) break;
      }
    }
    if (!raw) return { ...DEFAULT_STATE };
    const parsed = JSON.parse(raw);
    return migrateState(parsed);
  } catch {
    return { ...DEFAULT_STATE };
  }
}

/** Persiste con schemaVersion. Rimuove chiavi legacy. */
export function saveState(state: AppState) {
  if (typeof window === "undefined") return;
  const payload: PersistedPayload = {
    schemaVersion: SCHEMA_VERSION,
    state: { ...state, adminPin: undefined },
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  for (const k of LEGACY_STORAGE_KEYS) {
    try {
      localStorage.removeItem(k);
    } catch {
      /* ignore */
    }
  }
}

export function clearPersistedState() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
  for (const k of LEGACY_STORAGE_KEYS) {
    try {
      localStorage.removeItem(k);
    } catch {
      /* ignore */
    }
  }
}

/** KPI da prenotazioni reali (stato + date), non da activeRentals */
export function dashboardStats(vehicles: Vehicle[], bookings: Booking[]) {
  const now = Date.now();
  const live = bookings.filter((b) => {
    if (b.status === "cancelled" || b.status === "completed") return false;
    if (b.status !== "pending" && b.status !== "confirmed") return false;
    const start = new Date(b.pickup).getTime();
    const end = new Date(b.return).getTime();
    // attivo se in corso o inizia entro 24h, oppure pending/confirmed futuro
    return end >= now;
  });
  const active = live.length;
  // incasso stimato: somma total delle prenotazioni non cancellate (giorno / periodo)
  const revenue = live.reduce((s, b) => s + (Number(b.total) || 0), 0);
  const pending = bookings.filter((b) => b.status === "pending").length;
  const confirmed = bookings.filter((b) => b.status === "confirmed").length;
  return {
    active,
    revenue: Math.round(revenue),
    available: vehicles.filter((v) => v.available).length,
    total: vehicles.length,
    pending,
    confirmed,
    totalBookings: bookings.length,
  };
}

/** @deprecated non confrontare PIN in chiaro — usa auth-pin.ts */
export const checkPin = (_pin: string, _stored: string) => false;

/** Formatta Date in valore locale per input datetime-local (niente UTC). */
export function toLocalDatetimeValue(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Data/ora locale di default: oggi alle 10:00, o +N giorni. */
export function defaultLocalDatetime(daysFromNow = 0, hour = 10): string {
  const d = new Date();
  d.setDate(d.getDate() + daysFromNow);
  d.setHours(hour, 0, 0, 0);
  return toLocalDatetimeValue(d);
}

export const HOTEL_LOCATION = "hotel";
export const HOTEL_FEE = 15;
export const HOTEL_EXTRA_ID = "e3";
export const MIN_RENTAL_DAYS = 1;

export type DateValidationError =
  | "pickup_past"
  | "return_before_pickup"
  | "too_short"
  | null;

export function validateRentalDates(pickup: string, returnDate: string): DateValidationError {
  if (!pickup || !returnDate) return "too_short";
  const start = new Date(pickup).getTime();
  const end = new Date(returnDate).getTime();
  const now = Date.now() - 60_000; // 1 min tolleranza
  if (Number.isNaN(start) || Number.isNaN(end)) return "too_short";
  if (start < now) return "pickup_past";
  if (end <= start) return "return_before_pickup";
  const days = Math.ceil((end - start) / 864e5);
  if (days < MIN_RENTAL_DAYS) return "too_short";
  return null;
}

export function rentalDays(pickup: string, returnDate: string): number {
  const a = new Date(pickup).getTime();
  const b = new Date(returnDate).getTime();
  if (Number.isNaN(a) || Number.isNaN(b) || b <= a) return 0;
  return Math.max(1, Math.ceil((b - a) / 864e5));
}

/** true se due intervalli [start,end) si sovrappongono */
export function rangesOverlap(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  const as = new Date(aStart).getTime();
  const ae = new Date(aEnd).getTime();
  const bs = new Date(bStart).getTime();
  const be = new Date(bEnd).getTime();
  return as < be && bs < ae;
}

/** Quante unità già impegnate (pending/confirmed) che si sovrappongono */
export function countOverlappingBookings(
  bookings: Booking[],
  vehicleId: string,
  pickup: string,
  returnDate: string
): number {
  return bookings.filter(
    (b) =>
      b.vehicleId === vehicleId &&
      (b.status === "pending" || b.status === "confirmed") &&
      rangesOverlap(pickup, returnDate, b.pickup, b.return)
  ).length;
}

export function isVehicleAvailableForDates(
  vehicle: Vehicle,
  bookings: Booking[],
  pickup: string,
  returnDate: string
): boolean {
  if (!vehicle.available) return false;
  const qty = vehicle.quantity ?? 1;
  return countOverlappingBookings(bookings, vehicle.id, pickup, returnDate) < qty;
}

/**
 * Sconto pacchetto solo se la prenotazione soddisfa TUTTI i requisiti:
 * - giorni >= daysMin
 * - se vehicleIds ha 1 solo id: deve essere quel mezzo
 * - se vehicleIds ha più id: serve una prenotazione multi-mezzo (non supportata in un solo booking)
 *   → in quel caso non applicare sconto (solo cross-sell in UI)
 */
export function matchPackageDiscount(
  pkg: Package,
  vehicleId: string,
  days: number
): { applies: boolean; reason: "ok" | "days" | "need_multi" | "wrong_vehicle" } {
  if (!pkg.active) return { applies: false, reason: "wrong_vehicle" };
  if (days < pkg.daysMin) return { applies: false, reason: "days" };
  if (pkg.vehicleIds.length === 0) return { applies: false, reason: "wrong_vehicle" };
  if (pkg.vehicleIds.length === 1) {
    if (pkg.vehicleIds[0] === vehicleId) return { applies: true, reason: "ok" };
    return { applies: false, reason: "wrong_vehicle" };
  }
  // Multi-mezzo: un solo vehicleId non basta
  if (pkg.vehicleIds.includes(vehicleId)) return { applies: false, reason: "need_multi" };
  return { applies: false, reason: "wrong_vehicle" };
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function isWhatsappConfigured(url: string): boolean {
  return /^https?:\/\/wa\.me\/\d{8,}/i.test((url || "").trim());
}

export function isValidPhone(phone: string): boolean {
  const digits = phone.replace(/\D/g, "");
  return digits.length >= 8;
}

/** Traduzioni base IT / EN / DE */
export const i18n: Record<Lang, Record<string, string>> = {
  it: {
    fleet: "Flotta",
    book: "Prenota",
    admin: "Admin",
    home: "Home",
    seeAvailable: "Vedi Mezzi Disponibili",
    from: "da",
    day: "giorno",
    bookNow: "Prenota ora",
    extras: "Extra",
    packages: "Pacchetti",
    confirm: "Conferma prenotazione",
    deposit: "Cauzione",
    total: "Totale",
    available: "Disponibile",
    notAvailable: "Non Disponibile",
    notFoundTitle: "Pagina non trovata",
    notFoundBody: "La pagina che cerchi non esiste o è stata spostata.",
    goHome: "Torna alla home",
    errorTitle: "Questa pagina non si è caricata",
    errorBody: "Qualcosa è andato storto. Puoi riprovare o tornare alla home.",
    tryAgain: "Riprova",
    privacyAccept: "Accetto privacy e termini di noleggio",
    cancelPolicy: "Cancellazione gratuita fino a 48h prima del ritiro; dopo trattenuta l'acconto.",
    reviewsExample: "Recensioni di esempio — sostituire con feed Google",
    whatsappMissing: "WhatsApp non configurato — impostalo da Admin → Contenuti",
    checkIn: "Check-in",
    checkOut: "Check-out",
  },
  en: {
    fleet: "Fleet",
    book: "Book",
    admin: "Admin",
    home: "Home",
    seeAvailable: "See Available Vehicles",
    from: "from",
    day: "day",
    bookNow: "Book now",
    extras: "Extras",
    packages: "Packages",
    confirm: "Confirm booking",
    deposit: "Deposit",
    total: "Total",
    available: "Available",
    notAvailable: "Not Available",
    notFoundTitle: "Page not found",
    notFoundBody: "The page you're looking for doesn't exist or has been moved.",
    goHome: "Go home",
    errorTitle: "This page didn't load",
    errorBody: "Something went wrong. You can try again or go back home.",
    tryAgain: "Try again",
    privacyAccept: "I accept the privacy policy and rental terms",
    cancelPolicy: "Free cancellation up to 48h before pickup; deposit retained after that.",
    reviewsExample: "Sample reviews — replace with live Google feed",
    whatsappMissing: "WhatsApp not configured — set it in Admin → Content",
    checkIn: "Check-in",
    checkOut: "Check-out",
  },
  de: {
    fleet: "Flotte",
    book: "Buchen",
    admin: "Admin",
    home: "Start",
    seeAvailable: "Verfügbare Fahrzeuge",
    from: "ab",
    day: "Tag",
    bookNow: "Jetzt buchen",
    extras: "Extras",
    packages: "Pakete",
    confirm: "Buchung bestätigen",
    deposit: "Kaution",
    total: "Gesamt",
    available: "Verfügbar",
    notAvailable: "Nicht verfügbar",
    notFoundTitle: "Seite nicht gefunden",
    notFoundBody: "Die gesuchte Seite existiert nicht oder wurde verschoben.",
    goHome: "Zur Startseite",
    errorTitle: "Seite konnte nicht geladen werden",
    errorBody: "Etwas ist schiefgelaufen. Bitte erneut versuchen oder zur Startseite.",
    tryAgain: "Erneut versuchen",
    privacyAccept: "Ich akzeptiere Datenschutz und Mietbedingungen",
    cancelPolicy: "Kostenlose Stornierung bis 48 Std. vor Abholung; danach Anzahlung einbehalten.",
    reviewsExample: "Beispielbewertungen — durch Google-Feed ersetzen",
    whatsappMissing: "WhatsApp nicht konfiguriert — unter Admin → Inhalte setzen",
    checkIn: "Check-in",
    checkOut: "Check-out",
  },
};
