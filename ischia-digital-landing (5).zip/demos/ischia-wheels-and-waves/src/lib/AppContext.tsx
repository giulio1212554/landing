import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
  type ReactNode,
} from "react";
import {
  DEFAULT_STATE,
  loadState,
  saveState,
  clearPersistedState,
  type AppState,
  type Vehicle,
  type Extra,
  type Package,
  type SiteContent,
  type Booking,
  type Lang,
  type Review,
} from "./store";
import { createPinRecord } from "./auth-pin";

interface AppContextValue {
  state: AppState;
  /** true dopo aver letto localStorage (client only) */
  hydrated: boolean;
  setVehicles: (fn: (v: Vehicle[]) => Vehicle[]) => void;
  setExtras: (fn: (e: Extra[]) => Extra[]) => void;
  setPackages: (fn: (p: Package[]) => Package[]) => void;
  setContent: (fn: (c: SiteContent) => SiteContent) => void;
  setBookings: (fn: (b: Booking[]) => Booking[]) => void;
  setReviews: (fn: (r: Review[]) => Review[]) => void;
  setLang: (lang: Lang) => void;
  setAdminPinSecure: (pin: string) => Promise<void>;
  resetToDefault: () => void;
  isAdmin: boolean;
  setIsAdmin: (v: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  // SSR-safe: stesso valore server/client al primo paint
  const [state, setState] = useState<AppState>(() => ({ ...DEFAULT_STATE }));
  const [hydrated, setHydrated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const hydratedRef = useRef(false);

  // Carica localStorage solo dopo il mount (evita hydration mismatch)
  useEffect(() => {
    const loaded = loadState();
    setState(loaded);
    hydratedRef.current = true;
    setHydrated(true);
  }, []);

  // Salva solo dopo idratazione (non sovrascrivere storage col DEFAULT iniziale)
  useEffect(() => {
    if (!hydratedRef.current) return;
    saveState(state);
  }, [state, hydrated]);

  const setVehicles = useCallback((fn: (v: Vehicle[]) => Vehicle[]) => {
    setState((s) => ({ ...s, vehicles: fn(s.vehicles) }));
  }, []);

  const setExtras = useCallback((fn: (e: Extra[]) => Extra[]) => {
    setState((s) => ({ ...s, extras: fn(s.extras) }));
  }, []);

  const setPackages = useCallback((fn: (p: Package[]) => Package[]) => {
    setState((s) => ({ ...s, packages: fn(s.packages) }));
  }, []);

  const setContent = useCallback((fn: (c: SiteContent) => SiteContent) => {
    setState((s) => ({ ...s, content: fn(s.content) }));
  }, []);

  const setBookings = useCallback((fn: (b: Booking[]) => Booking[]) => {
    setState((s) => ({ ...s, bookings: fn(s.bookings) }));
  }, []);

  const setReviews = useCallback((fn: (r: Review[]) => Review[]) => {
    setState((s) => ({ ...s, reviews: fn(s.reviews) }));
  }, []);

  const setLang = useCallback((lang: Lang) => {
    setState((s) => ({ ...s, lang }));
  }, []);

  const setAdminPinSecure = useCallback(async (pin: string) => {
    const { hash, salt } = await createPinRecord(pin);
    setState((s) => ({
      ...s,
      adminPinHash: hash,
      adminPinSalt: salt,
      pinMustChange: false,
      adminPin: undefined,
    }));
  }, []);

  const resetToDefault = useCallback(() => {
    clearPersistedState();
    setState({ ...DEFAULT_STATE });
  }, []);

  return (
    <AppContext.Provider
      value={{
        state,
        hydrated,
        setVehicles,
        setExtras,
        setPackages,
        setContent,
        setBookings,
        setReviews,
        setLang,
        setAdminPinSecure,
        resetToDefault,
        isAdmin,
        setIsAdmin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
