/**
 * Handler HTTP per /api/* (Stripe, email).
 * Chiavi secret lette solo da process.env (server).
 */

function env(key: string, fallback = ""): string {
  return (typeof process !== "undefined" && process.env?.[key]) || fallback;
}

async function readJson(req: Request): Promise<any> {
  try {
    return await req.json();
  } catch {
    return {};
  }
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json" },
  });
}

export async function handleApi(request: Request): Promise<Response | null> {
  const url = new URL(request.url);
  if (!url.pathname.startsWith("/api/")) return null;

  // CORS preflight
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  if (url.pathname === "/api/health" && request.method === "GET") {
    return json({
      ok: true,
      stripe: Boolean(env("STRIPE_SECRET_KEY")?.startsWith("sk_")),
      stripePub: Boolean(env("VITE_STRIPE_PUBLISHABLE_KEY")?.startsWith("pk_")),
      supabase: Boolean(env("VITE_SUPABASE_URL")),
      resend: Boolean(env("RESEND_API_KEY")?.startsWith("re_")),
    });
  }

  if (url.pathname === "/api/stripe/payment-intent" && request.method === "POST") {
    const body = await readJson(request);
    const secret = env("STRIPE_SECRET_KEY");
    if (!secret.startsWith("sk_")) {
      return json({
        ok: true,
        mock: true,
        clientSecret: "mock_" + Date.now(),
        id: "pi_mock_" + Date.now(),
        reason: "STRIPE_SECRET_KEY mancante nel .env del server",
      });
    }
    try {
      const Stripe = (await import("stripe")).default;
      const stripe = new Stripe(secret);
      const amount = Math.max(50, Math.round(Number(body.amountCents) || 0));
      const intent = await stripe.paymentIntents.create({
        amount,
        currency: body.currency || "eur",
        automatic_payment_methods: { enabled: true },
        metadata: body.metadata || {},
      });
      return json({ ok: true, mock: false, clientSecret: intent.client_secret, id: intent.id });
    } catch (e: any) {
      console.error("[api/stripe/payment-intent]", e);
      return json({ ok: false, error: e?.message || "stripe error" }, 500);
    }
  }

  if (url.pathname === "/api/stripe/deposit-intent" && request.method === "POST") {
    const body = await readJson(request);
    const secret = env("STRIPE_SECRET_KEY");
    if (!secret.startsWith("sk_")) {
      return json({
        ok: true,
        mock: true,
        clientSecret: "mock_dep_" + Date.now(),
        id: "pi_dep_mock_" + Date.now(),
        reason: "STRIPE_SECRET_KEY mancante",
      });
    }
    try {
      const Stripe = (await import("stripe")).default;
      const stripe = new Stripe(secret);
      const amount = Math.max(50, Math.round(Number(body.amountCents) || 0));
      const intent = await stripe.paymentIntents.create({
        amount,
        currency: body.currency || "eur",
        capture_method: "manual",
        automatic_payment_methods: { enabled: true },
        metadata: { ...(body.metadata || {}), type: "deposit" },
      });
      return json({ ok: true, mock: false, clientSecret: intent.client_secret, id: intent.id });
    } catch (e: any) {
      console.error("[api/stripe/deposit-intent]", e);
      return json({ ok: false, error: e?.message || "stripe error" }, 500);
    }
  }

  if (url.pathname === "/api/email/confirm" && request.method === "POST") {
    const body = await readJson(request);
    const key = env("RESEND_API_KEY");
    const from = env("EMAIL_FROM", "Ischia Rent <onboarding@resend.dev>");
    const subject = "Conferma prenotazione — Ischia Rent";
    const text = `Ciao ${body.name || ""},\n\nprenotazione confermata.\nMezzo: ${body.vehicle}\nRitiro: ${body.pickup}\nTotale: €${body.total}\n\nIschia Rent`;

    if (!key.startsWith("re_")) {
      console.log("[email MOCK]", body);
      return json({ ok: true, mock: true });
    }
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ from, to: [body.to], subject, text }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return json({ ok: false, error: data }, 500);
      return json({ ok: true, mock: false, id: (data as any).id });
    } catch (e: any) {
      return json({ ok: false, error: e?.message }, 500);
    }
  }

  return json({ error: "Not found", path: url.pathname }, 404);
}
