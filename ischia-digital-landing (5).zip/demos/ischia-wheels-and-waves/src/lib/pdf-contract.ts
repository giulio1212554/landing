/**
 * Generazione contratto PDF + firma canvas.
 *
 * Installazione: npm i pdf-lib
 *
 * - Se pdf-lib manca → errore tipizzato (niente blob "finto")
 * - Testo lungo con a capo automatico
 * - downloadPdf revoca l'object URL dopo un timeout
 */

export interface ContractData {
  customerName: string;
  customerEmail: string;
  vehicleName: string;
  pickup: string;
  returnDate: string;
  total: number;
  deposit: number;
  extras: string[];
  signatureDataUrl?: string;
}

export class PdfLibraryMissingError extends Error {
  constructor() {
    super("pdf-lib non installato. Esegui: npm i pdf-lib");
    this.name = "PdfLibraryMissingError";
  }
}

export class PdfGenerationError extends Error {
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = "PdfGenerationError";
    if (cause !== undefined) (this as Error & { cause?: unknown }).cause = cause;
  }
}

function isModuleMissing(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const e = err as { code?: string; message?: string };
  return (
    e.code === "MODULE_NOT_FOUND" ||
    /Cannot find module|Failed to fetch dynamically imported module|pdf-lib/i.test(
      e.message ?? ""
    )
  );
}

/** Spezza il testo in righe che stanno entro maxWidth (unità PDF) */
function wrapText(
  text: string,
  font: { widthOfTextAtSize: (t: string, size: number) => number },
  size: number,
  maxWidth: number
): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const trial = current ? `${current} ${word}` : word;
    if (font.widthOfTextAtSize(trial, size) <= maxWidth) {
      current = trial;
    } else {
      if (current) lines.push(current);
      // parola singola troppo lunga: taglia
      if (font.widthOfTextAtSize(word, size) > maxWidth) {
        let chunk = "";
        for (const ch of word) {
          const t2 = chunk + ch;
          if (font.widthOfTextAtSize(t2, size) <= maxWidth) chunk = t2;
          else {
            if (chunk) lines.push(chunk);
            chunk = ch;
          }
        }
        current = chunk;
      } else {
        current = word;
      }
    }
  }
  if (current) lines.push(current);
  return lines.length ? lines : [""];
}

/** Genera un PDF del contratto di noleggio. Lancia se pdf-lib manca o fallisce. */
export async function generateContractPdf(data: ContractData): Promise<Blob> {
  let PDFDocument: typeof import("pdf-lib").PDFDocument;
  let StandardFonts: typeof import("pdf-lib").StandardFonts;
  let rgb: typeof import("pdf-lib").rgb;

  try {
    const mod = await import("pdf-lib");
    PDFDocument = mod.PDFDocument;
    StandardFonts = mod.StandardFonts;
    rgb = mod.rgb;
  } catch (err) {
    if (isModuleMissing(err)) throw new PdfLibraryMissingError();
    throw new PdfGenerationError("Impossibile caricare pdf-lib", err);
  }

  try {
    const doc = await PDFDocument.create();
    const page = doc.addPage([595, 842]); // A4
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const bold = await doc.embedFont(StandardFonts.HelveticaBold);
    const margin = 50;
    const maxW = 595 - margin * 2;
    let y = 800;

    const drawLines = (text: string, size = 11, isBold = false) => {
      const f = isBold ? bold : font;
      const lines = wrapText(text, f, size, maxW);
      for (const ln of lines) {
        if (y < 60) {
          // pagina piena: non aggiungiamo altre pagine per semplicità
          return;
        }
        page.drawText(ln, {
          x: margin,
          y,
          size,
          font: f,
          color: rgb(0.1, 0.1, 0.2),
        });
        y -= size + 6;
      }
    };

    drawLines("CONTRATTO DI NOLEGGIO — ISCHIA RENT", 16, true);
    y -= 8;
    drawLines(`Cliente: ${data.customerName}`);
    drawLines(`Email: ${data.customerEmail}`);
    drawLines(`Mezzo: ${data.vehicleName}`);
    drawLines(`Ritiro: ${data.pickup}`);
    drawLines(`Riconsegna: ${data.returnDate}`);
    drawLines(`Totale: €${data.total}`);
    drawLines(`Cauzione: €${data.deposit}`);
    if (data.extras.length) {
      drawLines(`Extra: ${data.extras.join(", ")}`);
    }
    y -= 12;
    drawLines(
      "Il cliente dichiara di aver preso visione del regolamento e di accettare le condizioni di noleggio, inclusa la responsabilità per danni e la gestione della cauzione.",
      10
    );
    y -= 20;
    drawLines("Firma del cliente:", 11, true);

    if (data.signatureDataUrl) {
      try {
        const base64 = data.signatureDataUrl.split(",")[1];
        if (!base64) throw new Error("data URL firma non valida");
        const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
        const png = await doc.embedPng(bytes);
        const sigH = 80;
        const sigW = 200;
        if (y - sigH < 40) y = 40 + sigH;
        page.drawImage(png, { x: margin, y: y - sigH, width: sigW, height: sigH });
        y -= sigH + 10;
      } catch {
        drawLines("(firma non incorporata — errore encoding)", 10);
      }
    }

    const pdfBytes = await doc.save();
    // Copia in ArrayBuffer “classico” per compatibilità Blob
    const copy = new Uint8Array(pdfBytes).buffer;
    return new Blob([copy], { type: "application/pdf" });
  } catch (err) {
    if (err instanceof PdfLibraryMissingError) throw err;
    throw new PdfGenerationError("Errore durante la generazione del PDF", err);
  }
}

/** Scarica il PDF e revoca l'object URL dopo un timeout (default 60s). */
export function downloadPdf(
  blob: Blob,
  filename = "contratto-noleggio.pdf",
  revokeAfterMs = 60_000
) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
  }, revokeAfterMs);
}
