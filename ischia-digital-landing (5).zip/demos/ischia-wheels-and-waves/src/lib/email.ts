/**
 * Email e SMS automatici multilingua.
 *
 * Email: Resend (consigliato) — https://resend.com
 *   npm i resend
 *
 * SMS: Twilio — https://twilio.com
 *   npm i twilio
 *
 * Finché le chiavi non ci sono, le funzioni loggano in console (mock).
 */

import { env, hasEmail, hasSms } from "./env";
import type { Lang } from "./store";

const templates: Record<
  Lang,
  {
    confirmSubject: string;
    confirmBody: (p: { name: string; vehicle: string; pickup: string; total: number }) => string;
    reminderSubject: string;
    reminderBody: (p: { name: string; vehicle: string; pickup: string; maps: string }) => string;
  }
> = {
  it: {
    confirmSubject: "Conferma prenotazione — Ischia Rent",
    confirmBody: ({ name, vehicle, pickup, total }) =>
      `Ciao ${name},\n\nla tua prenotazione è confermata.\n\nMezzo: ${vehicle}\nRitiro: ${pickup}\nTotale: €${total}\n\nA presto,\nIschia Rent`,
    reminderSubject: "Promemoria ritiro — Ischia Rent",
    reminderBody: ({ name, vehicle, pickup, maps }) =>
      `Ciao ${name},\n\ndomani ritiri ${vehicle} alle ${pickup}.\nMappa: ${maps}\n\nIschia Rent`,
  },
  en: {
    confirmSubject: "Booking confirmation — Ischia Rent",
    confirmBody: ({ name, vehicle, pickup, total }) =>
      `Hi ${name},\n\nyour booking is confirmed.\n\nVehicle: ${vehicle}\nPickup: ${pickup}\nTotal: €${total}\n\nSee you soon,\nIschia Rent`,
    reminderSubject: "Pickup reminder — Ischia Rent",
    reminderBody: ({ name, vehicle, pickup, maps }) =>
      `Hi ${name},\n\ntomorrow you pick up ${vehicle} at ${pickup}.\nMap: ${maps}\n\nIschia Rent`,
  },
  de: {
    confirmSubject: "Buchungsbestätigung — Ischia Rent",
    confirmBody: ({ name, vehicle, pickup, total }) =>
      `Hallo ${name},\n\ndeine Buchung ist bestätigt.\n\nFahrzeug: ${vehicle}\nAbholung: ${pickup}\nGesamt: €${total}\n\nBis bald,\nIschia Rent`,
    reminderSubject: "Erinnerung Abholung — Ischia Rent",
    reminderBody: ({ name, vehicle, pickup, maps }) =>
      `Hallo ${name},\n\nmorgen holst du ${vehicle} um ${pickup} ab.\nKarte: ${maps}\n\nIschia Rent`,
  },
};

export async function sendConfirmationEmail(params: {
  to: string;
  lang: Lang;
  name: string;
  vehicle: string;
  pickup: string;
  total: number;
}) {
  const t = templates[params.lang] ?? templates.it;
  const subject = t.confirmSubject;
  const body = t.confirmBody(params);

  if (!hasEmail()) {
    console.log("[email MOCK]", { to: params.to, subject, body });
    return { ok: true, mock: true };
  }

  // Resend example:
  // const { Resend } = await import("resend");
  // const resend = new Resend(env.resendApiKey);
  // await resend.emails.send({
  //   from: env.emailFrom,
  //   to: params.to,
  //   subject,
  //   text: body,
  // });
  console.log("[email] would send via Resend", { to: params.to, subject });
  return { ok: true };
}

export async function sendReminderEmail(params: {
  to: string;
  lang: Lang;
  name: string;
  vehicle: string;
  pickup: string;
  maps: string;
}) {
  const t = templates[params.lang] ?? templates.it;
  if (!hasEmail()) {
    console.log("[email MOCK reminder]", params);
    return { ok: true, mock: true };
  }
  // stesso pattern Resend
  return { ok: true };
}

export async function sendSms(params: { to: string; body: string }) {
  if (!hasSms()) {
    console.log("[sms MOCK]", params);
    return { ok: true, mock: true };
  }
  // const twilio = await import("twilio");
  // const client = twilio.default(env.twilioSid, env.twilioToken);
  // await client.messages.create({
  //   from: env.twilioPhone,
  //   to: params.to,
  //   body: params.body,
  // });
  return { ok: true };
}
