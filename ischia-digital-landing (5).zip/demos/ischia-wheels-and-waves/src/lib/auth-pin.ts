/**
 * Protezione PIN admin (client-side).
 *
 * ⚠️ SOLO FACCIATA: chiunque può ispezionare localStorage e bypassare questo controllo.
 * In produzione usare autenticazione lato server (es. Supabase Auth + RLS sulle tabelle).
 */

const SALT_LEN = 16;
const MAX_ATTEMPTS = 5;
const BASE_LOCK_MS = 30_000; // 30s dopo MAX_ATTEMPTS, poi raddoppia

function bufToHex(buf: ArrayBuffer): string {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function randomSalt(): string {
  const a = new Uint8Array(SALT_LEN);
  crypto.getRandomValues(a);
  return bufToHex(a.buffer);
}

/** SHA-256(salt + ":" + pin) in hex */
export async function hashPin(pin: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${pin}`);
  const dig = await crypto.subtle.digest("SHA-256", data);
  return bufToHex(dig);
}

export async function createPinRecord(pin: string): Promise<{ hash: string; salt: string }> {
  const salt = randomSalt();
  const hash = await hashPin(pin, salt);
  return { hash, salt };
}

export async function verifyPin(
  pin: string,
  storedHash: string,
  salt: string
): Promise<boolean> {
  if (!storedHash || !salt) return false;
  const h = await hashPin(pin, salt);
  // confronto a tempo costante elementare
  if (h.length !== storedHash.length) return false;
  let ok = 0;
  for (let i = 0; i < h.length; i++) ok |= h.charCodeAt(i) ^ storedHash.charCodeAt(i);
  return ok === 0;
}

const ATTEMPTS_KEY = "ischia-admin-pin-attempts";

export type AttemptState = {
  fails: number;
  lockedUntil: number; // epoch ms
};

export function loadAttempts(): AttemptState {
  if (typeof window === "undefined") return { fails: 0, lockedUntil: 0 };
  try {
    const raw = sessionStorage.getItem(ATTEMPTS_KEY);
    if (!raw) return { fails: 0, lockedUntil: 0 };
    return JSON.parse(raw) as AttemptState;
  } catch {
    return { fails: 0, lockedUntil: 0 };
  }
}

function saveAttempts(s: AttemptState) {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(ATTEMPTS_KEY, JSON.stringify(s));
}

export function clearAttempts() {
  if (typeof window === "undefined") return;
  sessionStorage.removeItem(ATTEMPTS_KEY);
}

export function registerFailedAttempt(): AttemptState {
  const cur = loadAttempts();
  const fails = cur.fails + 1;
  let lockedUntil = cur.lockedUntil;
  if (fails >= MAX_ATTEMPTS) {
    const rounds = fails - MAX_ATTEMPTS + 1;
    lockedUntil = Date.now() + BASE_LOCK_MS * Math.pow(2, Math.min(rounds - 1, 4));
  }
  const next = { fails, lockedUntil };
  saveAttempts(next);
  return next;
}

export function isLocked(s: AttemptState = loadAttempts()): boolean {
  return s.lockedUntil > Date.now();
}

export function lockRemainingMs(s: AttemptState = loadAttempts()): number {
  return Math.max(0, s.lockedUntil - Date.now());
}

/** PIN iniziale (solo bootstrap, non persistito in chiaro nello store) */
export const BOOTSTRAP_ADMIN_PIN = "1234";

export const PIN_POLICY = {
  minLength: 4,
  maxAttempts: MAX_ATTEMPTS,
};
