import { describe, it, expect } from "vitest";
import {
  applyPriceChange,
  applySeasonMultiplier,
  dashboardStats,
  type Vehicle,
} from "./fleet";
import {
  type Booking,
  type Package,
  validateRentalDates,
  rangesOverlap,
  isVehicleAvailableForDates,
  matchPackageDiscount,
  sanitizePrice,
  rentalDays,
} from "./store";
import { hashPin, verifyPin, createPinRecord } from "./auth-pin";

const v = (id: string, price: number, quantity = 1): Vehicle => ({
  id,
  cat: "scooter",
  name: "x",
  img: "",
  price,
  basePrice: price,
  seasonMultiplier: 1,
  specs: [],
  available: true,
  activeRentals: 0,
  quantity,
});

const booking = (
  vehicleId: string,
  pickup: string,
  ret: string,
  status: Booking["status"] = "confirmed"
): Booking => ({
  id: crypto.randomUUID?.() ?? String(Math.random()),
  vehicleId,
  customerName: "T",
  customerEmail: "t@t.it",
  customerPhone: "3331234567",
  pickup,
  return: ret,
  pickupLocation: "iasolino",
  extras: [],
  total: 100,
  deposit: 0,
  status,
  createdAt: new Date().toISOString(),
  lang: "it",
});

describe("season prices", () => {
  it("×1.2 raises 35 to 42 without stacking", () => {
    const once = applySeasonMultiplier([v("1", 35)], 1.2);
    expect(once[0]?.price).toBe(42);
    expect(applySeasonMultiplier(once, 1.2)[0]?.price).toBe(42);
  });

  it("applyPriceChange ±20 is reversible via reset", () => {
    const low = applyPriceChange([v("1", 35)], -20);
    expect(low[0]?.price).toBe(28);
    expect(applySeasonMultiplier(low, 1)[0]?.price).toBe(35);
  });

  it("sanitizePrice rejects NaN zero negative", () => {
    expect(sanitizePrice(NaN)).toBe(1);
    expect(sanitizePrice(0)).toBe(1);
    expect(sanitizePrice(-5)).toBe(1);
    expect(sanitizePrice(12.4)).toBe(12);
  });
});

describe("dashboardStats", () => {
  it("requires bookings and ignores activeRentals", () => {
    const vehicles = [v("35", 35), v("69", 69)];
    const bookings = [
      booking(
        "35",
        new Date().toISOString(),
        new Date(Date.now() + 864e5 * 2).toISOString()
      ),
    ];
    const s = dashboardStats(vehicles, bookings);
    expect(s.active).toBe(1);
    expect(s.revenue).toBe(100);
  });
});

describe("dates", () => {
  it("validateRentalDates rejects past and inverted range", () => {
    expect(validateRentalDates("2020-01-01T10:00", "2020-01-03T10:00")).toBe(
      "pickup_past"
    );
    const future = new Date(Date.now() + 864e5 * 2);
    const past = new Date(Date.now() + 864e5);
    const f = (d: Date) => d.toISOString().slice(0, 16);
    expect(validateRentalDates(f(future), f(past))).toBe("return_before_pickup");
  });

  it("rentalDays counts at least 1", () => {
    const a = new Date(Date.now() + 864e5 * 2);
    const b = new Date(Date.now() + 864e5 * 5);
    expect(rentalDays(a.toISOString(), b.toISOString())).toBeGreaterThanOrEqual(3);
  });

  it("rangesOverlap detects intersection", () => {
    expect(
      rangesOverlap("2026-06-01T10:00", "2026-06-05T10:00", "2026-06-04T10:00", "2026-06-08T10:00")
    ).toBe(true);
    expect(
      rangesOverlap("2026-06-01T10:00", "2026-06-03T10:00", "2026-06-03T10:00", "2026-06-05T10:00")
    ).toBe(false);
  });
});

describe("availability overlaps", () => {
  it("blocks double booking same vehicle same range", () => {
    const vehicle = v("1", 40, 1);
    const pick = new Date(Date.now() + 864e5 * 3).toISOString();
    const ret = new Date(Date.now() + 864e5 * 6).toISOString();
    const existing = [booking("1", pick, ret)];
    expect(isVehicleAvailableForDates(vehicle, existing, pick, ret)).toBe(false);
  });

  it("allows second unit when quantity > 1", () => {
    const vehicle = v("1", 40, 2);
    const pick = new Date(Date.now() + 864e5 * 3).toISOString();
    const ret = new Date(Date.now() + 864e5 * 6).toISOString();
    const existing = [booking("1", pick, ret)];
    expect(isVehicleAvailableForDates(vehicle, existing, pick, ret)).toBe(true);
  });
});

describe("package discount", () => {
  const pkg: Package = {
    id: "p",
    name: "Solo Vespa",
    vehicleIds: ["1"],
    discountPct: 10,
    daysMin: 3,
    active: true,
  };

  it("applies when vehicle and days match", () => {
    expect(matchPackageDiscount(pkg, "1", 3).applies).toBe(true);
  });

  it("rejects short stays and multi-vehicle packages", () => {
    expect(matchPackageDiscount(pkg, "1", 2).reason).toBe("days");
    const multi = { ...pkg, vehicleIds: ["1", "4"] };
    expect(matchPackageDiscount(multi, "1", 5).reason).toBe("need_multi");
  });
});

describe("pin hash", () => {
  it("createPinRecord and verifyPin work without plaintext", async () => {
    const { hash, salt } = await createPinRecord("secure-pin-99");
    expect(hash).not.toContain("secure");
    expect(await verifyPin("secure-pin-99", hash, salt)).toBe(true);
    expect(await verifyPin("wrong", hash, salt)).toBe(false);
    expect(await hashPin("secure-pin-99", salt)).toBe(hash);
  });
});
