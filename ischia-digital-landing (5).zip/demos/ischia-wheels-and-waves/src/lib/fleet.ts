/**
 * Compatibility layer – source of truth: store.ts
 * PIN plaintext rimosso: usare auth-pin.ts + stato adminPinHash.
 */
export type { Cat, Vehicle } from "./store";
export {
  applyPriceChange,
  applySeasonMultiplier,
  dashboardStats,
  sanitizePrice,
  sanitizeNonNeg,
} from "./store";
