/**
 * Client helpers per API server (/api/*).
 * Le secret restano sul server (api-handlers.ts).
 */

export async function sendConfirmationEmailFn(args: {
  data: {
    to: string;
    name: string;
    vehicle: string;
    pickup: string;
    total: number;
    lang?: string;
  };
}) {
  try {
    const res = await fetch("/api/email/confirm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(args.data),
    });
    return await res.json();
  } catch (e: any) {
    console.warn("[email]", e);
    return { ok: false, mock: true, error: e?.message };
  }
}

/** Compat: non usare createServerFn qui */
export const createPaymentIntentFn = async ({ data }: { data: any }) => {
  const { createPaymentIntent } = await import("./stripe");
  return createPaymentIntent(data);
};

export const createDepositIntentFn = async ({ data }: { data: any }) => {
  const { createDepositIntent } = await import("./stripe");
  return createDepositIntent(data);
};
