/**
 * Recensioni live da Google Places API.
 *
 * 1. Google Cloud Console → abilita Places API
 * 2. Crea API key e limita per HTTP referrer
 * 3. Trova il Place ID della tua attività (Place ID finder)
 * 4. Inserisci VITE_GOOGLE_PLACES_API_KEY e GOOGLE_PLACE_ID nel .env
 *
 * Finché non configurato, restituisce null (il widget usa i dati dello store).
 */

import { env, hasGooglePlaces } from "./env";

export interface GoogleReview {
  author: string;
  rating: number;
  text: string;
  date: string;
  source: "google";
}

export async function fetchGoogleReviews(): Promise<GoogleReview[] | null> {
  if (!hasGooglePlaces()) return null;

  try {
    // Places API (New) o legacy:
    // const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${env.googlePlaceId}&fields=reviews,rating&key=${env.googlePlacesKey}`;
    // Nota: da browser la key va limitata; meglio proxy lato server.
    // const res = await fetch(`/api/google-reviews`);
    // const json = await res.json();
    // return json.reviews.map(...)
    console.log("[google-places] configurato ma serve proxy server per evitare CORS");
    return null;
  } catch (e) {
    console.error("[google-places]", e);
    return null;
  }
}
