/**
 * Variabili d'ambiente.
 * Browser: solo VITE_*
 * Server: anche STRIPE_SECRET_KEY, RESEND_API_KEY, ecc.
 */

function get(key: string, fallback = ""): string {
  if (typeof import.meta !== "undefined" && (import.meta as any).env) {
    const v = (import.meta as any).env[key];
    if (v != null && v !== "") return String(v);
  }
  if (typeof process !== "undefined" && process.env) {
    const v = process.env[key];
    if (v != null && v !== "") return String(v);
  }
  return fallback;
}

export const env = {
  stripePublishableKey: get("VITE_STRIPE_PUBLISHABLE_KEY"),
  // secret solo server — non usare VITE_STRIPE_SECRET_KEY
  stripeSecretKey: get("STRIPE_SECRET_KEY"),
  stripeWebhookSecret: get("STRIPE_WEBHOOK_SECRET"),

  supabaseUrl: get("VITE_SUPABASE_URL"),
  supabaseAnonKey: get("VITE_SUPABASE_ANON_KEY"),
  supabaseServiceKey: get("SUPABASE_SERVICE_ROLE_KEY"),

  resendApiKey: get("RESEND_API_KEY"),
  emailFrom: get("EMAIL_FROM", "Ischia Rent <noreply@ischiarent.local>"),

  twilioSid: get("TWILIO_ACCOUNT_SID"),
  twilioToken: get("TWILIO_AUTH_TOKEN"),
  twilioPhone: get("TWILIO_PHONE_NUMBER"),

  googlePlacesKey: get("VITE_GOOGLE_PLACES_API_KEY"),
  googlePlaceId: get("GOOGLE_PLACE_ID"),

  appUrl: get("VITE_APP_URL", "http://localhost:3000"),
  isDev: get("NODE_ENV", "development") !== "production",
};

export const hasStripe = () =>
  Boolean(env.stripePublishableKey && env.stripePublishableKey.startsWith("pk_"));

export const hasStripeSecret = () =>
  Boolean(env.stripeSecretKey && env.stripeSecretKey.startsWith("sk_"));

export const hasSupabase = () => Boolean(env.supabaseUrl && env.supabaseAnonKey);

export const hasEmail = () => Boolean(env.resendApiKey && env.resendApiKey.startsWith("re_"));

export const hasSms = () => Boolean(env.twilioSid && env.twilioToken && env.twilioSid.startsWith("AC"));

export const hasGooglePlaces = () => Boolean(env.googlePlacesKey && env.googlePlaceId);

/** Stato integrazioni (solo flag pubblici, niente secret) */
export function integrationStatus() {
  return {
    stripePublishable: hasStripe(),
    supabase: hasSupabase(),
    googlePlaces: hasGooglePlaces(),
    // secret non leggibili dal browser: lo status reale lo dice il server
  };
}
