/**
 * Check-in / Check-out digitale.
 * Da mostrare al ritiro (admin o link dedicato), non subito dopo la prenotazione.
 */
import { useState } from "react";
import { Camera, CheckCircle2, ClipboardList } from "lucide-react";
import type { CheckInRecord } from "@/lib/store";

const CHECKLIST_ITEMS = [
  "Carrozzeria / scafo senza danni evidenti",
  "Pneumatici / gonfiaggio ok",
  "Luci e indicatori funzionanti",
  "Livello carburante registrato",
  "Documenti di bordo presenti",
  "Accessori (caschi, ancora, telo) consegnati",
];

export function CheckInOutPanel({
  mode,
  onComplete,
}: {
  mode: "checkin" | "checkout";
  onComplete?: (data: CheckInRecord) => void;
}) {
  const [items, setItems] = useState<boolean[]>(CHECKLIST_ITEMS.map(() => false));
  const [photos, setPhotos] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [done, setDone] = useState(false);

  const toggle = (i: number) => {
    setItems((prev) => prev.map((v, idx) => (idx === i ? !v : v)));
  };

  const addPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setPhotos((p) => [...p, URL.createObjectURL(f)]);
  };

  const submit = () => {
    const record: CheckInRecord = {
      photos,
      notes,
      items,
      at: new Date().toISOString(),
    };
    setDone(true);
    onComplete?.(record);
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-accent/40 bg-accent/5 p-6 text-center">
        <CheckCircle2 className="mx-auto size-10 text-accent" />
        <p className="mt-3 font-display text-lg font-bold text-primary">
          {mode === "checkin" ? "Check-in completato" : "Check-out completato"}
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Stato del mezzo registrato con {photos.length} foto.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="mb-4 flex items-center gap-2">
        <ClipboardList className="size-5 text-accent" />
        <h3 className="font-display text-lg font-bold text-primary">
          {mode === "checkin" ? "Check-in digitale" : "Check-out digitale"}
        </h3>
      </div>
      <p className="mb-4 text-sm text-muted-foreground">
        Compila la checklist e scatta foto dello stato del mezzo.
      </p>

      <ul className="space-y-2">
        {CHECKLIST_ITEMS.map((label, i) => (
          <li key={label}>
            <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-border px-3 py-2.5 hover:bg-muted/50">
              <input
                type="checkbox"
                checked={items[i]}
                onChange={() => toggle(i)}
                className="size-4 accent-[var(--accent)]"
              />
              <span className="text-sm">{label}</span>
            </label>
          </li>
        ))}
      </ul>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold uppercase text-muted-foreground">
          Foto stato mezzo
        </p>
        <div className="flex flex-wrap gap-2">
          {photos.map((src, i) => (
            <img key={i} src={src} alt="" className="size-20 rounded-xl object-cover" />
          ))}
          <label className="flex size-20 cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-input bg-muted text-muted-foreground hover:border-accent">
            <Camera className="size-5" />
            <span className="mt-1 text-[10px]">Aggiungi</span>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={addPhoto}
            />
          </label>
        </div>
      </div>

      <textarea
        placeholder="Note aggiuntive (opzionale)"
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        rows={2}
        className="mt-4 w-full rounded-xl border border-input bg-muted px-3 py-2 text-sm outline-none focus:border-ring"
      />

      <button
        type="button"
        onClick={submit}
        disabled={!items.every(Boolean)}
        className="mt-4 w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
      >
        Conferma {mode === "checkin" ? "Check-in" : "Check-out"}
      </button>
    </div>
  );
}
