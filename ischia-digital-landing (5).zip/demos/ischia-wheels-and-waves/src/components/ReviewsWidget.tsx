/**
 * Widget recensioni dinamico (Google / TripAdvisor style).
 * Tipo unico: Review da @/lib/store
 */
import { Star } from "lucide-react";
import { motion } from "framer-motion";
import type { Review } from "@/lib/store";

export type { Review };

export function ReviewsWidget({ reviews = [] }: { reviews?: Review[] }) {
  const list = reviews.length > 0 ? reviews : [];
  const avg =
    list.length > 0
      ? (list.reduce((s, r) => s + r.rating, 0) / list.length).toFixed(1)
      : "—";

  if (list.length === 0) return null;

  return (
    <section className="mx-auto mt-14 max-w-6xl px-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-accent">Recensioni</p>
          <h2 className="font-display text-2xl font-extrabold text-primary">
            Cosa dicono i clienti
          </h2>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-sand px-4 py-2">
          <div className="flex">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className="size-4 fill-gold text-gold" />
            ))}
          </div>
          <span className="font-display text-lg font-bold text-primary">{avg}</span>
          <span className="text-xs text-muted-foreground">· esempi (non feed live)</span>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {list.map((r, i) => (
          <motion.article
            key={r.id}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
            className="rounded-2xl border border-border bg-card p-4 shadow-soft"
          >
            <div className="flex items-center justify-between">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star
                    key={j}
                    className={`size-3.5 ${
                      j < r.rating ? "fill-gold text-gold" : "text-muted"
                    }`}
                  />
                ))}
              </div>
              <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">
                {r.source}
              </span>
            </div>
            <p className="mt-3 line-clamp-4 text-sm leading-relaxed text-foreground/90">
              “{r.text}”
            </p>
            <p className="mt-3 text-xs font-semibold text-primary">{r.author}</p>
            <p className="text-[11px] text-muted-foreground">
              {new Date(r.date).toLocaleDateString("it-IT", {
                month: "short",
                year: "numeric",
              })}
            </p>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
