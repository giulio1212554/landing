/**
 * Stripe Payment Element — paga il totale noleggio.
 * Richiede VITE_STRIPE_PUBLISHABLE_KEY + Intent creato via /api/stripe/payment-intent
 */
import { useEffect, useMemo, useState } from "react";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import type { Stripe, StripeElementsOptions } from "@stripe/stripe-js";
import { loadStripeJs } from "@/lib/stripe";
import { Loader2 } from "lucide-react";

type Props = {
  amountEuro: number;
  customerEmail: string;
  customerName: string;
  vehicleId: string;
  metadata?: Record<string, string>;
  onPaid: (info: { paymentIntentId: string; mock: boolean }) => void;
  onError: (msg: string) => void;
  disabled?: boolean;
};

function CheckoutForm({
  onPaid,
  onError,
  disabled,
}: {
  onPaid: (paymentIntentId: string) => void;
  onError: (msg: string) => void;
  disabled?: boolean;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements || disabled) return;
    setBusy(true);
    setMsg(null);
    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: "if_required",
        confirmParams: {
          return_url: `${window.location.origin}/prenota?paid=1`,
        },
      });
      if (error) {
        onError(error.message || "Pagamento rifiutato");
        setMsg(error.message || "Pagamento rifiutato");
        return;
      }
      if (
        paymentIntent &&
        (paymentIntent.status === "succeeded" ||
          paymentIntent.status === "processing" ||
          paymentIntent.status === "requires_capture")
      ) {
        onPaid(paymentIntent.id);
      } else {
        onError("Stato pagamento: " + (paymentIntent?.status || "sconosciuto"));
      }
    } catch (err: any) {
      onError(err?.message || "Errore conferma pagamento");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="rounded-xl border border-border bg-white p-3">
        <PaymentElement
          options={{
            layout: "tabs",
          }}
        />
      </div>
      {msg && (
        <p className="text-sm text-destructive" role="alert">
          {msg}
        </p>
      )}
      <button
        type="submit"
        disabled={!stripe || !elements || busy || disabled}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-bold text-primary-foreground disabled:opacity-50"
      >
        {busy ? (
          <>
            <Loader2 className="size-4 animate-spin" /> Elaborazione…
          </>
        ) : (
          "Paga ora in sicurezza"
        )}
      </button>
      <p className="text-center text-[11px] text-muted-foreground">
        Pagamento gestito da Stripe. Non memorizziamo i dati della carta.
      </p>
    </form>
  );
}

export function StripePaymentForm({
  amountEuro,
  customerEmail,
  customerName,
  vehicleId,
  metadata,
  onPaid,
  onError,
  disabled,
}: Props) {
  const [stripePromise, setStripePromise] = useState<Promise<Stripe | null> | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [intentId, setIntentId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isMock, setIsMock] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setInitError(null);
      const promise = loadStripeJs();
      setStripePromise(promise);
      const stripe = await promise;

      try {
        const res = await fetch("/api/stripe/payment-intent", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amountCents: Math.round(amountEuro * 100),
            currency: "eur",
            metadata: {
              vehicleId,
              customerEmail,
              customerName,
              ...(metadata || {}),
            },
          }),
        });
        const data = await res.json();
        if (cancelled) return;
        if (!data.ok && data.error) {
          setInitError(data.error);
          setLoading(false);
          return;
        }
        if (data.mock) {
          setIsMock(true);
          setIntentId(data.id);
          setClientSecret(null);
          setLoading(false);
          return;
        }
        if (!data.clientSecret) {
          setInitError("Nessun clientSecret da Stripe");
          setLoading(false);
          return;
        }
        if (!stripe) {
          setInitError(
            "Stripe.js non caricato. Verifica VITE_STRIPE_PUBLISHABLE_KEY e npm i @stripe/stripe-js @stripe/react-stripe-js"
          );
          setLoading(false);
          return;
        }
        setClientSecret(data.clientSecret);
        setIntentId(data.id);
      } catch (e: any) {
        if (!cancelled) setInitError(e?.message || "Errore creazione pagamento");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [amountEuro, customerEmail, customerName, vehicleId]);

  const options: StripeElementsOptions | undefined = useMemo(() => {
    if (!clientSecret) return undefined;
    return {
      clientSecret,
      appearance: {
        theme: "stripe",
        variables: {
          colorPrimary: "#0d9488",
          borderRadius: "12px",
        },
      },
    };
  }, [clientSecret]);

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 rounded-xl border border-border bg-muted/40 py-10 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Preparazione pagamento Stripe…
      </div>
    );
  }

  if (initError) {
    return (
      <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm text-destructive">
        {initError}
      </div>
    );
  }

  // Mock: secret assente → conferma senza carta (demo)
  if (isMock) {
    return (
      <div className="space-y-3 rounded-xl border border-amber-500/40 bg-amber-500/5 p-4">
        <p className="text-sm font-semibold text-amber-800 dark:text-amber-200">
          Modalità demo (Stripe secret non attiva sul server)
        </p>
        <p className="text-xs text-muted-foreground">
          Controlla <code>STRIPE_SECRET_KEY</code> nel .env e riavvia. Puoi comunque registrare la
          prenotazione senza addebito reale.
        </p>
        <button
          type="button"
          disabled={disabled}
          onClick={() => onPaid({ paymentIntentId: intentId || "pi_mock", mock: true })}
          className="w-full rounded-xl bg-primary py-3.5 font-bold text-primary-foreground disabled:opacity-50"
        >
          Conferma prenotazione (demo) · €{amountEuro}
        </button>
      </div>
    );
  }

  if (!stripePromise || !clientSecret || !options) {
    return (
      <p className="text-sm text-muted-foreground">Impossibile inizializzare Stripe Elements.</p>
    );
  }

  return (
    <Elements stripe={stripePromise} options={options}>
      <CheckoutForm
        disabled={disabled}
        onError={onError}
        onPaid={(id) => onPaid({ paymentIntentId: id, mock: false })}
      />
    </Elements>
  );
}
