import { Link, useNavigate } from "@tanstack/react-router";
import { useRef, useCallback } from "react";
import { MessageCircle } from "lucide-react";
import { useApp } from "@/lib/AppContext";
import { i18n, type Lang, isWhatsappConfigured } from "@/lib/store";

export function Nav() {
  const { state, setLang } = useApp();
  const t = i18n[state.lang];
  const navigate = useNavigate();
  const clicks = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const onLogoClick = useCallback(
    (e: React.MouseEvent) => {
      // 3 clic rapidi → area admin (nascosta)
      clicks.current += 1;
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => {
        clicks.current = 0;
      }, 900);
      if (clicks.current >= 3) {
        e.preventDefault();
        clicks.current = 0;
        navigate({ to: "/admin" });
      }
    },
    [navigate]
  );

  const waOk = isWhatsappConfigured(state.content.whatsapp);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-4 px-4">
        <Link
          to="/"
          onClick={onLogoClick}
          className="select-none font-display text-lg font-extrabold tracking-tight text-primary"
          title="Ischia Rent"
        >
          ISCHIA<span className="text-accent"> RENT</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-semibold md:flex">
          <Link
            to="/"
            className="text-muted-foreground transition-colors hover:text-primary [&.active]:text-primary"
          >
            {t.home}
          </Link>
          <Link
            to="/flotta"
            className="text-muted-foreground transition-colors hover:text-primary [&.active]:text-primary"
          >
            {t.fleet}
          </Link>
          <Link
            to="/prenota"
            className="text-muted-foreground transition-colors hover:text-primary [&.active]:text-primary"
          >
            {t.book}
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-full border border-border bg-muted px-1.5 py-1">
            {(["it", "en", "de"] as Lang[]).map((l) => (
              <button
                key={l}
                type="button"
                onClick={() => setLang(l)}
                className={`rounded-full px-2 py-0.5 text-[11px] font-bold uppercase transition-colors ${
                  state.lang === l
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-primary"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          {waOk ? (
            <a
              href={state.content.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full bg-whatsapp px-3.5 py-2 text-xs font-semibold text-primary-foreground shadow-soft transition-transform active:scale-95"
            >
              <MessageCircle className="size-4" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>
          ) : (
            <span
              className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3.5 py-2 text-xs font-semibold text-muted-foreground"
              title={t.whatsappMissing}
            >
              <MessageCircle className="size-4" />
              <span className="hidden sm:inline">WhatsApp</span>
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
