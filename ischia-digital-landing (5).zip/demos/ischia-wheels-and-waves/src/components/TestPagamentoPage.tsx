/**
 * Modalità TEST — simula un pagamento riuscito senza Stripe.
 * Apri: /test-pagamento
 *
 * Cosa fa:
 * 1. Crea una prenotazione finta "confirmed" (come se avessi pagato)
 * 2. La salva nello store (visibile in Admin → Prenotazioni)
 * 3. Mostra la schermata post-pagamento
 */
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  FlaskConical,
  CreditCard,
  Calendar,
  Car,
  Mail,
  ArrowRight,
  Shield,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { useApp } from "@/lib/AppContext";
import {
  type Booking,
  defaultLocalDatetime,
  rentalDays,
} from "@/lib/store";

export function TestPagamentoPage() {
  const { state, setBookings } = useApp();
  const [done, setDone] = useState(false);
  const [booking, setBooking] = useState<Booking | null>(null);

  const vehicle =
    state.vehicles.find((v) => v.available) ?? state.vehicles[0];

  const runTest = (scenario: "paid" | "pending" | "with_deposit") => {
    if (!vehicle) return;
    const pickup = defaultLocalDatetime(2, 10);
    const ret = defaultLocalDatetime(5, 10);
    const days = rentalDays(pickup, ret);
    const total = Math.round(vehicle.price * days);
    const deposit =
      scenario === "with_deposit" ? vehicle.deposit ?? 200 : vehicle.deposit ?? 0;

    const b: Booking = {
      id: crypto.randomUUID(),
      vehicleId: vehicle.id,
      customerName: "Mario Rossi (TEST)",
      customerEmail: "test@ischiarent.local",
      customerPhone: "+39 333 1234567",
      pickup,
      return: ret,
      pickupLocation: "iasolino",
      extras: [],
      total,
      deposit: deposit || 0,
      status: scenario === "pending" ? "pending" : "confirmed",
      createdAt: new Date().toISOString(),
      lang: state.lang,
      documentsUploaded: true,
      contractSigned: true,
      privacyAccepted: true,
    };

    setBookings((list) => [b, ...list]);
    setBooking(b);
    setDone(true);
  };

  if (done && booking) {
    const v = state.vehicles.find((x) => x.id === booking.vehicleId);
    const paid = booking.status === "confirmed";

    return (
      <div className="min-h-screen bg-background font-sans">
        <Nav />
        <div className="mx-auto max-w-lg px-4 py-16">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-center"
          >
            <div
              className={`mx-auto flex size-20 items-center justify-center rounded-full ${
                paid ? "bg-emerald-500/15 text-emerald-600" : "bg-amber-500/15 text-amber-600"
              }`}
            >
              <CheckCircle2 className="size-10" />
            </div>
            <h1 className="mt-6 font-display text-2xl font-extrabold text-primary">
              {paid ? "Pagamento simulato riuscito" : "Prenotazione in attesa"}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Modalità TEST — nessun addebito reale su Stripe.
            </p>
          </motion.div>

          <div className="mt-8 space-y-3 rounded-2xl border border-border bg-card p-5 shadow-soft text-left">
            <Row icon={Car} label="Mezzo" value={v?.name ?? booking.vehicleId} />
            <Row
              icon={Calendar}
              label="Ritiro"
              value={new Date(booking.pickup).toLocaleString("it-IT")}
            />
            <Row
              icon={Calendar}
              label="Riconsegna"
              value={new Date(booking.return).toLocaleString("it-IT")}
            />
            <Row icon={CreditCard} label="Totale" value={`€${booking.total}`} />
            {booking.deposit > 0 && (
              <Row
                icon={Shield}
                label="Cauzione"
                value={`€${booking.deposit} (pre-autorizzazione finta)`}
              />
            )}
            <Row icon={Mail} label="Email" value={booking.customerEmail} />
            <div className="flex justify-between border-t border-border pt-3 text-sm">
              <span className="text-muted-foreground">Stato</span>
              <span
                className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${
                  paid
                    ? "bg-emerald-500/15 text-emerald-600"
                    : "bg-amber-500/15 text-amber-600"
                }`}
              >
                {booking.status}
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground">
              ID prenotazione: <code>{booking.id.slice(0, 8)}…</code>
            </p>
          </div>

          <div className="mt-6 space-y-2">
            <p className="text-center text-sm text-muted-foreground">
              Cosa fare adesso:
            </p>
            <Link
              to="/admin"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-bold text-primary-foreground"
            >
              Apri Admin → Prenotazioni <ArrowRight className="size-4" />
            </Link>
            <button
              type="button"
              onClick={() => {
                setDone(false);
                setBooking(null);
              }}
              className="w-full rounded-xl border border-border py-3 text-sm font-semibold"
            >
              Simula un altro scenario
            </button>
            <Link
              to="/"
              className="block text-center text-sm text-muted-foreground hover:underline"
            >
              Torna alla home
            </Link>
          </div>

          <div className="mt-8 rounded-xl border border-dashed border-border bg-muted/40 p-4 text-left text-xs text-muted-foreground">
            <p className="font-semibold text-foreground">Cosa è successo (simulato)</p>
            <ol className="mt-2 list-decimal space-y-1 pl-4">
              <li>Pagamento {paid ? "confermato" : "non completato"} (finto)</li>
              <li>Prenotazione salvata nel browser (localStorage)</li>
              <li>
                In Admin vedi cliente, mezzo, totale, stato e puoi fare Check-in
              </li>
              <li>Email/SMS reali solo se Resend/Twilio sono configurati</li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-sans">
      <Nav />
      <div className="mx-auto max-w-lg px-4 py-12">
        <div className="flex items-center gap-3">
          <div className="flex size-12 items-center justify-center rounded-2xl bg-amber-500/15 text-amber-600">
            <FlaskConical className="size-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-extrabold text-primary">
              Modalità test pagamento
            </h1>
            <p className="text-sm text-muted-foreground">
              Fingi di aver pagato e guarda cosa succede dopo
            </p>
          </div>
        </div>

        <p className="mt-6 text-sm text-muted-foreground">
          Nessuna carta, nessun Stripe. Crea una prenotazione di prova e aprila in
          Admin.
        </p>

        {vehicle && (
          <p className="mt-2 text-xs text-muted-foreground">
            Mezzo usato: <strong>{vehicle.name}</strong> · €{vehicle.price}/giorno
          </p>
        )}

        <div className="mt-8 space-y-3">
          <button
            type="button"
            onClick={() => runTest("paid")}
            className="flex w-full flex-col items-start gap-1 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 px-5 py-4 text-left transition hover:bg-emerald-500/10"
          >
            <span className="font-bold text-emerald-700 dark:text-emerald-400">
              1 · Pagamento riuscito
            </span>
            <span className="text-xs text-muted-foreground">
              Stato <code>confirmed</code> — come dopo Stripe OK
            </span>
          </button>

          <button
            type="button"
            onClick={() => runTest("with_deposit")}
            className="flex w-full flex-col items-start gap-1 rounded-2xl border border-accent/30 bg-accent/5 px-5 py-4 text-left transition hover:bg-accent/10"
          >
            <span className="font-bold text-primary">2 · Pagato + cauzione</span>
            <span className="text-xs text-muted-foreground">
              Totale pagato e cauzione registrata (simulata)
            </span>
          </button>

          <button
            type="button"
            onClick={() => runTest("pending")}
            className="flex w-full flex-col items-start gap-1 rounded-2xl border border-amber-500/30 bg-amber-500/5 px-5 py-4 text-left transition hover:bg-amber-500/10"
          >
            <span className="font-bold text-amber-700 dark:text-amber-400">
              3 · In attesa di pagamento
            </span>
            <span className="text-xs text-muted-foreground">
              Stato <code>pending</code> — cliente non ha ancora pagato
            </span>
          </button>
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          Solo per sviluppo. Non usare in produzione.
        </p>
      </div>
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Car;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 text-sm">
      <Icon className="mt-0.5 size-4 shrink-0 text-accent" />
      <div className="min-w-0 flex-1">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}
