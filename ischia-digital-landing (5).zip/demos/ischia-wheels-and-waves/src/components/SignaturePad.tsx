/**
 * Signature pad nativo (canvas) — nessuna dipendenza esterna.
 * Espone getDataUrl() e clear() via ref o callback onChange.
 */
import { useRef, useEffect, useCallback, useState } from "react";

type Props = {
  onChange?: (dataUrl: string | null) => void;
  className?: string;
  height?: number;
};

export function SignaturePad({ onChange, className = "", height = 160 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const stroked = useRef(false);
  const [hasStroke, setHasStroke] = useState(false);

  const getCtx = () => {
    const c = canvasRef.current;
    if (!c) return null;
    const ctx = c.getContext("2d");
    if (!ctx) return null;
    return { c, ctx };
  };

  const resize = useCallback(() => {
    const el = canvasRef.current;
    if (!el) return;
    const parent = el.parentElement;
    const w = parent?.clientWidth ?? 320;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    el.width = Math.floor(w * dpr);
    el.height = Math.floor(height * dpr);
    el.style.width = `${w}px`;
    el.style.height = `${height}px`;
    const ctx = el.getContext("2d");
    if (ctx) {
      ctx.scale(dpr, dpr);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.strokeStyle = "#0f172a";
      ctx.lineWidth = 2.2;
    }
  }, [height]);

  useEffect(() => {
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [resize]);

  const pos = (e: React.MouseEvent | React.TouchEvent) => {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    if ("touches" in e) {
      const t = e.touches[0];
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    }
    return { x: (e as React.MouseEvent).clientX - r.left, y: (e as React.MouseEvent).clientY - r.top };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const pair = getCtx();
    if (!pair) return;
    drawing.current = true;
    const p = pos(e);
    pair.ctx.beginPath();
    pair.ctx.moveTo(p.x, p.y);
  };

  const move = (e: React.MouseEvent | React.TouchEvent) => {
    if (!drawing.current) return;
    e.preventDefault();
    const pair = getCtx();
    if (!pair) return;
    const p = pos(e);
    pair.ctx.lineTo(p.x, p.y);
    pair.ctx.stroke();
    stroked.current = true;
  };

  const end = () => {
    if (!drawing.current) return;
    drawing.current = false;
    const pair = getCtx();
    if (!pair || !stroked.current) return;
    setHasStroke(true);
    onChange?.(pair.c.toDataURL("image/png"));
  };

  const clear = () => {
    const el = canvasRef.current;
    if (!el) return;
    const ctx = el.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, el.width, el.height);
    resize();
    stroked.current = false;
    setHasStroke(false);
    onChange?.(null);
  };

  return (
    <div className={className}>
      <div className="overflow-hidden rounded-xl border border-input bg-white touch-none">
        <canvas
          ref={canvasRef}
          className="block w-full cursor-crosshair"
          style={{ height }}
          onMouseDown={start}
          onMouseMove={move}
          onMouseUp={end}
          onMouseLeave={end}
          onTouchStart={start}
          onTouchMove={move}
          onTouchEnd={end}
          aria-label="Area firma digitale"
          role="img"
        />
      </div>
      <div className="mt-2 flex items-center justify-between gap-2">
        <p className="text-xs text-muted-foreground">
          {hasStroke ? "Firma rilevata" : "Disegna la firma con il dito o il mouse"}
        </p>
        <button
          type="button"
          onClick={clear}
          className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-muted"
        >
          Cancella
        </button>
      </div>
    </div>
  );
}
