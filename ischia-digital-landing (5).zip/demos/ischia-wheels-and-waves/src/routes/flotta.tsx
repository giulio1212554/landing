import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Gauge, HardHat, Infinity as InfinityIcon, Users, Anchor, Fuel } from "lucide-react";
import { Nav } from "@/components/Nav";
import { useApp } from "@/lib/AppContext";
import { i18n, type Cat } from "@/lib/store";

export const Route = createFileRoute("/flotta")({
  head: () => ({
    meta: [
      { title: "Flotta — Ischia Rent | Scooter, Auto e Gommoni" },
      { name: "description", content: "Scopri la flotta completa di Ischia Rent: Vespa, Fiat 500, gommoni. Disponibilità in tempo reale e prenotazione online." },
    ],
  }),
  component: FlottaPage,
});

const cats: { id: Cat; label: string; emoji: string }[] = [
  { id: "scooter", label: "Scooter", emoji: "🛵" },
  { id: "auto", label: "Auto", emoji: "🚗" },
  { id: "gommoni", label: "Gommoni", emoji: "🛥️" },
];

const specIcons = {
  scooter: [Gauge, HardHat, InfinityIcon],
  auto: [Users, Fuel, InfinityIcon],
  gommoni: [Users, Anchor, Fuel],
};

function FlottaPage() {
  const { state } = useApp();
  const t = i18n[state.lang];
  const [cat, setCat] = useState<Cat | "all">("all");

  const list =
    cat === "all"
      ? state.vehicles
      : state.vehicles.filter((v) => v.cat === cat);

  return (
    <div className="min-h-screen bg-background font-sans">
      <Nav />

      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="mb-8">
          <p className="text-xs font-bold uppercase tracking-wider text-accent">Catalogo completo</p>
          <h1 className="mt-1 font-display text-3xl font-extrabold text-primary md:text-4xl">
            La nostra flotta
          </h1>
          <p className="mt-2 max-w-xl text-muted-foreground">
            Mezzi selezionati, mantenuti con cura e pronti al porto di Ischia. Disponibilità aggiornata in tempo reale.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-wrap gap-2">
          <button
            onClick={() => setCat("all")}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
              cat === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-secondary"
            }`}
          >
            Tutti
          </button>
          {cats.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                cat === c.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-secondary"
              }`}
            >
              {c.emoji} {c.label}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((v, i) => (
            <motion.article
              key={v.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -4 }}
              className={`overflow-hidden rounded-2xl border border-border bg-card shadow-soft ${
                v.available ? "" : "opacity-60 grayscale"
              }`}
            >
              <div className="relative bg-secondary px-6 pt-8">
                <span
                  className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-bold ${
                    !v.available
                      ? "bg-muted text-muted-foreground"
                      : v.badge === "Più Richiesto"
                        ? "bg-gold text-primary"
                        : "bg-accent text-accent-foreground"
                  }`}
                >
                  {v.available ? v.badge : t.notAvailable}
                </span>
                <img
                  src={v.img}
                  alt={v.name}
                  loading="lazy"
                  className="mx-auto h-44 w-full object-contain"
                />
              </div>
              <div className="p-4">
                <h3 className="font-display text-lg font-bold text-primary">{v.name}</h3>
                {v.desc && <p className="mt-1 text-sm text-muted-foreground">{v.desc}</p>}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {v.specs.map((s, si) => {
                    const Icon = (specIcons[v.cat] as any)[si] ?? InfinityIcon;
                    return (
                      <span
                        key={s}
                        className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground"
                      >
                        <Icon className="size-3 text-accent" />
                        {s}
                      </span>
                    );
                  })}
                </div>
                <div className="mt-4 flex items-end justify-between gap-3">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      {t.from}{" "}
                      <span className="font-display text-2xl font-extrabold text-primary">€{v.price}</span> / {t.day}
                    </p>
                    {v.deposit != null && v.deposit > 0 && (
                      <p className="text-xs text-muted-foreground">
                        Cauzione: €{v.deposit}
                      </p>
                    )}
                  </div>
                </div>
                <Link
                  to="/prenota"
                  search={{ vehicle: v.id }}
                  className={`mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-transform active:scale-[0.98] ${
                    v.available
                      ? "bg-primary text-primary-foreground"
                      : "pointer-events-none bg-muted text-muted-foreground"
                  }`}
                >
                  {v.available ? (
                    <>
                      {t.bookNow} <ArrowRight className="size-4" />
                    </>
                  ) : (
                    t.notAvailable
                  )}
                </Link>
              </div>
            </motion.article>
          ))}
        </div>

        {list.length === 0 && (
          <p className="py-16 text-center text-muted-foreground">Nessun mezzo in questa categoria.</p>
        )}
      </section>

      <footer className="mx-auto max-w-6xl px-4 py-8 text-center text-xs text-muted-foreground">
        © 2026 Ischia Rent · Molo Iasolino, Porto di Ischia (NA)
      </footer>
    </div>
  );
}
