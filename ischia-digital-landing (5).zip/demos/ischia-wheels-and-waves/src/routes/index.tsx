import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  MapPin,
  CalendarClock,
  ArrowRight,
  MessageCircle,
  Map,
  CreditCard,
  ShieldCheck,
  Gauge,
  HardHat,
  Infinity as InfinityIcon,
  Users,
  Anchor,
  Fuel,
} from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Nav } from "@/components/Nav";
import { ReviewsWidget } from "@/components/ReviewsWidget";
import { useApp } from "@/lib/AppContext";
import { i18n, type Cat } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ischia Rent — Noleggio Auto, Scooter e Gommoni a Ischia" },
      {
        name: "description",
        content:
          "Noleggio auto, scooter e gommoni con consegna diretta al Porto di Ischia. Prenotazione rapida, Kasko e assistenza H24.",
      },
      { property: "og:title", content: "Ischia Rent — Esplora Ischia in Totale Libertà" },
      {
        property: "og:description",
        content: "Scooter, auto e gommoni consegnati al Molo Iasolino in 2 minuti.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const cats: { id: Cat; label: string; emoji: string }[] = [
  { id: "scooter", label: "Scooter", emoji: "🛵" },
  { id: "auto", label: "Auto", emoji: "🚗" },
  { id: "gommoni", label: "Gommoni", emoji: "🛥️" },
];

const specIcons = {
  scooter: [Gauge, HardHat, InfinityIcon],
  auto: [Users, Fuel, InfinityIcon],
  gommoni: [Users, Anchor, Fuel],
};

const propIcons = [MapPin, CreditCard, ShieldCheck];

function Field({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof MapPin;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex items-center gap-3 rounded-xl border border-border bg-muted px-3 py-2.5 focus-within:border-accent transition-colors">
      <Icon className="size-4 shrink-0 text-accent" />
      <span className="flex min-w-0 flex-1 flex-col">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        {children}
      </span>
    </label>
  );
}

function Index() {
  const { state } = useApp();
  const t = i18n[state.lang];
  const [cat, setCat] = useState<Cat>("scooter");
  const today = new Date();
  const fmt = (d: Date) => d.toISOString().slice(0, 10) + "T10:00";
  const ret = new Date(today.getTime() + 3 * 864e5);
  const list = state.vehicles.filter((v) => v.cat === cat);

  return (
    <div className="min-h-screen bg-background pb-28 font-sans md:pb-0">
      <Nav />

      {/* Hero */}
      <section className="relative">
        <div className="relative h-[340px] overflow-hidden md:h-[460px]">
          <img
            src={hero}
            alt="Porto di Ischia"
            width={1280}
            height={832}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-hero-overlay" />
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-x-0 bottom-20 mx-auto max-w-6xl px-4 text-primary-foreground md:bottom-32"
          >
            <span className="inline-block rounded-full bg-gold px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary">
              {state.content.seasonBadge || "Ischia · Noleggio"}
            </span>
            <h1 className="mt-3 font-display text-3xl font-extrabold leading-tight md:text-5xl">
              {state.content.heroTitle.split(" in ").map((part, i) =>
                i === 0 ? (
                  <span key={i}>
                    {part}
                    <br />
                  </span>
                ) : (
                  <span key={i}>in {part}</span>
                )
              )}
            </h1>
            <p className="mt-2 max-w-md text-sm opacity-90 md:text-base">
              {state.content.heroSubtitle}
            </p>
          </motion.div>
        </div>

        {/* Booking widget */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="relative z-10 mx-auto -mt-16 max-w-3xl px-4"
        >
          <div className="rounded-2xl bg-card p-4 shadow-float md:p-6">
            <div className="mb-4 grid grid-cols-3 gap-1 rounded-xl bg-muted p-1">
              {cats.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCat(c.id)}
                  className="relative rounded-lg py-2 text-sm font-semibold transition-colors"
                >
                  {cat === c.id && (
                    <motion.span
                      layoutId="tab"
                      className="absolute inset-0 rounded-lg bg-primary shadow-soft"
                      transition={{ type: "spring", stiffness: 400, damping: 32 }}
                    />
                  )}
                  <span
                    className={`relative ${
                      cat === c.id ? "text-primary-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {c.emoji} {c.label}
                  </span>
                </button>
              ))}
            </div>
            <div className="grid gap-2.5 md:grid-cols-3">
              <Field icon={MapPin} label="Ritiro">
                <select
                  className="w-full truncate bg-transparent text-sm font-medium text-foreground outline-none"
                  defaultValue="iasolino"
                >
                  <option value="iasolino">Molo Iasolino - Porto di Ischia</option>
                  <option value="casamicciola">Porto di Casamicciola</option>
                  <option value="forio">Porto di Forio</option>
                  <option value="hotel">Consegna in Hotel</option>
                </select>
              </Field>
              <Field icon={CalendarClock} label="Ritiro data e ora">
                <input
                  type="datetime-local"
                  defaultValue={fmt(today)}
                  className="w-full bg-transparent text-sm font-medium text-foreground outline-none"
                />
              </Field>
              <Field icon={CalendarClock} label="Riconsegna data e ora">
                <input
                  type="datetime-local"
                  defaultValue={fmt(ret)}
                  className="w-full bg-transparent text-sm font-medium text-foreground outline-none"
                />
              </Field>
            </div>
            <Link
              to="/flotta"
              className="pulse-cta mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-3.5 font-display font-bold text-accent-foreground transition-transform active:scale-[0.98]"
            >
              {t.seeAvailable} <ArrowRight className="size-4" />
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Value props */}
      <section className="mx-auto mt-10 max-w-6xl">
        <div className="no-scrollbar flex snap-x gap-3 overflow-x-auto px-4 md:grid md:grid-cols-3">
          {state.content.valueProps.map((p, i) => {
            const Icon = propIcons[i] ?? MapPin;
            return (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="min-w-[72%] snap-start rounded-2xl bg-sand p-4 md:min-w-0"
              >
                <div className="flex size-10 items-center justify-center rounded-xl bg-card text-accent shadow-soft">
                  <Icon className="size-5" />
                </div>
                <h3 className="mt-3 font-display font-bold text-primary">{p.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.text}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Catalog preview */}
      <section id="mezzi" className="mx-auto mt-12 max-w-6xl scroll-mt-20 px-4">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-accent">
              La nostra flotta
            </p>
            <h2 className="font-display text-2xl font-extrabold text-primary">
              {cats.find((c) => c.id === cat)?.label} disponibili
            </h2>
          </div>
          <Link
            to="/flotta"
            className="text-sm font-semibold text-accent hover:underline"
          >
            Vedi tutti →
          </Link>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((v, i) => (
            <motion.article
              key={v.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              whileHover={{ y: -4 }}
              className={`overflow-hidden rounded-2xl border border-border bg-card shadow-soft ${
                v.available ? "" : "opacity-60 grayscale"
              }`}
            >
              <div className="relative bg-secondary px-6 pt-8">
                <span
                  className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-bold ${
                    !v.available
                      ? "bg-muted text-muted-foreground"
                      : v.badge === "Più Richiesto"
                        ? "bg-gold text-primary"
                        : "bg-accent text-accent-foreground"
                  }`}
                >
                  {v.available ? v.badge : t.notAvailable}
                </span>
                <img
                  src={v.img}
                  alt={v.name}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="mx-auto h-44 w-full object-contain"
                />
              </div>
              <div className="p-4">
                <h3 className="font-display text-lg font-bold text-primary">{v.name}</h3>
                {v.desc && <p className="mt-1 text-sm text-muted-foreground">{v.desc}</p>}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {v.specs.map((s, si) => {
                    const Icon = (specIcons[v.cat] as any)[si] ?? InfinityIcon;
                    return (
                      <span
                        key={s}
                        className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground"
                      >
                        <Icon className="size-3 text-accent" />
                        {s}
                      </span>
                    );
                  })}
                </div>
                <div className="mt-4 flex items-center justify-between gap-3">
                  <p className="text-sm text-muted-foreground">
                    {t.from}{" "}
                    <span className="font-display text-2xl font-extrabold text-primary">
                      €{v.price}
                    </span>{" "}
                    / {t.day}
                  </p>
                </div>
                <Link
                  to="/prenota"
                  search={{ vehicle: v.id }}
                  className={`mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-transform active:scale-[0.98] ${
                    v.available
                      ? "bg-primary text-primary-foreground"
                      : "pointer-events-none bg-muted text-muted-foreground"
                  }`}
                >
                  {v.available ? (
                    <>
                      {t.bookNow} <ArrowRight className="size-4" />
                    </>
                  ) : (
                    t.notAvailable
                  )}
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Packages teaser */}
      {state.packages.filter((p) => p.active).length > 0 && (
        <section className="mx-auto mt-14 max-w-6xl px-4">
          <p className="text-xs font-bold uppercase tracking-wider text-accent">Pacchetti</p>
          <h2 className="font-display text-2xl font-extrabold text-primary">Offerte speciali</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {state.packages
              .filter((p) => p.active)
              .map((p) => (
                <div
                  key={p.id}
                  className="rounded-2xl border border-gold/40 bg-gold/10 p-5"
                >
                  <p className="font-display text-lg font-bold text-primary">{p.name}</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {p.desc || `Sconto ${p.discountPct}% per noleggi di almeno ${p.daysMin} giorni`}
                  </p>
                </div>
              ))}
          </div>
        </section>
      )}

      <ReviewsWidget reviews={state.reviews} />

      {/* Link modalità test (solo sviluppo) */}
      <div className="mx-auto mt-10 max-w-6xl px-4 pb-8 text-center">
        <Link
          to="/test"
          className="text-xs font-semibold text-muted-foreground underline-offset-2 hover:text-accent hover:underline"
        >
          Modalità test pagamento →
        </Link>
      </div>

      <footer className="mx-auto mt-16 max-w-6xl px-4 py-8 text-center text-xs text-muted-foreground">
        © 2026 Ischia Rent · Molo Iasolino, Porto di Ischia (NA)
        <br />
        <Link to="/admin" className="mt-2 inline-block text-[10px] opacity-40 hover:opacity-100">
          Admin
        </Link>
      </footer>

      {/* Mobile bottom bar */}
      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 p-3 backdrop-blur-md md:hidden">
        <div className="flex gap-2">
          <a
            href={state.content.whatsapp || "#"}
            target="_blank"
            rel="noreferrer"
            className="flex flex-[2] items-center justify-center gap-2 rounded-xl bg-whatsapp py-3 text-sm font-bold text-primary-foreground shadow-soft active:scale-[0.98]"
          >
            <MessageCircle className="size-4" /> Prenota Subito via WhatsApp
          </a>
          <a
            href={state.content.mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-border bg-card py-3 text-xs font-semibold text-primary active:scale-[0.98]"
          >
            <Map className="size-4 text-accent" /> Mappa
          </a>
        </div>
      </div>
    </div>
  );
}
