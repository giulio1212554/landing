/**
 * Dashboard admin.
 * ⚠️ PIN: solo facciata client-side. Produzione: Supabase Auth + RLS.
 */
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Car, Package, Tag, FileText, Settings, LogOut, Plus, Trash2,
  TrendingUp, TrendingDown, Users, Euro, Calendar, CheckCircle, Clock, Save, X,
  Lock, BarChart3, Globe, Menu, Download, Pencil,
} from "lucide-react";
import { useApp } from "@/lib/AppContext";
import {
  dashboardStats, applySeasonMultiplier, sanitizePrice, sanitizeNonNeg,
  removeVehicleFromState, setVehicleBasePrice,
  type Vehicle, type Extra, type Package as Pkg, type Cat, type Booking,
} from "@/lib/store";
import { CheckInOutPanel } from "@/components/CheckInOut";
import { BOOTSTRAP_ADMIN_PIN } from "@/lib/auth-pin";
import {
  verifyPin, registerFailedAttempt, clearAttempts, isLocked, lockRemainingMs,
  PIN_POLICY,
} from "@/lib/auth-pin";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Dashboard — Ischia Rent" }] }),
  component: AdminPage,
});

type Tab = "overview" | "fleet" | "extras" | "packages" | "bookings" | "content" | "settings";

function AdminPage() {
  const {
    state, setIsAdmin, isAdmin, setVehicles, setExtras, setPackages, setContent,
    setBookings, setAdminPinSecure,
  } = useApp();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("overview");
  const [pin, setPin] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [lockMs, setLockMs] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  // Dopo login con PIN di default → form cambio obbligatorio
  const [mustChangePin, setMustChangePin] = useState(false);
  const [setupPin, setSetupPin] = useState("");
  const [setupPin2, setSetupPin2] = useState("");

  useEffect(() => {
    if (!isLocked()) return;
    const t = setInterval(() => setLockMs(lockRemainingMs()), 500);
    setLockMs(lockRemainingMs());
    return () => clearInterval(t);
  }, [err]);

  const onLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (isLocked()) {
      setErr(`Troppi tentativi. Riprova tra ${Math.ceil(lockRemainingMs() / 1000)}s.`);
      return;
    }
    setBusy(true);
    try {
      let ok = false;
      let usedBootstrap = false;
      if (!state.adminPinHash || !state.adminPinSalt) {
        // Primo accesso: PIN di default
        ok = pin === BOOTSTRAP_ADMIN_PIN;
        usedBootstrap = ok;
      } else {
        ok = await verifyPin(pin, state.adminPinHash, state.adminPinSalt);
        // Se ancora pinMustChange, anche dopo hash, forza cambio
      }
      if (ok) {
        clearAttempts();
        setIsAdmin(true);
        setPin("");
        if (usedBootstrap || state.pinMustChange) {
          setMustChangePin(true);
        }
      } else {
        const st = registerFailedAttempt();
        setErr(
          isLocked(st)
            ? `PIN errato. Bloccato per ${Math.ceil(lockRemainingMs(st) / 1000)}s.`
            : `PIN errato (${st.fails}/${PIN_POLICY.maxAttempts}).`
        );
        setPin("");
      }
    } finally {
      setBusy(false);
    }
  };

  const onChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (setupPin.length < PIN_POLICY.minLength) {
      setErr(`Minimo ${PIN_POLICY.minLength} caratteri.`);
      return;
    }
    if (setupPin === BOOTSTRAP_ADMIN_PIN) {
      setErr("Scegli un PIN diverso da quello di default.");
      return;
    }
    if (setupPin !== setupPin2) {
      setErr("I due PIN non coincidono.");
      return;
    }
    setBusy(true);
    try {
      await setAdminPinSecure(setupPin);
      setMustChangePin(false);
      setSetupPin("");
      setSetupPin2("");
    } finally {
      setBusy(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5 px-4">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={onLogin}
          className="w-full max-w-sm rounded-2xl border border-border bg-card p-8 shadow-float"
        >
          <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Lock className="size-7" />
          </div>
          <h1 className="mt-4 text-center font-display text-2xl font-extrabold text-primary">
            Area Riservata
          </h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">
            Tre clic sul logo → qui. Inserisci il PIN.
          </p>
          <input
            autoFocus
            inputMode="numeric"
            type="password"
            autoComplete="current-password"
            value={pin}
            onChange={(e) => {
              setPin(e.target.value);
              setErr(null);
            }}
            className="mt-6 w-full rounded-xl border border-input bg-muted px-4 py-3 text-center text-2xl tracking-[0.4em] outline-none focus:border-ring"
          />
          {err && (
            <p className="mt-2 text-center text-sm text-destructive" role="alert">
              {err}
            </p>
          )}
          {lockMs > 0 && (
            <p className="mt-1 text-center text-xs text-muted-foreground">
              Sblocco tra {Math.ceil(lockMs / 1000)}s
            </p>
          )}
          <button
            type="submit"
            disabled={busy || lockMs > 0}
            className="mt-4 w-full rounded-xl bg-accent py-3.5 font-bold text-accent-foreground disabled:opacity-50"
          >
            Accedi alla Dashboard
          </button>
          <p className="mt-3 text-center text-[10px] text-muted-foreground">
            Accesso nascosto: 3 clic sul logo in alto.
          </p>
          <Link
            to="/"
            className="mt-4 block text-center text-xs text-muted-foreground hover:underline"
          >
            ← Torna al sito
          </Link>
        </motion.form>
      </div>
    );
  }

  // Dopo PIN default: obbligo cambio prima della dashboard
  if (mustChangePin || state.pinMustChange) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0f172a] px-4 text-slate-100">
        <motion.form
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={onChangePin}
          className="w-full max-w-sm rounded-2xl border border-slate-700 bg-slate-900 p-8"
        >
          <h1 className="text-center font-display text-xl font-bold">Cambia PIN obbligatorio</h1>
          <p className="mt-2 text-center text-sm text-slate-400">
            Hai usato il PIN di default. Impostane uno personale prima di continuare.
          </p>
          <input
            autoFocus
            type="password"
            autoComplete="new-password"
            minLength={PIN_POLICY.minLength}
            value={setupPin}
            onChange={(e) => setSetupPin(e.target.value)}
            placeholder="Nuovo PIN"
            className="mt-6 w-full rounded-xl border border-slate-700 bg-slate-800 px-4 py-3 text-center text-lg tracking-widest outline-none focus:border-accent"
          />
          <input
            type="password"
            autoComplete="new-password"
            minLength={PIN_POLICY.minLength}
            value={setupPin2}
            onChange={(e) => setSetupPin2(e.target.value)}
            placeholder="Ripeti PIN"
            className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-800 px-4 py-3 text-center text-lg tracking-widest outline-none focus:border-accent"
          />
          {err && (
            <p className="mt-2 text-center text-sm text-red-400" role="alert">
              {err}
            </p>
          )}
          <button
            type="submit"
            disabled={busy}
            className="mt-4 w-full rounded-xl bg-accent py-3.5 font-bold text-white disabled:opacity-50"
          >
            Salva nuovo PIN
          </button>
        </motion.form>
      </div>
    );
  }

    const stats = dashboardStats(state.vehicles, state.bookings);
  const tabs: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "fleet", label: "Flotta", icon: Car },
    { id: "extras", label: "Extra", icon: Tag },
    { id: "packages", label: "Pacchetti", icon: Package },
    { id: "bookings", label: "Prenotazioni", icon: Calendar },
    { id: "content", label: "Contenuti", icon: FileText },
    { id: "settings", label: "Impostazioni", icon: Settings },
  ];
  const selectTab = (id: Tab) => { setTab(id); setSidebarOpen(false); };

  return (
    <div className="flex min-h-screen bg-[#0f172a] text-slate-100">
      {sidebarOpen && (
        <button type="button" aria-label="Chiudi menu" className="fixed inset-0 z-40 bg-black/60 md:hidden"
          onClick={() => setSidebarOpen(false)} />
      )}
      <aside className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-800 bg-slate-950 transition-transform duration-200 md:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-16 items-center justify-between border-b border-slate-800 px-5">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-accent text-sm font-bold text-white">IR</div>
            <div><p className="font-display text-sm font-bold">Ischia Rent</p><p className="text-[10px] text-slate-500">Admin Console</p></div>
          </div>
          <button type="button" className="rounded-lg p-2 text-slate-400 hover:bg-slate-900 md:hidden" onClick={() => setSidebarOpen(false)} aria-label="Chiudi"><X className="size-5" /></button>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
          {tabs.map((t) => (
            <button key={t.id} type="button" onClick={() => selectTab(t.id)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${tab === t.id ? "bg-accent/20 text-accent" : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"}`}>
              <t.icon className="size-4 shrink-0" />{t.label}
            </button>
          ))}
        </nav>
        <div className="border-t border-slate-800 p-3">
          <Link to="/" className="mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-400 hover:bg-slate-900 hover:text-slate-200"><Globe className="size-4" /> Vedi sito</Link>
          <button type="button" onClick={() => { setIsAdmin(false); navigate({ to: "/" }); }}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-red-400 hover:bg-red-500/10"><LogOut className="size-4" /> Esci</button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 md:ml-64">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-800 bg-slate-950/80 px-4 backdrop-blur md:px-8">
          <div className="flex items-center gap-3">
            <button type="button" className="rounded-lg p-2 text-slate-300 hover:bg-slate-900 md:hidden" onClick={() => setSidebarOpen(true)} aria-label="Apri menu"><Menu className="size-5" /></button>
            <h1 className="font-display text-lg font-bold capitalize">{tabs.find((t) => t.id === tab)?.label}</h1>
          </div>
          <span className="rounded-full bg-emerald-500/20 px-2.5 py-1 text-xs font-semibold text-emerald-400">● Online</span>
        </header>
        <div className="p-4 md:p-8">
          <AnimatePresence mode="wait">
            {tab === "overview" && <Overview key="ov" stats={stats} bookings={state.bookings} vehicles={state.vehicles} />}
            {tab === "fleet" && <FleetTab key="fl" vehicles={state.vehicles} packages={state.packages} bookings={state.bookings} setVehicles={setVehicles} setPackages={setPackages} />}
            {tab === "extras" && <ExtrasTab key="ex" extras={state.extras} setExtras={setExtras} />}
            {tab === "packages" && <PackagesTab key="pk" packages={state.packages} vehicles={state.vehicles} setPackages={setPackages} />}
            {tab === "bookings" && <BookingsTab key="bk" bookings={state.bookings} vehicles={state.vehicles} setBookings={setBookings} />}
            {tab === "content" && <ContentTab key="ct" content={state.content} setContent={setContent} />}
            {tab === "settings" && <SettingsTab key="st" setAdminPinSecure={setAdminPinSecure} />}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}


function Overview({
  stats, bookings, vehicles,
}: {
  stats: ReturnType<typeof dashboardStats>;
  bookings: Booking[];
  vehicles: Vehicle[];
}) {
  const nameOf = (id: string) => vehicles.find((v) => v.id === id)?.name ?? id;
  const cards = [
    { label: "Noleggi attivi", value: stats.active, icon: Users, color: "text-cyan-400" },
    { label: "Incasso prenotazioni live", value: `€${stats.revenue}`, icon: Euro, color: "text-amber-400" },
    { label: "Mezzi disponibili", value: `${stats.available}/${stats.total}`, icon: Car, color: "text-emerald-400" },
    { label: "Prenotazioni totali", value: stats.totalBookings, icon: Calendar, color: "text-violet-400" },
  ];
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 shadow-lg">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-slate-400">{c.label}</p>
              <c.icon className={`size-5 ${c.color}`} />
            </div>
            <p className="mt-2 font-display text-3xl font-extrabold tracking-tight">{c.value}</p>
          </div>
        ))}
      </div>
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
        <h2 className="mb-4 flex items-center gap-2 font-display text-base font-bold">
          <BarChart3 className="size-4 text-accent" /> Ultime prenotazioni
        </h2>
        {bookings.length === 0 ? (
          <p className="text-sm text-slate-500">Nessuna prenotazione ancora.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-500">
                  <th className="pb-3 pr-4">Cliente</th>
                  <th className="pb-3 pr-4">Mezzo</th>
                  <th className="pb-3 pr-4">Totale</th>
                  <th className="pb-3 pr-4">Stato</th>
                  <th className="pb-3">Data</th>
                </tr>
              </thead>
              <tbody>
                {bookings.slice(0, 8).map((b) => (
                  <tr key={b.id} className="border-b border-slate-800/50">
                    <td className="py-3 pr-4 font-medium">{b.customerName}</td>
                    <td className="py-3 pr-4 text-slate-300">{nameOf(b.vehicleId)}</td>
                    <td className="py-3 pr-4">€{b.total}</td>
                    <td className="py-3 pr-4"><StatusBadge status={b.status} /></td>
                    <td className="py-3 text-slate-500">{new Date(b.createdAt).toLocaleDateString("it-IT")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-500/20 text-amber-400",
    confirmed: "bg-emerald-500/20 text-emerald-400",
    completed: "bg-slate-500/20 text-slate-400",
    cancelled: "bg-red-500/20 text-red-400",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${map[status] || map.pending}`}>{status}</span>
  );
}

function FleetTab({
  vehicles, packages, bookings, setVehicles, setPackages,
}: {
  vehicles: Vehicle[]; packages: Pkg[]; bookings: Booking[];
  setVehicles: (fn: (v: Vehicle[]) => Vehicle[]) => void;
  setPackages: (fn: (p: Pkg[]) => Pkg[]) => void;
}) {
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", cat: "scooter" as Cat, price: "", deposit: "", badge: "", desc: "", img: "" });

  const add = () => {
    const price = sanitizePrice(form.price);
    if (!form.name) return;
    const v: Vehicle = {
      id: crypto.randomUUID(), cat: form.cat, name: form.name, img: form.img || "/placeholder.svg",
      price, basePrice: price, seasonMultiplier: 1, deposit: sanitizeNonNeg(form.deposit),
      badge: form.badge || "Novità", desc: form.desc,
      specs: form.cat === "scooter" ? ["2 Caschi Inclusi", "Km Illimitati"] : form.cat === "auto" ? ["4 Posti", "Km Illimitati"] : ["Ancora + Telo"],
      available: true, activeRentals: 0,
    };
    setVehicles((l) => [...l, v]);
    setAdding(false);
    setForm({ name: "", cat: "scooter", price: "", deposit: "", badge: "", desc: "", img: "" });
  };

  const onDelete = (id: string, name: string) => {
    const result = removeVehicleFromState(vehicles, packages, bookings, id);
    if (result.blocked) {
      alert(`Impossibile eliminare "${name}": ${result.activeCount} prenotazioni attive. Annullale prima.`);
      return;
    }
    if (!confirm(`Eliminare ${name}? Verrà rimosso anche dai pacchetti.`)) return;
    setVehicles(() => result.vehicles);
    setPackages(() => result.packages);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <button type="button" onClick={() => setVehicles((l) => applySeasonMultiplier(l, 1.2))}
          className="flex items-center gap-2 rounded-xl bg-amber-500/20 px-4 py-2 text-sm font-bold text-amber-400 hover:bg-amber-500/30">
          <TrendingUp className="size-4" /> Alta ×1.2
        </button>
        <button type="button" onClick={() => setVehicles((l) => applySeasonMultiplier(l, 0.8))}
          className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2 text-sm font-bold text-slate-300 hover:bg-slate-700">
          <TrendingDown className="size-4" /> Bassa ×0.8
        </button>
        <button type="button" onClick={() => setVehicles((l) => applySeasonMultiplier(l, 1))}
          className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2 text-sm font-bold text-slate-300 hover:bg-slate-700">
          Reset ×1
        </button>
        <button type="button" onClick={() => setAdding(true)}
          className="ml-auto flex items-center gap-2 rounded-xl bg-accent px-4 py-2 text-sm font-bold text-white">
          <Plus className="size-4" /> Aggiungi mezzo
        </button>
      </div>
      <p className="text-xs text-slate-500">I moltiplicatori non si cumulan: partono sempre da basePrice.</p>
      {adding && (
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-bold">Nuovo mezzo</h3>
            <button type="button" onClick={() => setAdding(false)} aria-label="Chiudi"><X className="size-5 text-slate-400" /></button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <input placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
            <select value={form.cat} onChange={(e) => setForm({ ...form, cat: e.target.value as Cat })}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none">
              <option value="scooter">Scooter</option><option value="auto">Auto</option><option value="gommoni">Gommone</option>
            </select>
            <input type="number" min={1} placeholder="Prezzo base €/giorno" value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
            <input type="number" min={0} placeholder="Cauzione €" value={form.deposit}
              onChange={(e) => setForm({ ...form, deposit: e.target.value })}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
          </div>
          <button type="button" onClick={add} className="mt-4 flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-bold text-white">
            <Save className="size-4" /> Salva mezzo
          </button>
        </div>
      )}
      <div className="space-y-3">
        {vehicles.map((v) => (
          <div key={v.id} className={`flex flex-wrap items-center gap-4 rounded-2xl border border-slate-800 bg-slate-900/60 p-4 ${!v.available ? "opacity-50" : ""}`}>
            <img src={v.img} alt="" className="size-14 rounded-xl bg-slate-800 object-contain" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-semibold">{v.name}</p>
              <p className="text-xs text-slate-500">base €{v.basePrice} · ×{v.seasonMultiplier} · cauzione €{v.deposit ?? 0}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-400">€</span>
              <input type="number" min={1} value={v.basePrice}
                onChange={(e) => {
                  const n = sanitizePrice(e.target.value);
                  setVehicles((l) => l.map((x) => (x.id === v.id ? setVehicleBasePrice(x, n) : x)));
                }}
                className="w-20 rounded-lg border border-slate-700 bg-slate-800 px-2 py-1.5 text-right text-sm font-bold outline-none" />
              <span className="text-xs text-slate-500">→ €{v.price}/g</span>
            </div>
            <button type="button"
              onClick={() => setVehicles((l) => l.map((x) => (x.id === v.id ? { ...x, available: !x.available } : x)))}
              className={`rounded-full px-3 py-1 text-xs font-semibold ${v.available ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-700 text-slate-400"}`}>
              {v.available ? "Disponibile" : "Off"}
            </button>
            <button type="button" onClick={() => onDelete(v.id, v.name)} className="rounded-lg p-2 text-red-400 hover:bg-red-500/10" aria-label={`Elimina ${v.name}`}>
              <Trash2 className="size-4" />
            </button>
          </div>
        ))}
      </div>
    </motion.div>
  );
}


function ExtrasTab({ extras, setExtras }: { extras: Extra[]; setExtras: (fn: (e: Extra[]) => Extra[]) => void }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex flex-wrap gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <input placeholder="Nome extra" value={name} onChange={(e) => setName(e.target.value)}
          className="flex-1 rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
        <input type="number" min={1} placeholder="Prezzo €" value={price} onChange={(e) => setPrice(e.target.value)}
          className="w-28 rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
        <button type="button" onClick={() => {
          if (!name) return;
          setExtras((l) => [...l, { id: crypto.randomUUID(), name, price: sanitizePrice(price), active: true }]);
          setName(""); setPrice("");
        }} className="flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-white">
          <Plus className="size-4" /> Aggiungi
        </button>
      </div>
      <div className="space-y-2">
        {extras.map((e) => (
          <div key={e.id} className="flex items-center gap-4 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex-1"><p className="font-semibold">{e.name}</p></div>
            <input type="number" min={1} value={e.price}
              onChange={(ev) => setExtras((l) => l.map((x) => x.id === e.id ? { ...x, price: sanitizePrice(ev.target.value) } : x))}
              className="w-16 rounded-lg border border-slate-700 bg-slate-800 px-2 py-1.5 text-right text-sm font-bold outline-none" />
            <button type="button" onClick={() => setExtras((l) => l.map((x) => x.id === e.id ? { ...x, active: !x.active } : x))}
              className={`rounded-full px-3 py-1 text-xs font-semibold ${e.active ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-700 text-slate-400"}`}>
              {e.active ? "Attivo" : "Off"}
            </button>
            <button type="button" onClick={() => setExtras((l) => l.filter((x) => x.id !== e.id))} className="rounded-lg p-2 text-red-400 hover:bg-red-500/10">
              <Trash2 className="size-4" />
            </button>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function PackagesTab({ packages, vehicles, setPackages }: {
  packages: Pkg[]; vehicles: Vehicle[]; setPackages: (fn: (p: Pkg[]) => Pkg[]) => void;
}) {
  const [name, setName] = useState("");
  const [discount, setDiscount] = useState("10");
  const [daysMin, setDaysMin] = useState("3");
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <h3 className="mb-3 font-bold">Nuovo pacchetto sconto</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <input placeholder="Nome" value={name} onChange={(e) => setName(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
          <input type="number" min={1} max={90} value={discount} onChange={(e) => setDiscount(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
          <input type="number" min={1} value={daysMin} onChange={(e) => setDaysMin(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
        </div>
        <button type="button" onClick={() => {
          if (!name) return;
          setPackages((l) => [...l, {
            id: crypto.randomUUID(), name, vehicleIds: vehicles.map((v) => v.id),
            discountPct: sanitizePrice(discount), daysMin: sanitizePrice(daysMin), active: true,
          }]);
          setName("");
        }} className="mt-3 flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-white">
          <Plus className="size-4" /> Crea pacchetto
        </button>
      </div>
      <div className="space-y-2">
        {packages.map((p) => (
          <div key={p.id} className="flex items-center gap-4 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex-1">
              <p className="font-semibold">{p.name}</p>
              <p className="text-xs text-slate-500">−{p.discountPct}% · min {p.daysMin} gg · {p.vehicleIds.length} mezzi</p>
            </div>
            <button type="button" onClick={() => setPackages((l) => l.map((x) => x.id === p.id ? { ...x, active: !x.active } : x))}
              className={`rounded-full px-3 py-1 text-xs font-semibold ${p.active ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-700 text-slate-400"}`}>
              {p.active ? "Attivo" : "Off"}
            </button>
            <button type="button" onClick={() => setPackages((l) => l.filter((x) => x.id !== p.id))} className="rounded-lg p-2 text-red-400 hover:bg-red-500/10">
              <Trash2 className="size-4" />
            </button>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function exportBookingsCsv(bookings: Booking[], vehicles: Vehicle[]) {
  const nameOf = (id: string) => vehicles.find((v) => v.id === id)?.name ?? id;
  const header = ["id","cliente","email","telefono","mezzo","ritiro","riconsegna","totale","cauzione","stato","creata"];
  const rows = bookings.map((b) =>
    [b.id, b.customerName, b.customerEmail, b.customerPhone, nameOf(b.vehicleId), b.pickup, b.return, b.total, b.deposit, b.status, b.createdAt]
      .map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")
  );
  const csv = [header.join(","), ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `prenotazioni-ischia-rent-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

function BookingsTab({ bookings, vehicles, setBookings }: {
  bookings: Booking[]; vehicles: Vehicle[]; setBookings: (fn: (b: Booking[]) => Booking[]) => void;
}) {
  const [editId, setEditId] = useState<string | null>(null);
  const checkInId = editId?.startsWith("checkin:") ? editId.slice(8) : null;
  const editing = bookings.find((b) => b.id === editId);
  const checkInBooking = bookings.find((b) => b.id === checkInId);
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      <div className="flex justify-end">
        <button type="button" onClick={() => exportBookingsCsv(bookings, vehicles)} disabled={bookings.length === 0}
          className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-semibold disabled:opacity-40">
          <Download className="size-4" /> Esporta CSV
        </button>
      </div>
      
      {checkInBooking && (
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-bold">Check-in — {checkInBooking.customerName}</h3>
            <button type="button" onClick={() => setEditId(null)} aria-label="Chiudi"><X className="size-5" /></button>
          </div>
          {checkInBooking.checkIn ? (
            <p className="text-sm text-emerald-400">Check-in già registrato il {new Date(checkInBooking.checkIn.at).toLocaleString("it-IT")}</p>
          ) : (
            <CheckInOutPanel
              mode="checkin"
              onComplete={(data) => {
                setBookings((list) =>
                  list.map((x) => (x.id === checkInBooking.id ? { ...x, checkIn: data, status: x.status === "pending" ? "confirmed" : x.status } : x))
                );
                setEditId(null);
              }}
            />
          )}
        </div>
      )}

      {editing && (
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-bold">Modifica prenotazione</h3>
            <button type="button" onClick={() => setEditId(null)} aria-label="Chiudi"><X className="size-5" /></button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <input value={editing.customerName} onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, customerName: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" placeholder="Nome" />
            <input value={editing.customerEmail} onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, customerEmail: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" placeholder="Email" />
            <input value={editing.customerPhone} onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, customerPhone: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" placeholder="Telefono" />
            <select value={editing.vehicleId} onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, vehicleId: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm">
              {vehicles.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
            </select>
            <input type="datetime-local" value={editing.pickup.slice(0, 16)}
              onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, pickup: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" />
            <input type="datetime-local" value={editing.return.slice(0, 16)}
              onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, return: e.target.value } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" />
            <input type="number" min={1} value={editing.total}
              onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, total: sanitizePrice(e.target.value) } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm" />
            <select value={editing.status} onChange={(e) => setBookings((list) => list.map((x) => x.id === editing.id ? { ...x, status: e.target.value as Booking["status"] } : x))}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm">
              <option value="pending">pending</option>
              <option value="confirmed">confirmed</option>
              <option value="completed">completed</option>
              <option value="cancelled">cancelled</option>
            </select>
          </div>
          <button type="button" onClick={() => setEditId(null)} className="mt-3 rounded-xl bg-accent px-4 py-2 text-sm font-bold text-white">Chiudi</button>
        </div>
      )}
      {bookings.length === 0 ? (
        <p className="py-12 text-center text-slate-500">Nessuna prenotazione registrata.</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-800">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900">
              <tr className="text-xs text-slate-500">
                <th className="px-4 py-3">Cliente</th>
                <th className="px-4 py-3">Mezzo</th>
                <th className="px-4 py-3">Totale</th>
                <th className="px-4 py-3">Docs</th>
                <th className="px-4 py-3">Stato</th>
                <th className="px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => {
                const v = vehicles.find((x) => x.id === b.vehicleId);
                return (
                  <tr key={b.id} className="border-t border-slate-800/60">
                    <td className="px-4 py-3 font-medium">{b.customerName}</td>
                    <td className="px-4 py-3">{v?.name ?? b.vehicleId}</td>
                    <td className="px-4 py-3">€{b.total}</td>
                    <td className="px-4 py-3">{b.documentsUploaded ? <CheckCircle className="size-4 text-emerald-400" /> : <Clock className="size-4 text-slate-500" />}</td>
                    <td className="px-4 py-3"><StatusBadge status={b.status} /></td>
                    <td className="px-4 py-3">
                      <button type="button" onClick={() => setEditId(b.id)}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-700 px-2 py-1 text-xs font-semibold hover:bg-slate-800">
                        <Pencil className="size-3" /> Modifica
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
}

function ContentTab({ content, setContent }: { content: any; setContent: (fn: (c: any) => any) => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl space-y-5">
      <div>
        <label className="text-xs font-semibold text-slate-400">Titolo Hero</label>
        <input value={content.heroTitle} onChange={(e) => setContent((c: any) => ({ ...c, heroTitle: e.target.value }))}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
      </div>
      <div>
        <label className="text-xs font-semibold text-slate-400">Sottotitolo Hero</label>
        <textarea value={content.heroSubtitle} onChange={(e) => setContent((c: any) => ({ ...c, heroSubtitle: e.target.value }))} rows={2}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
      </div>
      <div>
        <label className="text-xs font-semibold text-slate-400">Badge stagione (hero)</label>
        <input
          value={content.seasonBadge || ""}
          onChange={(e) => setContent((c: any) => ({ ...c, seasonBadge: e.target.value }))}
          placeholder="Ischia · Noleggio"
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent"
        />
      </div>
      <div>
        <label className="text-xs font-semibold text-slate-400">Link WhatsApp (obbligatorio, wa.me/...)</label>
        <input value={content.whatsapp} onChange={(e) => setContent((c: any) => ({ ...c, whatsapp: e.target.value }))}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
      </div>
      <div>
        <label className="text-xs font-semibold text-slate-400">URL Google Maps</label>
        <input value={content.mapsUrl} onChange={(e) => setContent((c: any) => ({ ...c, mapsUrl: e.target.value }))}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
      </div>
      <div>
        <label className="text-xs font-semibold text-slate-400">Keyword SEO (una per riga)</label>
        <textarea value={(content.seoKeywords || []).join("\n")}
          onChange={(e) => setContent((c: any) => ({ ...c, seoKeywords: e.target.value.split("\n").filter(Boolean) }))} rows={4}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
      </div>
    </motion.div>
  );
}

function SettingsTab({ setAdminPinSecure }: { setAdminPinSecure: (pin: string) => Promise<void> }) {
  const [newPin, setNewPin] = useState("");
  const [newPin2, setNewPin2] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="max-w-md space-y-5">
      <div>
        <label className="text-xs font-semibold text-slate-400">Nuovo PIN (hash SHA-256)</label>
        <input type="password" value={newPin} onChange={(e) => setNewPin(e.target.value)}
          className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
        <input type="password" placeholder="Ripeti PIN" value={newPin2} onChange={(e) => setNewPin2(e.target.value)}
          className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-accent" />
        <button type="button" onClick={async () => {
          setMsg(null);
          if (newPin.length < PIN_POLICY.minLength) { setMsg(`Minimo ${PIN_POLICY.minLength} caratteri`); return; }
          if (newPin !== newPin2) { setMsg("I PIN non coincidono"); return; }
          await setAdminPinSecure(newPin);
          setNewPin(""); setNewPin2("");
          setMsg("PIN aggiornato (solo hash).");
        }} className="mt-3 rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-white">
          Salva nuovo PIN
        </button>
        {msg && <p className="mt-2 text-xs text-slate-400">{msg}</p>}
      </div>
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-xs text-slate-400">
        <p className="font-semibold text-slate-300">Sicurezza</p>
        <p className="mt-2">
          PIN memorizzato solo come hash SHA-256 con salt (SubtleCrypto). Questa è protezione di facciata:
          in produzione usare autenticazione lato server (Supabase Auth + RLS).
        </p>
      </div>
    </motion.div>
  );
}

