import { createFileRoute } from "@tanstack/react-router";
import { TestPagamentoPage } from "@/components/TestPagamentoPage";

export const Route = createFileRoute("/test-pagamento")({
  head: () => ({
    meta: [{ title: "Test pagamento — Ischia Rent" }],
  }),
  component: TestPagamentoPage,
});
