import { createFileRoute } from "@tanstack/react-router";
import { TestPagamentoPage } from "@/components/TestPagamentoPage";

export const Route = createFileRoute("/test")({
  head: () => ({
    meta: [{ title: "Test pagamento — Ischia Rent" }],
  }),
  component: TestPagamentoPage,
});
