import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo, useEffect } from "react";
import { motion } from "framer-motion";
import {
  MapPin,
  CalendarClock,
  CreditCard,
  FileText,
  CheckCircle2,
  Upload,
  PenLine,
  Shield,
  ArrowRight,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { SignaturePad } from "@/components/SignaturePad";
import { StripePaymentForm } from "@/components/StripePaymentForm";
import { useApp } from "@/lib/AppContext";
import {
  generateContractPdf,
  downloadPdf,
  PdfLibraryMissingError,
  PdfGenerationError,
} from "@/lib/pdf-contract";
import { createDepositIntent } from "@/lib/stripe";
import { saveBookingRemote, uploadDocument } from "@/lib/supabase";
import { sendConfirmationEmailFn } from "@/lib/server-api";
import { hasStripe, hasSupabase, integrationStatus } from "@/lib/env";
import {
  i18n,
  type Booking,
  defaultLocalDatetime,
  validateRentalDates,
  rentalDays,
  matchPackageDiscount,
  isVehicleAvailableForDates,
  isValidEmail,
  isValidPhone,
  HOTEL_LOCATION,
  HOTEL_FEE,
  HOTEL_EXTRA_ID,
  type DateValidationError,
} from "@/lib/store";

export const Route = createFileRoute("/prenota")({
  validateSearch: (search: Record<string, unknown>) => ({
    vehicle: typeof search.vehicle === "string" ? search.vehicle : undefined,
    pickup: typeof search.pickup === "string" ? search.pickup : undefined,
    return: typeof search.return === "string" ? search.return : undefined,
    location: typeof search.location === "string" ? search.location : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Prenota online — Ischia Rent" },
      {
        name: "description",
        content:
          "Prenota scooter, auto o gommone a Ischia. Pagamento sicuro, documenti digitali e firma del contratto online.",
      },
    ],
  }),
  component: PrenotaPage,
});

const DATE_ERROR_MSG: Record<Exclude<DateValidationError, null>, string> = {
  pickup_past: "La data di ritiro non può essere nel passato.",
  return_before_pickup: "La riconsegna deve essere successiva al ritiro.",
  too_short: "Durata minima: 1 giorno. Controlla le date.",
};

function PrenotaPage() {
  const search = Route.useSearch();
  const { state, setBookings } = useApp();
  const t = i18n[state.lang];

  const firstAvailable = state.vehicles.find((v) => v.available)?.id ?? "";
  const initialVehicle =
    search.vehicle &&
    state.vehicles.some((v) => v.id === search.vehicle && v.available)
      ? search.vehicle
      : firstAvailable;

  const [step, setStep] = useState(1);
  const [vehicleId, setVehicleId] = useState(initialVehicle);
  const [pickupLoc, setPickupLoc] = useState(search.location || "iasolino");
  const [pickupDate, setPickupDate] = useState(
    () => search.pickup || defaultLocalDatetime(0, 10)
  );
  const [returnDate, setReturnDate] = useState(
    () => search.return || defaultLocalDatetime(3, 10)
  );
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [docsUploaded, setDocsUploaded] = useState(false);
  const [docFileName, setDocFileName] = useState<string | null>(null);
  const [docError, setDocError] = useState<string | null>(null);
  const [contractSigned, setContractSigned] = useState(false);
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [pdfMessage, setPdfMessage] = useState<string | null>(null);
  const [payMethod, setPayMethod] = useState<"stripe" | "paypal">("stripe");
  const [done, setDone] = useState(false);
  const [lastPaymentMock, setLastPaymentMock] = useState(true);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [step3Tried, setStep3Tried] = useState(false);

  // Se il mezzo predefinito non è più valido, ripiega sul primo disponibile
  useEffect(() => {
    const ok = state.vehicles.some((v) => v.id === vehicleId && v.available);
    if (!ok && firstAvailable) setVehicleId(firstAvailable);
  }, [state.vehicles, vehicleId, firstAvailable]);

  const vehicle = state.vehicles.find((v) => v.id === vehicleId);
  const days = useMemo(
    () => rentalDays(pickupDate, returnDate),
    [pickupDate, returnDate]
  );
  const dateError = useMemo(
    () => validateRentalDates(pickupDate, returnDate),
    [pickupDate, returnDate]
  );

  const hotelSelected = pickupLoc === HOTEL_LOCATION;
  const hotelFee = hotelSelected ? HOTEL_FEE : 0;

  const extrasTotal = selectedExtras.reduce((s, id) => {
    if (hotelSelected && id === HOTEL_EXTRA_ID) return s; // evita doppio addebito
    const e = state.extras.find((x) => x.id === id);
    return s + (e?.price ?? 0);
  }, 0);

  // Pacchetti: sconto solo se match completo; altrimenti cross-sell
  const packageEval = useMemo(() => {
    let discount = 0;
    let appliedName: string | null = null;
    const suggestions: { name: string; desc: string; discountPct: number; daysMin: number; otherIds: string[] }[] = [];

    for (const pkg of state.packages) {
      const m = matchPackageDiscount(pkg, vehicleId, days);
      if (m.applies && vehicle) {
        discount = Math.round(vehicle.price * days * (pkg.discountPct / 100));
        appliedName = pkg.name;
      } else if (m.reason === "need_multi" || (m.reason === "days" && pkg.vehicleIds.includes(vehicleId))) {
        const otherIds = pkg.vehicleIds.filter((id) => id !== vehicleId);
        suggestions.push({
          name: pkg.name,
          desc:
            pkg.desc ||
            `Prenota anche ${otherIds
              .map((id) => state.vehicles.find((v) => v.id === id)?.name ?? id)
              .join(" + ")} per almeno ${pkg.daysMin} giorni e ottieni −${pkg.discountPct}%`,
          discountPct: pkg.discountPct,
          daysMin: pkg.daysMin,
          otherIds,
        });
      }
    }
    return { discount, appliedName, suggestions };
  }, [state.packages, state.vehicles, vehicleId, days, vehicle]);

  const discount = packageEval.discount;
  const subtotal = (vehicle?.price ?? 0) * days + extrasTotal + hotelFee;
  const total = Math.max(0, subtotal - discount);
  const deposit = vehicle?.deposit ?? 0;

  const overlapOk =
    vehicle &&
    isVehicleAvailableForDates(vehicle, state.bookings, pickupDate, returnDate);

  const toggleExtra = (id: string) => {
    setSelectedExtras((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const step1Valid = !dateError && Boolean(vehicleId) && Boolean(vehicle?.available);

  const step3Valid =
    name.trim().length >= 2 &&
    isValidEmail(email) &&
    isValidPhone(phone) &&
    docsUploaded &&
    contractSigned;

  const finalizeBooking = async (paymentInfo: {
    paymentIntentId: string;
    mock: boolean;
    depositIntentId?: string;
  }) => {
    setBookingError(null);
    if (!vehicle || !step3Valid || !privacyAccepted) return;
    if (dateError) {
      setBookingError(DATE_ERROR_MSG[dateError]);
      return;
    }
    if (!isVehicleAvailableForDates(vehicle, state.bookings, pickupDate, returnDate)) {
      setBookingError(
        "Questo mezzo non è disponibile nelle date scelte (sovrapposizione con altre prenotazioni)."
      );
      return;
    }

    const extrasToSave = hotelSelected
      ? Array.from(new Set([...selectedExtras, HOTEL_EXTRA_ID]))
      : selectedExtras;

    const booking: Booking = {
      id: crypto.randomUUID(),
      vehicleId,
      customerName: name.trim(),
      customerEmail: email.trim(),
      customerPhone: phone.trim(),
      pickup: pickupDate,
      return: returnDate,
      pickupLocation: pickupLoc,
      extras: extrasToSave,
      total,
      deposit,
      status: paymentInfo.mock ? "pending" : "confirmed",
      createdAt: new Date().toISOString(),
      lang: state.lang,
      documentsUploaded: docsUploaded,
      contractSigned,
      privacyAccepted,
    };

    setBookings((b) => [booking, ...b]);

    try {
      await saveBookingRemote({
        id: booking.id,
        vehicle_id: booking.vehicleId,
        customer_name: booking.customerName,
        customer_email: booking.customerEmail,
        customer_phone: booking.customerPhone,
        pickup: booking.pickup,
        return: booking.return,
        extras: booking.extras,
        total: booking.total,
        deposit: booking.deposit,
        status: booking.status,
        lang: booking.lang,
        payment_intent_id: paymentInfo.paymentIntentId,
        deposit_intent_id: paymentInfo.depositIntentId,
      });
    } catch (e) {
      console.warn("[supabase] save remote failed", e);
    }

    try {
      await sendConfirmationEmailFn({
        data: {
          to: booking.customerEmail,
          name: booking.customerName,
          vehicle: vehicle.name,
          pickup: booking.pickup,
          total: booking.total,
          lang: booking.lang,
        },
      });
    } catch (e) {
      console.warn("[email] send failed", e);
    }

    setLastPaymentMock(paymentInfo.mock);
    setDone(true);
  };

  /** Crea anche cauzione (pre-auth) in background dopo il pagamento */
  const afterPaid = async (info: { paymentIntentId: string; mock: boolean }) => {
    let depositIntentId: string | undefined;
    if (deposit > 0 && !info.mock) {
      try {
        const dep = await createDepositIntent({
          amountCents: Math.round(deposit * 100),
          metadata: { vehicleId, type: "deposit", paymentId: info.paymentIntentId },
        });
        if (dep?.ok) depositIntentId = dep.id;
      } catch (e) {
        console.warn("[deposit]", e);
      }
    }
    await finalizeBooking({ ...info, depositIntentId });
  };


  if (done) {
    return (
      <div className="min-h-screen bg-background font-sans">
        <Nav />
        <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-20 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex size-20 items-center justify-center rounded-full bg-accent/20 text-accent"
          >
            <CheckCircle2 className="size-10" />
          </motion.div>
          <h1 className="mt-6 font-display text-2xl font-extrabold text-primary">
            {lastPaymentMock ? "Prenotazione registrata (demo)" : "Pagamento ricevuto"}
          </h1>
          <p className="mt-2 text-muted-foreground">
            {lastPaymentMock ? (
              <>
                Modalità demo: nessun addebito reale. Stato <strong>pending</strong>.
                Controlla in Admin → Prenotazioni.
              </>
            ) : (
              <>
                Grazie <strong>{name}</strong>. Riceverai conferma a <strong>{email}</strong>.
                Stato <strong>confirmed</strong>.
              </>
            )}
          </p>
          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Link
              to="/admin"
              className="rounded-xl bg-primary px-6 py-3 font-bold text-primary-foreground"
            >
              Vedi in Admin
            </Link>
            <Link
              to="/test-pagamento"
              className="rounded-xl border border-border px-6 py-3 text-sm font-semibold"
            >
              Altri test pagamento
            </Link>
            <Link to="/" className="rounded-xl px-6 py-3 text-sm text-muted-foreground hover:underline">
              Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-sans pb-20">
      <Nav />

      <div className="mx-auto max-w-3xl px-4 py-8">
        <h1 className="font-display text-2xl font-extrabold text-primary md:text-3xl">
          Prenota online
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Booking engine · Documenti digitali · Cauzione
        </p>

        <div className="mt-6 flex gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-1.5 flex-1 rounded-full transition-colors ${
                step >= s ? "bg-accent" : "bg-muted"
              }`}
            />
          ))}
        </div>
        <p className="mt-2 text-xs font-semibold text-muted-foreground">
          Passo {step} di 4 —{" "}
          {step === 1
            ? "Mezzo & Date"
            : step === 2
              ? "Extra & Pacchetti"
              : step === 3
                ? "Documenti & Contratto"
                : "Pagamento"}
        </p>

        {/* STEP 1 */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            className="mt-6 space-y-4"
          >
            <label className="block">
              <span className="text-xs font-semibold uppercase text-muted-foreground">
                Mezzo
              </span>
              <select
                value={vehicleId}
                onChange={(e) => setVehicleId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-input bg-muted px-3 py-3 text-sm font-medium outline-none focus:border-ring"
              >
                {state.vehicles
                  .filter((v) => v.available)
                  .map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name} — €{v.price}/giorno
                    </option>
                  ))}
              </select>
            </label>

            <label className="block">
              <span className="text-xs font-semibold uppercase text-muted-foreground">
                Luogo di ritiro
              </span>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-input bg-muted px-3 py-3">
                <MapPin className="size-4 text-accent" />
                <select
                  value={pickupLoc}
                  onChange={(e) => setPickupLoc(e.target.value)}
                  className="w-full bg-transparent text-sm font-medium outline-none"
                >
                  <option value="iasolino">Molo Iasolino - Porto di Ischia</option>
                  <option value="casamicciola">Porto di Casamicciola</option>
                  <option value="forio">Porto di Forio</option>
                  <option value={HOTEL_LOCATION}>
                    Consegna in Hotel (+€{HOTEL_FEE})
                  </option>
                </select>
              </div>
            </label>

            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="text-xs font-semibold uppercase text-muted-foreground">
                  Ritiro
                </span>
                <div className="mt-1 flex items-center gap-2 rounded-xl border border-input bg-muted px-3 py-3">
                  <CalendarClock className="size-4 text-accent" />
                  <input
                    type="datetime-local"
                    value={pickupDate}
                    onChange={(e) => setPickupDate(e.target.value)}
                    className="w-full bg-transparent text-sm font-medium outline-none"
                  />
                </div>
              </label>
              <label className="block">
                <span className="text-xs font-semibold uppercase text-muted-foreground">
                  Riconsegna
                </span>
                <div className="mt-1 flex items-center gap-2 rounded-xl border border-input bg-muted px-3 py-3">
                  <CalendarClock className="size-4 text-accent" />
                  <input
                    type="datetime-local"
                    value={returnDate}
                    onChange={(e) => setReturnDate(e.target.value)}
                    className="w-full bg-transparent text-sm font-medium outline-none"
                  />
                </div>
              </label>
            </div>

            {dateError && (
              <p className="text-sm text-destructive">{DATE_ERROR_MSG[dateError]}</p>
            )}
            {!dateError && vehicle && !overlapOk && (
              <p className="text-sm text-destructive">
                Nessuna unità disponibile in queste date per {vehicle.name}.
              </p>
            )}
            {!dateError && days > 0 && (
              <p className="text-xs text-muted-foreground">Durata: {days} giorno/i</p>
            )}

            <button
              type="button"
              disabled={!step1Valid || !overlapOk}
              onClick={() => setStep(2)}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-3.5 font-bold text-accent-foreground disabled:opacity-50"
            >
              Continua <ArrowRight className="size-4" />
            </button>
          </motion.div>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            className="mt-6 space-y-4"
          >
            <h2 className="font-display text-lg font-bold">Servizi aggiuntivi</h2>
            {hotelSelected && (
              <p className="rounded-xl bg-muted px-3 py-2 text-xs text-muted-foreground">
                Consegna in hotel già inclusa (+€{HOTEL_FEE}). L&apos;extra
                &quot;Consegna/Ritiro Hotel&quot; non viene addebitato due volte.
              </p>
            )}
            <div className="space-y-2">
              {state.extras
                .filter((e) => e.active)
                .filter((e) => !(hotelSelected && e.id === HOTEL_EXTRA_ID))
                .map((e) => (
                  <label
                    key={e.id}
                    className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-colors ${
                      selectedExtras.includes(e.id)
                        ? "border-accent bg-accent/5"
                        : "border-border bg-card"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedExtras.includes(e.id)}
                      onChange={() => toggleExtra(e.id)}
                      className="size-4 accent-[var(--accent)]"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-semibold">{e.name}</p>
                      {e.desc && (
                        <p className="text-xs text-muted-foreground">{e.desc}</p>
                      )}
                    </div>
                    <span className="font-bold text-primary">+€{e.price}</span>
                  </label>
                ))}
            </div>

            {packageEval.appliedName && discount > 0 && (
              <div className="rounded-xl border border-gold bg-gold/10 p-4">
                <p className="text-sm font-bold text-primary">
                  🎁 Pacchetto attivo: {packageEval.appliedName}
                </p>
                <p className="text-xs text-muted-foreground">
                  Sconto applicato (−€{discount})
                </p>
              </div>
            )}

            {packageEval.suggestions.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold uppercase text-muted-foreground">
                  Suggerimenti cross-selling
                </p>
                {packageEval.suggestions.map((s) => (
                  <div
                    key={s.name}
                    className="rounded-xl border border-border bg-card p-4"
                  >
                    <p className="text-sm font-bold text-primary">{s.name}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{s.desc}</p>
                    <p className="mt-2 text-xs font-semibold text-accent">
                      −{s.discountPct}% se combini i mezzi (min. {s.daysMin} giorni)
                    </p>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="rounded-xl border border-border px-4 py-3 text-sm font-semibold"
              >
                Indietro
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-accent py-3.5 font-bold text-accent-foreground"
              >
                Continua <ArrowRight className="size-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            className="mt-6 space-y-4"
          >
            <h2 className="font-display text-lg font-bold">Documenti & Contratto</h2>

            <div className="space-y-3">
              <div>
                <input
                  placeholder="Nome e cognome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-input bg-muted px-3 py-3 text-sm outline-none focus:border-ring"
                />
                {step3Tried && name.trim().length < 2 && (
                  <p className="mt-1 text-xs text-destructive">Inserisci nome e cognome.</p>
                )}
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-input bg-muted px-3 py-3 text-sm outline-none focus:border-ring"
                />
                {step3Tried && !isValidEmail(email) && (
                  <p className="mt-1 text-xs text-destructive">Inserisci un&apos;email valida.</p>
                )}
              </div>
              <div>
                <input
                  type="tel"
                  placeholder="Telefono / WhatsApp"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full rounded-xl border border-input bg-muted px-3 py-3 text-sm outline-none focus:border-ring"
                />
                {step3Tried && !isValidPhone(phone) && (
                  <p className="mt-1 text-xs text-destructive">
                    Inserisci un numero di telefono valido.
                  </p>
                )}
              </div>
            </div>

            {/* Upload documenti reale */}
            <div
              className={`rounded-xl border p-4 ${
                docsUploaded
                  ? "border-accent bg-accent/5"
                  : "border-dashed border-input bg-muted"
              }`}
            >
              <div className="flex items-start gap-3">
                <Upload className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold">
                    {docsUploaded
                      ? `✓ Documento caricato${docFileName ? `: ${docFileName}` : ""}`
                      : "Carica patente / carta d'identità"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Solo immagini (JPG/PNG/WebP) o PDF · max 5 MB
                  </p>
                  <label className="mt-3 inline-flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-semibold hover:bg-muted focus-within:ring-2 focus-within:ring-ring">
                    <span>{docsUploaded ? "Sostituisci file" : "Scegli file"}</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,application/pdf,.pdf"
                      className="sr-only"
                      onChange={(e) => {
                        setDocError(null);
                        const file = e.target.files?.[0];
                        e.target.value = "";
                        if (!file) {
                          setDocsUploaded(false);
                          setDocFileName(null);
                          return;
                        }
                        const okType =
                          file.type === "application/pdf" ||
                          file.type === "image/jpeg" ||
                          file.type === "image/png" ||
                          file.type === "image/webp" ||
                          /\.(pdf|jpe?g|png|webp)$/i.test(file.name);
                        if (!okType) {
                          setDocError("Formato non valido. Usa JPG, PNG, WebP o PDF.");
                          setDocsUploaded(false);
                          setDocFileName(null);
                          return;
                        }
                        if (file.size > 5 * 1024 * 1024) {
                          setDocError("File troppo grande (max 5 MB).");
                          setDocsUploaded(false);
                          setDocFileName(null);
                          return;
                        }
                        setDocFileName(file.name);
                        setDocsUploaded(true);
                      }}
                    />
                  </label>
                  {docError && (
                    <p className="mt-2 text-xs text-destructive" role="alert">
                      {docError}
                    </p>
                  )}
                  {step3Tried && !docsUploaded && !docError && (
                    <p className="mt-2 text-xs text-destructive">
                      Carica un documento valido per continuare.
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Firma su canvas */}
            <div
              className={`rounded-xl border p-4 ${
                contractSigned
                  ? "border-accent bg-accent/5"
                  : "border-dashed border-input bg-muted"
              }`}
            >
              <div className="mb-3 flex items-center gap-2">
                <PenLine className="size-5 text-accent" aria-hidden />
                <div>
                  <p className="text-sm font-semibold">
                    {contractSigned
                      ? "✓ Contratto firmato digitalmente"
                      : "Firma digitale del contratto"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Disegna la firma, poi genera il PDF
                  </p>
                </div>
              </div>
              <SignaturePad
                onChange={(url) => {
                  setSignatureDataUrl(url);
                  setContractSigned(Boolean(url));
                  setPdfMessage(null);
                }}
              />
              {step3Tried && !contractSigned && (
                <p className="mt-2 text-xs text-destructive">
                  Firma il contratto per continuare.
                </p>
              )}
              <button
                type="button"
                disabled={!contractSigned || !name.trim() || pdfBusy}
                onClick={async () => {
                  if (!vehicle || !signatureDataUrl) return;
                  setPdfBusy(true);
                  setPdfMessage(null);
                  try {
                    const extraNames = selectedExtras
                      .map((id) => state.extras.find((x) => x.id === id)?.name)
                      .filter(Boolean) as string[];
                    const blob = await generateContractPdf({
                      customerName: name.trim(),
                      customerEmail: email.trim(),
                      vehicleName: vehicle.name,
                      pickup: pickupDate,
                      returnDate: returnDate,
                      total,
                      deposit,
                      extras: extraNames,
                      signatureDataUrl,
                    });
                    downloadPdf(
                      blob,
                      `contratto-ischia-rent-${name.trim().replace(/\s+/g, "-").toLowerCase()}.pdf`
                    );
                    setPdfMessage("PDF scaricato. Conservalo insieme alla prenotazione.");
                  } catch (err) {
                    if (err instanceof PdfLibraryMissingError) {
                      setPdfMessage(
                        "Per generare il PDF installa pdf-lib: npm i pdf-lib (la firma resta valida)."
                      );
                    } else if (err instanceof PdfGenerationError) {
                      setPdfMessage(err.message);
                    } else {
                      setPdfMessage("Errore generico nella creazione del PDF.");
                    }
                  } finally {
                    setPdfBusy(false);
                  }
                }}
                className="mt-3 w-full rounded-xl border border-border bg-card py-2.5 text-sm font-semibold disabled:opacity-50"
              >
                {pdfBusy ? "Generazione PDF…" : "Scarica contratto PDF firmato"}
              </button>
              {pdfMessage && (
                <p className="mt-2 text-xs text-muted-foreground" role="status">
                  {pdfMessage}
                </p>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="rounded-xl border border-border px-4 py-3 text-sm font-semibold"
              >
                Indietro
              </button>
              <button
                type="button"
                onClick={() => {
                  setStep3Tried(true);
                  if (step3Valid) setStep(4);
                }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-accent py-3.5 font-bold text-accent-foreground"
              >
                Continua <ArrowRight className="size-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* STEP 4 */}
        {step === 4 && (
          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            className="mt-6 space-y-4"
          >
            <h2 className="font-display text-lg font-bold">Pagamento & Cauzione</h2>

            <p className="text-xs text-muted-foreground">
              Stripe pub: {hasStripe() ? "✓" : "✗"} · Supabase: {hasSupabase() ? "✓" : "✗ (solo locale)"}
              <br />
              La secret Stripe deve essere <code className="text-[10px]">STRIPE_SECRET_KEY</code> (senza prefisso VITE_).
            </p>


            <div className="rounded-2xl border border-border bg-card p-4 shadow-soft">
              <div className="flex justify-between text-sm">
                <span>
                  {vehicle?.name} × {days} giorni
                </span>
                <span>€{(vehicle?.price ?? 0) * days}</span>
              </div>
              {hotelFee > 0 && (
                <div className="mt-1 flex justify-between text-sm text-muted-foreground">
                  <span>Consegna in hotel</span>
                  <span>€{hotelFee}</span>
                </div>
              )}
              {extrasTotal > 0 && (
                <div className="mt-1 flex justify-between text-sm text-muted-foreground">
                  <span>Extra</span>
                  <span>€{extrasTotal}</span>
                </div>
              )}
              {discount > 0 && (
                <div className="mt-1 flex justify-between text-sm text-accent">
                  <span>Sconto pacchetto</span>
                  <span>−€{discount}</span>
                </div>
              )}
              <div className="mt-3 flex justify-between border-t border-border pt-3 font-display text-xl font-extrabold text-primary">
                <span>{t.total}</span>
                <span>€{total}</span>
              </div>
              {deposit > 0 && (
                <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Shield className="size-3.5" />
                  Cauzione pre-autorizzata: €{deposit} (sbloccata al ritorno del mezzo)
                </div>
              )}
            </div>

            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-muted/50 p-4">
              <input
                type="checkbox"
                checked={privacyAccepted}
                onChange={(e) => setPrivacyAccepted(e.target.checked)}
                className="mt-1 size-4 accent-[var(--accent)]"
              />
              <span className="text-sm">
                <span className="font-semibold">{t.privacyAccept}</span>
                <span className="mt-1 block text-xs text-muted-foreground">{t.cancelPolicy}</span>
              </span>
            </label>

            {payMethod === "stripe" && privacyAccepted ? (
              <StripePaymentForm
                amountEuro={total}
                customerEmail={email.trim()}
                customerName={name.trim()}
                vehicleId={vehicleId}
                disabled={!privacyAccepted}
                onError={(msg) => setBookingError(msg)}
                onPaid={(info) => {
                  void afterPaid(info);
                }}
              />
            ) : payMethod === "stripe" && !privacyAccepted ? (
              <p className="text-sm text-destructive">Accetta privacy e termini per pagare.</p>
            ) : (
              <div className="rounded-xl border border-border bg-muted/40 p-4 text-sm text-muted-foreground">
                PayPal non è ancora collegato. Usa Stripe / Carta.
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPayMethod("stripe")}
                className={`rounded-xl border py-3 text-sm font-bold ${
                  payMethod === "stripe" ? "border-accent bg-accent/10" : "border-border"
                }`}
              >
                <CreditCard className="mx-auto mb-1 size-5" />
                Stripe / Carta
              </button>
              <button
                type="button"
                onClick={() => setPayMethod("paypal")}
                className={`rounded-xl border py-3 text-sm font-bold ${
                  payMethod === "paypal" ? "border-accent bg-accent/10" : "border-border"
                }`}
              >
                PayPal
              </button>
            </div>

            {bookingError && (
              <p className="text-sm text-destructive" role="alert">{bookingError}</p>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="rounded-xl border border-border px-4 py-3 text-sm font-semibold"
              >
                Indietro
              </button>
            </div>

          </motion.div>
        )}
      </div>
    </div>
  );
}
