# Checklist verifica — Ischia Rent

## Funzionale

- [x] Home → Flotta → Prenota conserva mezzo/date (search params)
- [x] Impossibile doppia prenotazione stesso mezzo/intervallo (quantity)
- [x] Upload documenti reale + firma canvas + PDF
- [x] Privacy/termini obbligatori prima della conferma
- [x] Check-in in Admin (non dopo conferma booking)
- [x] Admin responsive (drawer mobile)
- [x] KPI overview da prenotazioni reali
- [x] Prezzi stagione non cumulativi (basePrice)
- [x] PIN solo hash, nessun "1234" in chiaro
- [x] i18n IT/EN/DE + 404 tradotta
- [x] Hydration SSR-safe + schema v3

## Test / build

```bash
npm test
npm run build
```

## Produzione ancora mock

| Voce | Stato |
|------|--------|
| Stripe live | Mock UI |
| Email/SMS | Mock / console |
| Google reviews live | Esempi etichettati |
| WhatsApp | Configurabile in admin (vuoto di default) |
