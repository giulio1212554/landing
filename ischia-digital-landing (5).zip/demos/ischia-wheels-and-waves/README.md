# Ischia Rent — Wheels & Waves

Sistema di prenotazione per noleggio scooter, auto e gommoni a Ischia.

## Funzionalità

- Booking a 4 step (date, extra, documenti/firma, pagamento mock)
- Anti-sovrapposizione prenotazioni (quantità per modello)
- Admin `/admin` con PIN in **hash SHA-256** (impostato al primo accesso)
- Upload documenti + SignaturePad + PDF (`pdf-lib`)
- Check-in digitale **in admin** al ritiro
- Multilingua IT/EN/DE + `html lang` dinamico
- Store versionato (`schemaVersion: 3`) con idratazione SSR-safe

## Avvio

```bash
npm i
npm run dev
npm test
npm run build
```

## Admin

1. **3 clic** sul logo «ISCHIA RENT» (in alto a sinistra)
2. PIN di default al primo accesso: **`1234`**
3. Subito dopo ti chiede di **cambiarlo** (obbligatorio)
4. Configura **WhatsApp** in Contenuti (link wa.me)

## Note produzione

- Stripe / Supabase / Resend: vedi `SERVICES.md`
- PIN client-side = sola facciata → usare Supabase Auth + RLS
- Recensioni attuali = **esempi** finché non c'è Google Places API
