# Servizi esterni

Vedi `.env.example` per le variabili.

| Servizio | Stato nel codice |
|----------|------------------|
| Stripe | `src/lib/stripe.ts` — mock finché mancano le chiavi |
| Supabase | `src/lib/supabase.ts` — storage + bookings |
| Resend / Twilio | `src/lib/email.ts` |
| pdf-lib | `src/lib/pdf-contract.ts` — `npm i pdf-lib` |
| Google Places | `src/lib/google-places.ts` |

Quando hai le chiavi, copiale in `.env` (mai in git). Il client passa da mock a reale automaticamente dove implementato.

**Auth admin:** PIN hash lato client è solo UX. In produzione: Supabase Auth + RLS.
