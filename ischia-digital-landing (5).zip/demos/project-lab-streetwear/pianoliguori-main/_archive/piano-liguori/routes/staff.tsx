import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";

import {
  type FloorTable,
  formatDateIt,
  formatWeekdayShort,
  nextDays,
  toISODate,
} from "@/lib/booking";
import {
  exportDayCsv,
  getStaffDay,
  setReservationStatus,
  staffCreateReservation,
  staffDeleteReservation,
  staffUpdateReservation,
  verifyPin,
} from "@/lib/booking.functions";
import { ALL_SLOTS, LUNCH_SLOTS } from "@/lib/booking";
import {
  opsAddOrder,
  opsDeleteMenuItem,
  opsGetMenu,
  opsListMessages,
  opsListOrders,
  opsPayTable,
  opsSaveMenuItem,
  opsSendMessage,
  opsSetOrderStatus,
  opsStats,
  opsTableBill,
  opsListSolutions,
  opsSaveSolution,
  opsDeleteSolution,
  staffCreateUser,
  staffListUsers,
  staffLogin,
  staffToggleUser,
} from "@/lib/staff-ops.functions";

type StaffSession = {
  id: string;
  username: string;
  name: string;
  role: "dirigente" | "cuoco" | "cassiere" | "cameriere";
  active: boolean;
};

export const Route = createFileRoute("/staff")({
  validateSearch: (search: Record<string, unknown>) => ({
    code: typeof search["code"] === "string" ? search["code"].slice(0, 12) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Area staff — Piano Liguori" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: StaffPage,
});

const SESSION_KEY = "pl-staff-session";
const PIN_KEY = "pl-staff-pin";

function StaffPage() {
  const { code } = Route.useSearch();
  const [session, setSession] = useState<StaffSession | null>(null);
  const [pinFallback, setPinFallback] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (raw) setSession(JSON.parse(raw) as StaffSession);
      else setPinFallback(sessionStorage.getItem(PIN_KEY));
    } catch {
      /* ignore */
    }
  }, []);

  const logout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(PIN_KEY);
    setSession(null);
    setPinFallback(null);
  };

  if (!session && !pinFallback) {
    return (
      <LoginGate
        onLogin={(user) => {
          sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
          setSession(user);
        }}
        onPinUnlock={(pin) => {
          sessionStorage.setItem(PIN_KEY, pin);
          // PIN generale = accesso dirigente base
          const dir: StaffSession = {
            id: "pin-dir",
            username: "pin",
            name: "Dirigente (PIN)",
            role: "dirigente",
            active: true,
          };
          sessionStorage.setItem(SESSION_KEY, JSON.stringify(dir));
          setSession(dir);
          setPinFallback(pin);
        }}
      />
    );
  }

  const active = session ?? {
    id: "pin-dir",
    username: "pin",
    name: "Dirigente (PIN)",
    role: "dirigente" as const,
    active: true,
  };

  return (
    <RoleConsole
      user={active}
      scannedCode={code ?? null}
      pin={pinFallback ?? "1234"}
      onLogout={logout}
    />
  );
}

function LoginGate({
  onLogin,
  onPinUnlock,
}: {
  onLogin: (u: StaffSession) => void;
  onPinUnlock: (pin: string) => void;
}) {
  const [mode, setMode] = useState<"account" | "pin">("account");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);

  const login = useMutation({
    mutationFn: () => staffLogin({ data: { username, password } }),
    onSuccess: (res) => onLogin(res.user as StaffSession),
    onError: (err: Error) => setError(err.message),
  });

  const checkPin = useMutation({
    mutationFn: () => verifyPin({ data: { pin } }),
    onSuccess: () => onPinUnlock(pin),
    onError: () => setError("PIN non valido"),
  });

  return (
    <div className="flex min-h-screen flex-col px-4 py-6">
      <Link
        to="/"
        className="text-[12px] font-medium text-muted-foreground underline decoration-border underline-offset-4"
      >
        ← Torna al sito
      </Link>
      <div className="bento mt-8 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Accesso riservato
        </p>
        <h1 className="mt-1 text-[22px] font-semibold">Area staff</h1>

        <div className="mt-4 flex gap-2">
          <button
            type="button"
            className={`chip flex-1 ${mode === "account" ? "chip-active" : ""}`}
            onClick={() => setMode("account")}
          >
            Account
          </button>
          <button
            type="button"
            className={`chip flex-1 ${mode === "pin" ? "chip-active" : ""}`}
            onClick={() => setMode("pin")}
          >
            PIN
          </button>
        </div>

        {mode === "account" ? (
          <div className="mt-4 space-y-3">
            <label className="field flex flex-col px-3 py-2.5">
              <span className="text-[10px] text-muted-foreground uppercase">Username</span>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-transparent text-[15px] outline-none"
                autoComplete="username"
              />
            </label>
            <label className="field flex flex-col px-3 py-2.5">
              <span className="text-[10px] text-muted-foreground uppercase">Password</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-transparent text-[15px] outline-none"
                autoComplete="current-password"
              />
            </label>
            <button
              type="button"
              disabled={login.isPending}
              onClick={() => login.mutate()}
              className="btn-ink w-full py-3 text-[14px]"
            >
              {login.isPending ? "Accesso…" : "Entra"}
            </button>
            <p className="text-[11px] text-muted-foreground">
              Account demo: dirigente / cuoco / cassiere / cameriere — password:
              nome+123 (es. dirigente123)
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            <label className="field flex flex-col px-3 py-2.5">
              <span className="text-[10px] text-muted-foreground uppercase">PIN</span>
              <input
                value={pin}
                onChange={(e) => setPin(e.target.value.slice(0, 12))}
                type="password"
                inputMode="numeric"
                className="bg-transparent text-[16px] tracking-[0.3em] outline-none"
              />
            </label>
            <button
              type="button"
              disabled={pin.length < 3 || checkPin.isPending}
              onClick={() => checkPin.mutate()}
              className="btn-ink w-full py-3 text-[14px]"
            >
              Entra con PIN
            </button>
          </div>
        )}
        {error ? <p className="mt-3 text-[12px] font-medium text-destructive">{error}</p> : null}
      </div>
    </div>
  );
}

function RoleConsole({
  user,
  scannedCode,
  pin,
  onLogout,
}: {
  user: StaffSession;
  scannedCode: string | null;
  pin: string;
  onLogout: () => void;
}) {
  const [tab, setTab] = useState<string>(() => {
    if (user.role === "cuoco") return "cucina";
    if (user.role === "cassiere") return "cassa";
    if (user.role === "cameriere") return "ordini";
    return "sala"; // console sala originale
  });

  const tabs = useMemo(() => {
    const common = [
      { id: "chat", label: "Chat" },
      { id: "sala", label: "Sala" },
    ];
    if (user.role === "dirigente") {
      return [
        { id: "sala", label: "Sala" },
        { id: "dashboard", label: "Stats" },
        { id: "menu", label: "Menu" },
        { id: "soluzioni", label: "Soluzioni" },
        { id: "team", label: "Team" },
        { id: "cucina", label: "Cucina" },
        { id: "cassa", label: "Cassa" },
        { id: "chat", label: "Chat" },
      ];
    }
    if (user.role === "cuoco") return [{ id: "cucina", label: "Cucina" }, ...common];
    if (user.role === "cassiere") return [{ id: "cassa", label: "Cassa" }, ...common];
    return [
      { id: "ordini", label: "Ordini" },
      { id: "sala", label: "Sala" },
      { id: "chat", label: "Chat" },
    ];
  }, [user.role]);

  return (
    <div className="min-h-screen pb-16">
      <header className="flex items-center justify-between px-4 py-3">
        <div>
          <p className="text-[15px] font-semibold tracking-[0.08em] uppercase">
            {user.role}
          </p>
          <p className="text-[11px] text-muted-foreground">{user.name}</p>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="text-[12px] font-medium text-muted-foreground underline"
        >
          Esci
        </button>
      </header>

      <nav className="flex gap-1 overflow-x-auto px-3 pb-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`chip shrink-0 ${tab === t.id ? "chip-active" : ""}`}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="px-3">
        {tab === "dashboard" && user.role === "dirigente" ? <DirigenteStats /> : null}
        {tab === "menu" && user.role === "dirigente" ? (
          <MenuEditor role={user.role} />
        ) : null}
        {tab === "soluzioni" && user.role === "dirigente" ? (
          <SolutionsEditor role={user.role} />
        ) : null}
        {tab === "team" && user.role === "dirigente" ? (
          <TeamManager role={user.role} />
        ) : null}
        {tab === "cucina" ? <KitchenBoard role={user.role} /> : null}
        {tab === "cassa" ? <CashierBoard role={user.role} /> : null}
        {tab === "ordini" ? <WaiterBoard user={user} /> : null}
        {tab === "sala" ? (
          <Console pin={pin} scannedCode={scannedCode} onLock={onLogout} />
        ) : null}
        {tab === "chat" ? <StaffChat user={user} /> : null}
      </div>
    </div>
  );
}

/* ===================== DIRIGENTE ===================== */

function DirigenteStats() {
  const stats = useQuery({
    queryKey: ["ops-stats"],
    queryFn: () => opsStats({ data: { role: "dirigente" } }),
    refetchInterval: 15000,
  });
  const data = stats.data;
  const maxRev = Math.max(1, ...(data?.byDay.map((d) => d.revenue) ?? [1]));

  return (
    <div className="space-y-4">
      <section className="bento-dark p-4">
        <p className="text-[10px] tracking-[0.2em] text-white/50 uppercase">
          Andamento 7 giorni
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-white/8 p-3">
            <p className="text-[18px] font-semibold text-white">
              € {(data?.totalRevenue ?? 0).toFixed(2)}
            </p>
            <p className="text-[10px] text-white/50 uppercase">Guadagni</p>
          </div>
          <div className="rounded-xl bg-white/8 p-3">
            <p className="text-[18px] font-semibold text-white">
              {data?.totalOrders ?? 0}
            </p>
            <p className="text-[10px] text-white/50 uppercase">Piatti pagati</p>
          </div>
        </div>
        <div className="mt-4 flex items-end gap-1.5">
          {(data?.byDay ?? []).map((d) => (
            <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
              <div
                className="w-full rounded-t bg-mint/80"
                style={{
                  height: `${Math.max(4, (d.revenue / maxRev) * 64)}px`,
                }}
                title={`€ ${d.revenue.toFixed(0)}`}
              />
              <span className="text-[9px] text-white/40">
                {d.date.slice(8)}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Piatti più ordinati
        </p>
        <div className="mt-3 divide-y divide-border">
          {(data?.topDishes ?? []).length === 0 ? (
            <p className="py-3 text-[12px] text-muted-foreground">
              Nessun pagamento ancora. Quando il cassiere chiude i tavoli, compaiono qui.
            </p>
          ) : (
            data!.topDishes.map((d) => (
              <div
                key={d.name}
                className="flex items-center justify-between gap-2 py-2 text-[13px]"
              >
                <span className="truncate font-medium">{d.name}</span>
                <span className="shrink-0 text-muted-foreground">
                  ×{d.qty} · € {d.revenue.toFixed(0)}
                </span>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}


function SolutionsEditor({ role }: { role: string }) {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["ops-solutions"],
    queryFn: () => opsListSolutions({ data: { activeOnly: false } }),
  });
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  const save = useMutation({
    mutationFn: () =>
      opsSaveSolution({
        data: { role, title, description, price, active: true },
      }),
    onSuccess: () => {
      setTitle("");
      setDescription("");
      setPrice("");
      setMsg("Soluzione aggiunta");
      qc.invalidateQueries({ queryKey: ["ops-solutions"] });
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => opsDeleteSolution({ data: { role, id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ops-solutions"] }),
  });

  return (
    <div className="space-y-4">
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Aggiungi soluzione
        </p>
        <div className="mt-3 space-y-2">
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Titolo"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Descrizione"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Prezzo (es. 55 €)"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
          <button
            type="button"
            className="btn-ink w-full py-2.5 text-[13px]"
            disabled={!title.trim() || save.isPending}
            onClick={() => save.mutate()}
          >
            Pubblica soluzione
          </button>
          {msg ? <p className="text-[12px] text-mint">{msg}</p> : null}
        </div>
      </section>
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Soluzioni attive
        </p>
        <div className="mt-2 divide-y divide-border">
          {(list.data?.solutions ?? []).map((s) => (
            <div key={s.id} className="flex items-start justify-between gap-2 py-3">
              <div className="min-w-0">
                <p className="text-[13px] font-medium">{s.title}</p>
                <p className="text-[11px] text-muted-foreground">{s.description}</p>
                <p className="mt-1 text-[12px] text-wine">{s.price}</p>
              </div>
              <button
                type="button"
                className="text-[11px] text-destructive underline"
                onClick={() => del.mutate(s.id)}
              >
                Elimina
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function MenuEditor({ role }: { role: string }) {
  const qc = useQueryClient();
  const menuQ = useQuery({
    queryKey: ["ops-menu"],
    queryFn: () => opsGetMenu(),
  });
  const [section, setSection] = useState("Primi");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("10");
  const [desc, setDesc] = useState("");

  const save = useMutation({
    mutationFn: () =>
      opsSaveMenuItem({
        data: {
          role,
          section,
          name,
          price: Number(price.replace(",", ".")) || 0,
          desc,
          available: true,
        },
      }),
    onSuccess: () => {
      setName("");
      setDesc("");
      qc.invalidateQueries({ queryKey: ["ops-menu"] });
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => opsDeleteMenuItem({ data: { role, id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ops-menu"] }),
  });

  const sections = [...new Set((menuQ.data?.menu ?? []).map((m) => m.section))];

  return (
    <div className="space-y-4">
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Modifica menu
        </p>
        <div className="mt-3 space-y-2">
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Sezione (es. Primi)"
            value={section}
            onChange={(e) => setSection(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Nome piatto"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Prezzo"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Descrizione (opz.)"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
          />
          <button
            type="button"
            disabled={!name.trim() || save.isPending}
            onClick={() => save.mutate()}
            className="btn-ink w-full py-2.5 text-[13px]"
          >
            Aggiungi al menu
          </button>
        </div>
      </section>
      {sections.map((sec) => (
        <section key={sec} className="bento p-4">
          <p className="text-[12px] font-semibold text-wine">{sec}</p>
          <div className="mt-2 divide-y divide-border">
            {(menuQ.data?.menu ?? [])
              .filter((m) => m.section === sec)
              .map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between gap-2 py-2 text-[13px]"
                >
                  <div className="min-w-0">
                    <p className="font-medium">{m.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      € {m.price}
                      {m.desc ? ` · ${m.desc}` : ""}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="text-[11px] text-destructive underline"
                    onClick={() => del.mutate(m.id)}
                  >
                    Elimina
                  </button>
                </div>
              ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function TeamManager({ role }: { role: string }) {
  const qc = useQueryClient();
  const team = useQuery({
    queryKey: ["ops-team"],
    queryFn: () => staffListUsers({ data: { role } }),
  });
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [newRole, setNewRole] =
    useState<"dirigente" | "cuoco" | "cassiere" | "cameriere">("cameriere");
  const [msg, setMsg] = useState<string | null>(null);

  const create = useMutation({
    mutationFn: () =>
      staffCreateUser({
        data: { role, username, password, name, newRole },
      }),
    onSuccess: () => {
      setMsg("Account creato");
      setUsername("");
      setPassword("");
      setName("");
      qc.invalidateQueries({ queryKey: ["ops-team"] });
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const toggle = useMutation({
    mutationFn: (p: { userId: string; active: boolean }) =>
      staffToggleUser({ data: { role, ...p } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ops-team"] }),
  });

  return (
    <div className="space-y-4">
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Crea account dipendente
        </p>
        <div className="mt-3 space-y-2">
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Nome visualizzato"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            className="field w-full px-3 py-2 text-[13px]"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <select
            className="field w-full px-3 py-2 text-[13px]"
            value={newRole}
            onChange={(e) => setNewRole(e.target.value as typeof newRole)}
          >
            <option value="dirigente">Dirigente</option>
            <option value="cuoco">Cuoco</option>
            <option value="cassiere">Cassiere</option>
            <option value="cameriere">Cameriere</option>
          </select>
          <button
            type="button"
            className="btn-ink w-full py-2.5 text-[13px]"
            onClick={() => create.mutate()}
          >
            Crea account
          </button>
          {msg ? <p className="text-[12px] text-mint">{msg}</p> : null}
        </div>
      </section>
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Team
        </p>
        <div className="mt-2 divide-y divide-border">
          {(team.data?.staff ?? []).map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between gap-2 py-2 text-[13px]"
            >
              <div>
                <p className="font-medium">
                  {s.name}{" "}
                  <span className="text-[11px] text-muted-foreground">@{s.username}</span>
                </p>
                <p className="text-[11px] text-muted-foreground">{s.role}</p>
              </div>
              <button
                type="button"
                className="chip"
                onClick={() => toggle.mutate({ userId: s.id, active: !s.active })}
              >
                {s.active ? "Attivo" : "Disattivo"}
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ===================== CUCINA ===================== */

function KitchenBoard({ role }: { role: string }) {
  const qc = useQueryClient();
  const orders = useQuery({
    queryKey: ["ops-kitchen"],
    queryFn: () => opsListOrders({ data: { role, kitchen: true } }),
    refetchInterval: 4000,
  });

  const setStatus = useMutation({
    mutationFn: (p: { orderId: string; status: "preparing" | "ready" }) =>
      opsSetOrderStatus({ data: { role, ...p } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ops-kitchen"] }),
  });

  const readyCount = (orders.data?.orders ?? []).filter((o) => o.status === "ready").length;
  const pending = (orders.data?.orders ?? []).filter((o) =>
    ["pending", "preparing"].includes(o.status),
  );

  useEffect(() => {
    if (readyCount > 0 && typeof Notification !== "undefined") {
      if (Notification.permission === "granted") {
        /* silent poll - visual badge below */
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission().catch(() => {});
      }
    }
  }, [readyCount]);

  return (
    <div className="space-y-3">
      {readyCount > 0 ? (
        <div className="rounded-xl bg-mint/15 px-4 py-3 text-[13px] font-medium text-mint shadow-[0_0_0_1px_color-mix(in_oklab,var(--mint)_30%,transparent)]">
          🔔 {readyCount} piatto/i pronti da servire
        </div>
      ) : null}
      {pending.length === 0 ? (
        <p className="bento p-4 text-[13px] text-muted-foreground">
          Nessun ordine in cucina al momento.
        </p>
      ) : (
        pending.map((o) => (
          <div key={o.id} className="bento p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-[15px] font-semibold">
                  {o.qty}× {o.dishName}
                </p>
                <p className="text-[12px] text-muted-foreground">
                  Tavolo {o.tableLabel}
                  {o.mods ? ` · ${o.mods}` : ""}
                </p>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  da {o.createdBy} · {o.status}
                </p>
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              {o.status === "pending" ? (
                <button
                  type="button"
                  className="btn-ink flex-1 py-2 text-[12px]"
                  onClick={() =>
                    setStatus.mutate({ orderId: o.id, status: "preparing" })
                  }
                >
                  In preparazione
                </button>
              ) : null}
              <button
                type="button"
                className="chip flex-1 text-center"
                onClick={() => setStatus.mutate({ orderId: o.id, status: "ready" })}
              >
                ✅ Pronto
              </button>
            </div>
          </div>
        ))
      )}
      {(orders.data?.orders ?? []).filter((o) => o.status === "ready").length > 0 ? (
        <section className="bento p-4">
          <p className="text-[10px] font-semibold tracking-[0.2em] text-mint uppercase">
            Pronti
          </p>
          {(orders.data?.orders ?? [])
            .filter((o) => o.status === "ready")
            .map((o) => (
              <p key={o.id} className="mt-2 text-[13px]">
                {o.qty}× {o.dishName} → tavolo {o.tableLabel}
              </p>
            ))}
        </section>
      ) : null}
    </div>
  );
}

/* ===================== CASSA ===================== */

function CashierBoard({ role }: { role: string }) {
  const qc = useQueryClient();
  const menuQ = useQuery({ queryKey: ["ops-menu"], queryFn: () => opsGetMenu() });
  const [tableId, setTableId] = useState<number | null>(null);

  const bill = useQuery({
    queryKey: ["ops-bill", tableId],
    queryFn: () => opsTableBill({ data: { role, tableId: tableId! } }),
    enabled: tableId != null,
    refetchInterval: 5000,
  });

  const pay = useMutation({
    mutationFn: () => opsPayTable({ data: { role, tableId: tableId! } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["ops-bill"] });
      qc.invalidateQueries({ queryKey: ["ops-stats"] });
    },
  });

  return (
    <div className="space-y-3">
      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Seleziona tavolo
        </p>
        <div className="mt-3 grid grid-cols-4 gap-2">
          {(menuQ.data?.tables ?? []).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTableId(t.id)}
              className={`rounded-xl px-2 py-3 text-[12px] font-medium shadow-[0_0_0_1px_var(--color-border)] ${
                tableId === t.id ? "bg-wine/15 text-wine" : "bg-card"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </section>
      {tableId != null ? (
        <section className="bento p-4">
          <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
            Conto tavolo
          </p>
          <div className="mt-2 divide-y divide-border">
            {(bill.data?.items ?? []).length === 0 ? (
              <p className="py-3 text-[12px] text-muted-foreground">Nessun ordine aperto</p>
            ) : (
              bill.data!.items.map((o) => (
                <div
                  key={o.id}
                  className="flex justify-between gap-2 py-2 text-[13px]"
                >
                  <span>
                    {o.qty}× {o.dishName}
                    {o.mods ? (
                      <span className="block text-[11px] text-muted-foreground">
                        {o.mods}
                      </span>
                    ) : null}
                  </span>
                  <span className="tabular-nums">
                    € {(o.basePrice * o.qty).toFixed(2)}
                  </span>
                </div>
              ))
            )}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
            <span className="text-[15px] font-semibold">Totale</span>
            <span className="text-[18px] font-semibold tabular-nums">
              € {(bill.data?.total ?? 0).toFixed(2)}
            </span>
          </div>
          <button
            type="button"
            disabled={!bill.data?.items.length || pay.isPending}
            onClick={() => {
              if (confirm("Segnare il tavolo come pagato?")) pay.mutate();
            }}
            className="btn-ink mt-3 w-full py-3 text-[14px]"
          >
            {pay.isPending ? "…" : "Incassa e chiudi tavolo"}
          </button>
        </section>
      ) : null}
    </div>
  );
}

/* ===================== CAMERIERE ===================== */

function WaiterBoard({ user }: { user: StaffSession }) {
  const qc = useQueryClient();
  const menuQ = useQuery({ queryKey: ["ops-menu"], queryFn: () => opsGetMenu() });
  const [tableId, setTableId] = useState<number | null>(null);
  const [mods, setMods] = useState("");
  const [qty, setQty] = useState(1);
  const [selectedDish, setSelectedDish] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const table = (menuQ.data?.tables ?? []).find((t) => t.id === tableId);
  const dish = (menuQ.data?.menu ?? []).find((m) => m.id === selectedDish);

  const kitchen = useQuery({
    queryKey: ["ops-kitchen-w"],
    queryFn: () => opsListOrders({ data: { role: user.role, kitchen: true } }),
    refetchInterval: 4000,
  });

  const add = useMutation({
    mutationFn: () =>
      opsAddOrder({
        data: {
          role: user.role,
          userName: user.name,
          tableId: tableId!,
          tableLabel: table!.label,
          dishId: dish!.id,
          dishName: dish!.name,
          basePrice: dish!.price,
          qty,
          mods,
        },
      }),
    onSuccess: () => {
      setNote("Ordine inviato in cucina");
      setMods("");
      setQty(1);
      setSelectedDish(null);
      qc.invalidateQueries({ queryKey: ["ops-kitchen-w"] });
      qc.invalidateQueries({ queryKey: ["ops-bill"] });
    },
    onError: (e: Error) => setNote(e.message),
  });

  const serve = useMutation({
    mutationFn: (orderId: string) =>
      opsSetOrderStatus({
        data: { role: user.role, orderId, status: "served" },
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ops-kitchen-w"] }),
  });

  const ready = (kitchen.data?.orders ?? []).filter((o) => o.status === "ready");

  const bySection = useMemo(() => {
    const map = new Map<string, typeof menuQ.data extends undefined ? never[] : NonNullable<typeof menuQ.data>["menu"]>();
    for (const m of menuQ.data?.menu ?? []) {
      if (!m.available) continue;
      const list = map.get(m.section) ?? [];
      list.push(m);
      map.set(m.section, list);
    }
    return map;
  }, [menuQ.data]);

  return (
    <div className="space-y-3">
      {ready.length > 0 ? (
        <section className="rounded-xl bg-mint/15 p-4">
          <p className="text-[12px] font-semibold text-mint">
            🔔 Piatti pronti ({ready.length})
          </p>
          {ready.map((o) => (
            <div
              key={o.id}
              className="mt-2 flex items-center justify-between gap-2 text-[13px]"
            >
              <span>
                {o.qty}× {o.dishName} → {o.tableLabel}
              </span>
              <button
                type="button"
                className="chip"
                onClick={() => serve.mutate(o.id)}
              >
                Servito
              </button>
            </div>
          ))}
        </section>
      ) : null}

      <section className="bento p-4">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Tavolo
        </p>
        <div className="mt-2 grid grid-cols-4 gap-2">
          {(menuQ.data?.tables ?? []).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTableId(t.id)}
              className={`rounded-xl py-3 text-[12px] font-medium shadow-[0_0_0_1px_var(--color-border)] ${
                tableId === t.id ? "bg-wine/15 text-wine" : ""
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </section>

      {tableId != null ? (
        <section className="bento p-4">
          <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
            Menu → {table?.label}
          </p>
          {[...bySection.entries()].map(([sec, items]) => (
            <div key={sec} className="mt-3">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase">
                {sec}
              </p>
              <div className="mt-1 space-y-1">
                {items.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedDish(m.id)}
                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-[13px] ${
                      selectedDish === m.id ? "bg-wine/10" : "hover:bg-card"
                    }`}
                  >
                    <span>{m.name}</span>
                    <span className="text-muted-foreground">
                      {m.price > 0 ? `€ ${m.price}` : "su rich."}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ))}

          {dish ? (
            <div className="mt-4 space-y-2 border-t border-border pt-3">
              <p className="text-[13px] font-medium">{dish.name}</p>
              <label className="field flex flex-col px-3 py-2">
                <span className="text-[10px] text-muted-foreground uppercase">
                  Aggiunte / da levare
                </span>
                <input
                  value={mods}
                  onChange={(e) => setMods(e.target.value)}
                  placeholder="es. senza cipolla, extra formaggio"
                  className="bg-transparent text-[13px] outline-none"
                />
              </label>
              <label className="field flex flex-col px-3 py-2">
                <span className="text-[10px] text-muted-foreground uppercase">Qtà</span>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={qty}
                  onChange={(e) => setQty(Number(e.target.value) || 1)}
                  className="bg-transparent text-[13px] outline-none"
                />
              </label>
              <button
                type="button"
                className="btn-ink w-full py-2.5 text-[13px]"
                disabled={add.isPending}
                onClick={() => add.mutate()}
              >
                Invia in cucina
              </button>
            </div>
          ) : null}
          {note ? <p className="mt-2 text-[12px] text-mint">{note}</p> : null}
        </section>
      ) : null}
    </div>
  );
}

/* ===================== CHAT ===================== */

function StaffChat({ user }: { user: StaffSession }) {
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const [toId, setToId] = useState("all");

  const team = useQuery({
    queryKey: ["ops-team-chat"],
    queryFn: () => staffListUsers({ data: { role: "dirigente" } }),
    // cameriere might fail — fallback empty
    retry: false,
  });

  const msgs = useQuery({
    queryKey: ["ops-chat", user.id],
    queryFn: () => opsListMessages({ data: { userId: user.id } }),
    refetchInterval: 3000,
  });

  const send = useMutation({
    mutationFn: () =>
      opsSendMessage({
        data: {
          fromId: user.id,
          fromName: user.name,
          toId,
          text,
        },
      }),
    onSuccess: () => {
      setText("");
      qc.invalidateQueries({ queryKey: ["ops-chat"] });
    },
  });

  return (
    <div className="bento flex h-[70vh] flex-col p-4">
      <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
        Chat staff
      </p>
      <div className="mt-3 min-h-0 flex-1 space-y-2 overflow-y-auto">
        {(msgs.data?.messages ?? []).map((m) => (
          <div
            key={m.id}
            className={`max-w-[85%] rounded-xl px-3 py-2 text-[13px] ${
              m.fromId === user.id
                ? "ml-auto bg-wine/15"
                : "bg-card shadow-[0_0_0_1px_var(--color-border)]"
            }`}
          >
            <p className="text-[10px] font-medium text-muted-foreground">
              {m.fromName}
              {m.toId !== "all" ? " → privato" : ""}
            </p>
            <p>{m.text}</p>
          </div>
        ))}
      </div>
      <div className="mt-3 space-y-2 border-t border-border pt-3">
        <select
          className="field w-full px-3 py-2 text-[12px]"
          value={toId}
          onChange={(e) => setToId(e.target.value)}
        >
          <option value="all">Tutti</option>
          {(team.data?.staff ?? [])
            .filter((s) => s.id !== user.id)
            .map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.role})
              </option>
            ))}
        </select>
        <div className="flex gap-2">
          <input
            className="field flex-1 px-3 py-2 text-[13px]"
            placeholder="Messaggio…"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && text.trim()) send.mutate();
            }}
          />
          <button
            type="button"
            className="btn-ink px-4 py-2 text-[13px]"
            disabled={!text.trim() || send.isPending}
            onClick={() => send.mutate()}
          >
            Invia
          </button>
        </div>
      </div>
    </div>
  );
}

/* ===================== SALA legacy (prenotazioni) ===================== */


const STATUS_TONE: Record<FloorTable["status"], { dot: string; text: string }> = {
  free: { dot: "bg-mint/25 ring-mint/50", text: "libero" },
  reserved: { dot: "bg-amber/25 ring-amber/50", text: "in arrivo" },
  seated: { dot: "bg-wine/25 ring-wine/50", text: "in sala" },
};

function Console({
  pin,
  scannedCode,
  onLock,
}: {
  pin: string;
  scannedCode: string | null;
  onLock?: () => void;
}) {
  const queryClient = useQueryClient();
  const week = nextDays(7);
  const [date, setDate] = useState(toISODate(new Date()));
  const [selected, setSelected] = useState<FloorTable | null>(null);
  const [lookup, setLookup] = useState(scannedCode ?? "");
  const [message, setMessage] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [scanning, setScanning] = useState(false);

  // Form nuova prenotazione
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [newAdults, setNewAdults] = useState(2);
  const [newChildren, setNewChildren] = useState(0);
  const [newTime, setNewTime] = useState(LUNCH_SLOTS[2] ?? "12:00");

  // Form modifica
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editAdults, setEditAdults] = useState(2);
  const [editChildren, setEditChildren] = useState(0);
  const [editTime, setEditTime] = useState("");

  const day = useQuery({
    queryKey: ["staff-day", pin, date],
    queryFn: () => getStaffDay({ data: { pin, date } }),
  });

  const updateStatus = useMutation({
    mutationFn: (input: { code: string; status: string }) =>
      setReservationStatus({ data: { pin, ...input } }),
    onSuccess: (_result, input) => {
      setMessage(
        input.status === "seated"
          ? `${input.code} accolto in sala`
          : `${input.code} aggiornato`,
      );
      queryClient.invalidateQueries({ queryKey: ["staff-day"] });
    },
    onError: (err: Error) => setMessage(err.message),
  });

  const createRes = useMutation({
    mutationFn: () =>
      staffCreateReservation({
        data: {
          pin,
          date,
          time: newTime,
          adults: newAdults,
          children: newChildren,
          guestName: newName,
          phone: newPhone,
        },
      }),
    onSuccess: (ticket) => {
      setMessage(`Creata ${ticket.code} — ${ticket.guestName}`);
      setShowAdd(false);
      setNewName("");
      setNewPhone("");
      setNewAdults(2);
      setNewChildren(0);
      queryClient.invalidateQueries({ queryKey: ["staff-day"] });
    },
    onError: (err: Error) => setMessage(err.message),
  });

  const deleteRes = useMutation({
    mutationFn: (code: string) =>
      staffDeleteReservation({ data: { pin, code } }),
    onSuccess: (_r, code) => {
      setMessage(`Eliminata ${code}`);
      setLookup("");
      setEditMode(false);
      queryClient.invalidateQueries({ queryKey: ["staff-day"] });
    },
    onError: (err: Error) => setMessage(err.message),
  });

  const updateRes = useMutation({
    mutationFn: (code: string) =>
      staffUpdateReservation({
        data: {
          pin,
          code,
          guestName: editName || undefined,
          phone: editPhone || undefined,
          adults: editAdults,
          children: editChildren,
          time: editTime || undefined,
        },
      }),
    onSuccess: (_r, code) => {
      setMessage(`Modificata ${code}`);
      setEditMode(false);
      queryClient.invalidateQueries({ queryKey: ["staff-day"] });
    },
    onError: (err: Error) => setMessage(err.message),
  });

  const csv = useMutation({
    mutationFn: () => exportDayCsv({ data: { pin, date } }),
    onSuccess: (result) => {
      const blob = new Blob([result.csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `piano-liguori-${date}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    },
  });

  useEffect(() => {
    if (scannedCode) {
      setLookup(scannedCode);
      setMessage(`Ticket ${scannedCode} rilevato`);
    }
  }, [scannedCode]);

  // QR scanner: BarcodeDetector se disponibile, altrimenti html5-qrcode (CDN)
  useEffect(() => {
    if (!scanning) return;

    let stopped = false;
    let stream: MediaStream | null = null;
    let anim = 0;
    let html5Scanner: { stop: () => Promise<void> } | null = null;

    const extractCode = (raw: string) => {
      const match =
        raw.match(/PL-[A-Z0-9]{4}/i) || raw.match(/code=([A-Z0-9-]{4,12})/i);
      if (!match) return raw.slice(0, 12).toUpperCase();
      return (match[0].startsWith("PL") ? match[0] : match[1]!).toUpperCase();
    };

    const onCode = (raw: string) => {
      if (stopped) return;
      const code = extractCode(raw);
      setLookup(code);
      setMessage(`QR scansionato: ${code}`);
      setScanning(false);
    };

    const startBarcodeDetector = async () => {
      const detector = new (window as any).BarcodeDetector({ formats: ["qr_code"] });
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      const video = document.getElementById("qr-video") as HTMLVideoElement | null;
      if (!video) throw new Error("video missing");
      video.srcObject = stream;
      await video.play();

      const tick = async () => {
        if (stopped || !video) return;
        try {
          const codes = await detector.detect(video);
          if (codes.length > 0) {
            onCode(codes[0].rawValue as string);
            return;
          }
        } catch {
          /* ignore frame errors */
        }
        anim = requestAnimationFrame(tick);
      };
      anim = requestAnimationFrame(tick);
    };

    const loadScript = (src: string) =>
      new Promise<void>((resolve, reject) => {
        const existing = document.querySelector(`script[src="${src}"]`);
        if (existing) {
          resolve();
          return;
        }
        const script = document.createElement("script");
        script.src = src;
        script.async = true;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error("script load failed"));
        document.head.appendChild(script);
      });

    const startHtml5Qrcode = async () => {
      await loadScript("https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js");
      if (stopped) return;
      const Html5Qrcode = (window as any).Html5Qrcode;
      if (!Html5Qrcode) throw new Error("Html5Qrcode missing");

      const scanner = new Html5Qrcode("qr-reader");
      html5Scanner = scanner;
      await scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 240, height: 240 } },
        (decoded: string) => onCode(decoded),
        () => {},
      );
    };

    const start = async () => {
      try {
        if ("BarcodeDetector" in window) {
          await startBarcodeDetector();
          return;
        }
        await startHtml5Qrcode();
      } catch (err) {
        console.error(err);
        try {
          // Secondo tentativo con html5-qrcode anche se BarcodeDetector ha fallito
          if (!html5Scanner) await startHtml5Qrcode();
        } catch (err2) {
          console.error(err2);
          setMessage(
            "Impossibile usare la fotocamera. Digita il codice a mano oppure usa Chrome/Edge e consenti l'accesso alla camera.",
          );
          setScanning(false);
        }
      }
    };

    start();

    return () => {
      stopped = true;
      cancelAnimationFrame(anim);
      stream?.getTracks().forEach((t) => t.stop());
      html5Scanner?.stop().catch(() => {});
    };
  }, [scanning]);

  const floor = day.data?.floor ?? [];
  const stats = day.data?.stats;
  const reservations = day.data?.reservations ?? [];
  const matched = reservations.find(
    (r) => r.code.toUpperCase() === lookup.trim().toUpperCase(),
  );

  // Sync edit form when matched changes
  useEffect(() => {
    if (matched && editMode) {
      setEditName(matched.guestName);
      setEditPhone(matched.phone);
      setEditAdults(matched.adults);
      setEditChildren(matched.children);
      setEditTime(matched.time);
    }
  }, [matched?.code, editMode]);

  return (
    <div className="pb-6">
      <section className="px-0">
        <div className="bento-dark p-4">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <p className="truncate text-[10px] font-medium tracking-[0.2em] text-white/50 uppercase">
              Sala · {formatDateIt(date)}
            </p>
            <div className="flex shrink-0 items-center gap-3 text-[10px] text-white/80">
              <span className="flex items-center gap-1">
                <span className="size-2 rounded-full bg-mint" />
                libero
              </span>
              <span className="flex items-center gap-1">
                <span className="size-2 rounded-full bg-wine" />
                in sala
              </span>
              <span className="flex items-center gap-1">
                <span className="size-2 rounded-full bg-amber" />
                in arrivo
              </span>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-4 gap-3">
            {floor.map((table) => (
              <button
                key={table.id}
                type="button"
                onClick={() => setSelected(table)}
                className={`flex flex-col justify-between rounded-2xl bg-white/8 p-3 text-left shadow-[0_0_0_1px_rgb(255_255_255/0.1)] transition-transform hover:-translate-y-0.5 ${
                  table.span > 1 ? "col-span-2" : ""
                }`}
              >
                <div
                  className={`${table.span > 1 ? "size-9" : "size-7"} rounded-full ring-1 ${STATUS_TONE[table.status].dot}`}
                />
                <p className="mt-2 truncate text-[11px] font-medium">{table.label}</p>
                <p className="truncate text-[9px] text-white/50">
                  {table.guestName
                    ? `${table.guestName} · ${table.guestCount}`
                    : `${table.capacity} posti`}
                </p>
              </button>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-4 gap-2">
            <Metric value={stats?.tablesBooked ?? 0} label="tavoli" />
            <Metric value={stats?.covers ?? 0} label="coperti" />
            <Metric value={`${stats?.occupancy ?? 0}%`} label="occup." />
            <Metric value={stats?.children ?? 0} label="bambini" />
          </div>

          <div className="mt-3 flex items-center justify-between gap-2">
            <div className="flex min-w-0 gap-1 overflow-x-auto">
              {week.map((day7) => (
                <button
                  key={day7}
                  type="button"
                  onClick={() => setDate(day7)}
                  className={`shrink-0 rounded-md px-2 py-1 text-[10px] font-medium transition-colors ${
                    day7 === date ? "bg-white/15 text-white" : "text-white/40"
                  }`}
                >
                  {formatWeekdayShort(day7)}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => csv.mutate()}
              className="shrink-0 rounded-lg bg-white/90 px-3 py-1.5 text-[11px] font-medium text-ink"
            >
              CSV ↓
            </button>
          </div>

          <div className="mt-3 grid grid-cols-7 gap-1">
            {(day.data?.week ?? []).map((entry) => (
              <div key={entry.date} className="text-center">
                <div
                  className="mx-auto w-2 rounded-full bg-white/35"
                  style={{ height: `${Math.min(28, 4 + entry.covers)}px` }}
                />
                <p className="mt-1 text-[9px] text-white/40">{entry.covers}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bento mx-4 mt-6 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Accoglienza QR
        </p>
        <h2 className="mt-1 text-[20px] leading-tight font-semibold">
          Scansiona o digita il codice
        </h2>

        {scanning ? (
          <div className="mt-3 overflow-hidden rounded-xl bg-ink p-2">
            <video
              id="qr-video"
              className="aspect-video w-full object-cover rounded-lg"
              playsInline
              muted
            />
            <div id="qr-reader" className="w-full overflow-hidden rounded-lg" />
            <p className="mt-2 px-1 text-center text-[11px] text-white/60">
              Inquadra il QR del ticket. Se non parte, digita il codice sotto.
            </p>
            <button
              type="button"
              onClick={() => setScanning(false)}
              className="btn-ink mt-2 w-full py-2 text-[12px]"
            >
              Chiudi scanner
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => {
              setMessage(null);
              setScanning(true);
            }}
            className="chip mt-3 w-full py-2.5 text-center"
          >
            📷 Avvia scansione QR
          </button>
        )}

        <label className="field mt-3 flex flex-col px-3 py-2.5">
          <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
            Codice ticket
          </span>
          <input
            value={lookup}
            onChange={(event) => {
              setLookup(event.target.value.toUpperCase().slice(0, 12));
              setEditMode(false);
            }}
            placeholder="PL-7Q4X"
            className="bg-transparent text-[15px] font-medium tracking-wide outline-none placeholder:text-muted-foreground/60"
          />
        </label>

        {matched ? (
          <div className="rise mt-3 rounded-xl bg-card p-3 shadow-[0_0_0_1px_var(--color-border)]">
            {!editMode ? (
              <>
                <p className="text-[13px] font-medium">
                  {matched.guestName} · {matched.tables.join(" + ")}
                </p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">
                  {matched.time} · {matched.adults} adulti · {matched.children} bambini ·{" "}
                  {matched.status === "seated" ? "in sala" : "in attesa"}
                </p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">{matched.phone}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      updateStatus.mutate({ code: matched.code, status: "seated" })
                    }
                    className="btn-ink flex-1 py-2 text-[12px]"
                  >
                    Conferma arrivo
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditName(matched.guestName);
                      setEditPhone(matched.phone);
                      setEditAdults(matched.adults);
                      setEditChildren(matched.children);
                      setEditTime(matched.time);
                      setEditMode(true);
                    }}
                    className="chip flex-1 text-center"
                  >
                    Modifica
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Eliminare definitivamente ${matched.code}?`)) {
                        deleteRes.mutate(matched.code);
                      }
                    }}
                    className="chip flex-1 text-center text-destructive"
                  >
                    Elimina
                  </button>
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <p className="text-[12px] font-medium text-wine">Modifica {matched.code}</p>
                <label className="field flex flex-col px-3 py-2">
                  <span className="text-[10px] text-muted-foreground uppercase">Nome</span>
                  <input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="bg-transparent text-[13px] outline-none"
                  />
                </label>
                <label className="field flex flex-col px-3 py-2">
                  <span className="text-[10px] text-muted-foreground uppercase">Telefono</span>
                  <input
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="bg-transparent text-[13px] outline-none"
                  />
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <label className="field flex flex-col px-3 py-2">
                    <span className="text-[10px] text-muted-foreground uppercase">Adulti</span>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={editAdults}
                      onChange={(e) => setEditAdults(Number(e.target.value) || 1)}
                      className="bg-transparent text-[13px] outline-none"
                    />
                  </label>
                  <label className="field flex flex-col px-3 py-2">
                    <span className="text-[10px] text-muted-foreground uppercase">Bambini</span>
                    <input
                      type="number"
                      min={0}
                      max={10}
                      value={editChildren}
                      onChange={(e) => setEditChildren(Number(e.target.value) || 0)}
                      className="bg-transparent text-[13px] outline-none"
                    />
                  </label>
                </div>
                <label className="field flex flex-col px-3 py-2">
                  <span className="text-[10px] text-muted-foreground uppercase">Orario</span>
                  <select
                    value={editTime}
                    onChange={(e) => setEditTime(e.target.value)}
                    className="bg-transparent text-[13px] outline-none"
                  >
                    {ALL_SLOTS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => updateRes.mutate(matched.code)}
                    disabled={updateRes.isPending}
                    className="btn-ink flex-1 py-2 text-[12px]"
                  >
                    {updateRes.isPending ? "Salvo…" : "Salva modifiche"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditMode(false)}
                    className="chip flex-1 text-center"
                  >
                    Annulla
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : lookup.trim().length > 2 ? (
          <p className="mt-3 text-[12px] text-muted-foreground">
            Nessuna prenotazione con questo codice per {formatDateIt(date)}.
          </p>
        ) : null}

        {message ? (
          <p className="mt-3 text-[12px] font-medium text-mint">{message}</p>
        ) : null}
      </section>

      <section className="bento mx-4 mt-6 p-5">
        <div className="flex items-center justify-between gap-2">
          <div>
            <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
              Prenotazioni
            </p>
            <h2 className="mt-1 text-[20px] leading-tight font-semibold">
              {formatDateIt(date)}
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setShowAdd((v) => !v)}
            className="btn-ink shrink-0 px-3 py-2 text-[12px]"
          >
            {showAdd ? "Chiudi" : "+ Aggiungi"}
          </button>
        </div>

        {showAdd ? (
          <div className="rise mt-4 space-y-2 rounded-xl bg-card p-3 shadow-[0_0_0_1px_var(--color-border)]">
            <p className="text-[12px] font-medium text-wine">Nuova prenotazione</p>
            <label className="field flex flex-col px-3 py-2">
              <span className="text-[10px] text-muted-foreground uppercase">Nome</span>
              <input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Mario Rossi"
                className="bg-transparent text-[13px] outline-none"
              />
            </label>
            <label className="field flex flex-col px-3 py-2">
              <span className="text-[10px] text-muted-foreground uppercase">Telefono</span>
              <input
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="333 000 0000"
                className="bg-transparent text-[13px] outline-none"
              />
            </label>
            <div className="grid grid-cols-3 gap-2">
              <label className="field flex flex-col px-3 py-2">
                <span className="text-[10px] text-muted-foreground uppercase">Adulti</span>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={newAdults}
                  onChange={(e) => setNewAdults(Number(e.target.value) || 1)}
                  className="bg-transparent text-[13px] outline-none"
                />
              </label>
              <label className="field flex flex-col px-3 py-2">
                <span className="text-[10px] text-muted-foreground uppercase">Bimbi</span>
                <input
                  type="number"
                  min={0}
                  max={10}
                  value={newChildren}
                  onChange={(e) => setNewChildren(Number(e.target.value) || 0)}
                  className="bg-transparent text-[13px] outline-none"
                />
              </label>
              <label className="field flex flex-col px-3 py-2">
                <span className="text-[10px] text-muted-foreground uppercase">Ora</span>
                <select
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="bg-transparent text-[13px] outline-none"
                >
                  {ALL_SLOTS.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <button
              type="button"
              disabled={
                newName.trim().length < 2 ||
                newPhone.trim().length < 6 ||
                createRes.isPending
              }
              onClick={() => createRes.mutate()}
              className="btn-ink mt-2 w-full py-2.5 text-[13px]"
            >
              {createRes.isPending ? "Creo…" : "Crea prenotazione"}
            </button>
          </div>
        ) : null}

        <div className="mt-3 divide-y divide-border">
          {reservations.length === 0 ? (
            <p className="py-3 text-[12px] text-muted-foreground">
              Nessuna prenotazione per questa data.
            </p>
          ) : (
            reservations.map((r) => (
              <div
                key={r.code}
                className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 py-2.5"
              >
                <span className="shrink-0 font-mono text-[12px] text-muted-foreground">
                  {r.time}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-medium">{r.guestName}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {r.tables.join(" + ")} · {r.adults + r.children} coperti · {r.phone} ·{" "}
                    <span className="font-mono">{r.code}</span>
                  </p>
                </div>
                <div className="flex shrink-0 flex-col gap-1">
                  <button
                    type="button"
                    onClick={() =>
                      updateStatus.mutate({
                        code: r.code,
                        status: r.status === "seated" ? "pending" : "seated",
                      })
                    }
                    className={`chip ${r.status === "seated" ? "chip-active" : ""}`}
                  >
                    {r.status === "seated" ? "In sala" : "Accogli"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLookup(r.code);
                      setEditMode(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="text-[10px] text-muted-foreground underline"
                  >
                    Dettagli
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {selected ? (
        <div
          className="fixed inset-0 z-50 flex items-end bg-ink/50 p-4"
          onClick={() => setSelected(null)}
        >
          <div
            className="bento rise w-full p-5"
            onClick={(event) => event.stopPropagation()}
          >
            <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
              {selected.zone}
            </p>
            <h3 className="mt-1 text-[22px] font-semibold">{selected.label}</h3>
            <p className="mt-1 text-[12px] text-muted-foreground">
              {selected.capacity} posti · {STATUS_TONE[selected.status].text}
            </p>
            {selected.guestName ? (
              <div className="mt-3 space-y-1 text-[13px]">
                <p className="font-medium">{selected.guestName}</p>
                <p className="text-muted-foreground">
                  {selected.time} · {selected.guestCount} coperti · {selected.code}
                </p>
              </div>
            ) : (
              <p className="mt-3 text-[13px] text-muted-foreground">
                Tavolo libero per questa data.
              </p>
            )}
            <button
              type="button"
              onClick={() => setSelected(null)}
              className="btn-ink mt-5 w-full py-2.5 text-[13px]"
            >
              Chiudi
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Metric({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="rounded-xl bg-white/6 px-3 py-2.5 shadow-[0_0_0_1px_rgb(255_255_255/0.1)]">
      <p className="text-[16px] font-semibold">{value}</p>
      <p className="text-[9px] tracking-wider text-white/45 uppercase">{label}</p>
    </div>
  );
}
