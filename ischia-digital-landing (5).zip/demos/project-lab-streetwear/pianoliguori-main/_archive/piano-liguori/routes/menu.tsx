import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { SiteHeader } from "@/components/SiteHeader";
import { MENU_NOTE, MENU_SECTIONS } from "@/data/menu";
import { opsGetMenu } from "@/lib/staff-ops.functions";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Piano Liguori" },
      {
        name: "description",
        content: "Menu del ristorante Piano Liguori: antipasti, primi, secondi e specialità ischitane.",
      },
    ],
  }),
  component: MenuPage,
});

function MenuPage() {
  const live = useQuery({
    queryKey: ["public-menu"],
    queryFn: () => opsGetMenu(),
    retry: 1,
  });

  const sectionsFromDb = (() => {
    const items = live.data?.menu?.filter((m) => m.available) ?? [];
    if (!items.length) return null;
    const map = new Map<string, typeof items>();
    for (const m of items) {
      const list = map.get(m.section) ?? [];
      list.push(m);
      map.set(m.section, list);
    }
    return [...map.entries()].map(([title, list]) => ({
      title,
      items: list.map((i) => ({
        name: i.name,
        price: i.price > 0 ? String(i.price) : "su richiesta",
        desc: i.desc,
      })),
    }));
  })();

  const sections = sectionsFromDb ?? MENU_SECTIONS;

  return (
    <div className="min-h-screen pb-16">
      <SiteHeader active="menu" />
      <main className="mx-auto max-w-lg px-4 py-6">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          La carta
        </p>
        <h1 className="mt-1 text-[28px] font-semibold leading-tight">Menu</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
          {MENU_NOTE}
        </p>

        <div className="mt-6 space-y-5">
          {sections.map((section) => (
            <section key={section.title} className="bento p-5">
              <p className="text-[11px] font-semibold tracking-[0.14em] text-wine uppercase">
                {section.title}
              </p>
              <ul className="mt-2 divide-y divide-border">
                {section.items.map((item) => (
                  <li
                    key={item.name}
                    className="flex items-start justify-between gap-3 py-2.5"
                  >
                    <div className="min-w-0">
                      <p className="text-[14px] font-medium">{item.name}</p>
                      {item.desc ? (
                        <p className="mt-0.5 text-[12px] text-muted-foreground">
                          {item.desc}
                        </p>
                      ) : null}
                    </div>
                    <span className="shrink-0 text-[14px] font-medium tabular-nums">
                      {item.price}
                      {/\d/.test(item.price) && !item.price.includes("€") ? " €" : ""}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        <div className="mt-8 flex flex-col gap-2">
          <Link to="/prenota" className="btn-ink block w-full py-3 text-center text-[14px]">
            Prenota un tavolo
          </Link>
          <Link to="/soluzioni" className="chip block w-full py-3 text-center">
            Vedi le soluzioni
          </Link>
        </div>
      </main>
    </div>
  );
}
