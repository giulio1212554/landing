/* PROJECT LAB service worker — static assets only, never API/HTML nav */
const CACHE = "plab-static-v2";
const STATIC = [
  "/manifest.webmanifest",
  "/logo-project-lab.jpg",
  "/favicon.ico",
  "/icon-192.png",
  "/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(STATIC).catch(() => undefined)),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))),
    ),
  );
  self.clients.claim();
});

function shouldBypass(url) {
  const p = url.pathname;
  if (p.startsWith("/api/")) return true;
  if (p.startsWith("/admin")) return true;
  if (p.includes("_server") || p.includes("serverFn")) return true;
  // TanStack server function posts
  if (url.searchParams.has("_serverFn") || p.includes("/_server")) return true;
  const accept = ""; // network decides
  return false;
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Never cache API, admin, or server functions
  if (
    url.pathname.startsWith("/api/") ||
    url.pathname.startsWith("/admin") ||
    url.pathname.includes("_server") ||
    url.pathname.includes("serverFn")
  ) {
    return; // network only
  }

  // Navigations: network-first, no offline HTML fallback that breaks JSON
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).catch(() =>
        new Response("Offline", {
          status: 503,
          headers: { "content-type": "text/plain" },
        }),
      ),
    );
    return;
  }

  // Static assets: cache-first
  if (
    url.pathname.startsWith("/assets/") ||
    STATIC.some((s) => url.pathname === s)
  ) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((res) => {
            const copy = res.clone();
            if (res.ok) {
              caches.open(CACHE).then((c) => c.put(req, copy));
            }
            return res;
          }),
      ),
    );
  }
});
