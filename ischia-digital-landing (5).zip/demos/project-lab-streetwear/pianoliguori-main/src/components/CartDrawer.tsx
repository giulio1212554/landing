import { Link } from "@tanstack/react-router";
import { X, Minus, Plus, Trash2 } from "lucide-react";
import {
  type CartItem,
  cartSubtotal,
  updateCartQty,
  removeFromCart,
} from "@/lib/cart";
import { loadSettings } from "@/lib/store";

type CartDrawerProps = {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
  onChange: () => void;
};

export function CartDrawer({ open, onClose, items, onChange }: CartDrawerProps) {
  if (!open) return null;

  const settings = loadSettings();
  const subtotal = cartSubtotal(items);
  const threshold = settings.freeShippingThreshold ?? 150;
  const remaining = Math.max(0, threshold - subtotal);
  const freeShip = subtotal >= threshold && subtotal > 0;
  const progress =
    threshold > 0 ? Math.min(100, (subtotal / threshold) * 100) : 100;

  const refresh = (next: CartItem[]) => {
    void next;
    onChange();
  };

  return (
    <div className="fixed inset-0 z-[60]">
      <button
        type="button"
        className="absolute inset-0 bg-black/70"
        aria-label="Chiudi carrello"
        onClick={onClose}
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-border bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-4">
          <h2 className="font-display text-sm font-bold uppercase tracking-widest">
            Carrello ({items.reduce((n, i) => n + i.qty, 0)})
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-muted-foreground hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {items.length > 0 && (
          <div className="border-b border-border px-4 py-3">
            <p className="text-[11px] text-muted-foreground">
              {freeShip
                ? "Spedizione gratuita sbloccata"
                : `Ancora €${remaining.toFixed(0)} per la spedizione gratuita`}
            </p>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-4 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <p className="text-sm text-muted-foreground">Il carrello è vuoto</p>
              <button
                type="button"
                onClick={onClose}
                className="mt-4 text-xs font-bold uppercase tracking-wider text-primary"
              >
                Continua lo shopping
              </button>
            </div>
          ) : (
            <ul className="space-y-4">
              {items.map((item) => (
                <li
                  key={`${item.productId}-${item.size}`}
                  className="flex gap-3 border-b border-border/50 pb-4"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium uppercase">
                      {item.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {item.size} · €{item.price}
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <button
                        type="button"
                        className="rounded border border-border p-1"
                        onClick={() => {
                          refresh(
                            updateCartQty(
                              item.productId,
                              item.size,
                              item.qty - 1,
                            ),
                          );
                        }}
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-6 text-center text-xs">{item.qty}</span>
                      <button
                        type="button"
                        className="rounded border border-border p-1"
                        onClick={() => {
                          refresh(
                            updateCartQty(
                              item.productId,
                              item.size,
                              item.qty + 1,
                            ),
                          );
                        }}
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        className="ml-auto p-1 text-muted-foreground hover:text-destructive"
                        onClick={() => {
                          refresh(removeFromCart(item.productId, item.size));
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-sm font-bold">
                    €{(item.price * item.qty).toFixed(0)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-border p-4">
            <div className="mb-3 flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotale</span>
              <span className="font-bold">€{subtotal.toFixed(2)}</span>
            </div>
            <Link
              to="/checkout"
              onClick={onClose}
              className="block w-full rounded-sm bg-primary py-3 text-center text-xs font-bold uppercase tracking-wider text-primary-foreground"
            >
              Checkout
            </Link>
          </div>
        )}
      </aside>
    </div>
  );
}
