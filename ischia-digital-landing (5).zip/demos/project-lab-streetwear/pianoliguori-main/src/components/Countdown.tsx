import { useEffect, useState } from "react";

type CountdownProps = {
  target: string; // ISO date or datetime-local
  className?: string;
  compact?: boolean;
};

function pad(n: number) {
  if (!Number.isFinite(n) || Number.isNaN(n)) return "00";
  return Math.max(0, Math.floor(n)).toString().padStart(2, "0");
}

/** Parse ISO, datetime-local, or common date strings safely */
export function parseDropDate(target: string | undefined | null): number | null {
  if (!target || typeof target !== "string") return null;
  const trimmed = target.trim();
  if (!trimmed) return null;

  // datetime-local: "2026-11-15T18:00" (no timezone) → treat as local
  let d = new Date(trimmed);
  if (!Number.isNaN(d.getTime())) return d.getTime();

  // "15/11/2026 18:00" or "15-11-2026"
  const m = trimmed.match(
    /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})(?:[ T](\d{1,2}):(\d{2}))?/,
  );
  if (m) {
    const day = Number(m[1]);
    const month = Number(m[2]) - 1;
    const year = Number(m[3]);
    const hour = Number(m[4] ?? 0);
    const min = Number(m[5] ?? 0);
    d = new Date(year, month, day, hour, min);
    if (!Number.isNaN(d.getTime())) return d.getTime();
  }

  return null;
}

export function Countdown({ target, className = "", compact = false }: CountdownProps) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const end = parseDropDate(target);

  if (end == null) {
    if (compact) {
      return (
        <span className={`font-mono text-muted-foreground ${className}`}>
          —:—:—
        </span>
      );
    }
    return (
      <div className={`flex items-center justify-center ${className}`}>
        <span className="text-xs uppercase tracking-wider text-muted-foreground">
          Data drop non impostata
        </span>
      </div>
    );
  }

  const past = end <= now;
  const diff = Math.max(0, end - now);

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  const secs = Math.floor((diff % 60000) / 1000);

  if (past) {
    if (compact) {
      return (
        <span
          className={`font-mono font-bold uppercase tracking-wider text-primary ${className}`}
        >
          LIVE
        </span>
      );
    }
    return (
      <div className={`flex items-center justify-center ${className}`}>
        <span className="font-display text-2xl font-bold uppercase tracking-[0.2em] text-primary sm:text-4xl">
          LIVE
        </span>
      </div>
    );
  }

  if (compact) {
    return (
      <span className={`font-mono tabular-nums ${className}`}>
        {pad(days)}d {pad(hours)}h {pad(mins)}m {pad(secs)}s
      </span>
    );
  }

  const blocks = [
    { label: "GG", value: days },
    { label: "ORE", value: hours },
    { label: "MIN", value: mins },
    { label: "SEC", value: secs },
  ];

  return (
    <div className={`flex gap-3 sm:gap-4 ${className}`}>
      {blocks.map((b) => (
        <div key={b.label} className="flex flex-col items-center">
          <span className="font-display text-2xl font-bold tabular-nums text-primary sm:text-4xl">
            {pad(b.value)}
          </span>
          <span className="mt-1 text-[10px] font-medium uppercase tracking-widest text-muted-foreground">
            {b.label}
          </span>
        </div>
      ))}
    </div>
  );
}
