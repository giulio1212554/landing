import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

type Props = {
  images: string[];
  alt: string;
  className?: string;
};

export function ProductCarousel({ images, alt, className = "" }: Props) {
  const list = images.filter(Boolean);
  const [i, setI] = useState(0);

  if (list.length === 0) {
    return (
      <div
        className={`flex aspect-[3/4] items-center justify-center bg-gradient-to-br from-charcoal to-background ${className}`}
      >
        <span className="font-display text-4xl font-bold text-border opacity-40">
          {alt.split(" ")[0]}
        </span>
      </div>
    );
  }

  const prev = () => setI((x) => (x - 1 + list.length) % list.length);
  const next = () => setI((x) => (x + 1) % list.length);

  return (
    <div className={`relative aspect-[3/4] overflow-hidden bg-muted ${className}`}>
      <img
        src={list[i]}
        alt={`${alt} ${i + 1}`}
        className="h-full w-full object-cover"
      />
      {list.length > 1 && (
        <>
          <button
            type="button"
            onClick={prev}
            className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 p-2 text-white hover:bg-black/80"
            aria-label="Previous image"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={next}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 p-2 text-white hover:bg-black/80"
            aria-label="Next image"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1.5">
            {list.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setI(idx)}
                className={`h-1.5 w-1.5 rounded-full ${
                  idx === i ? "bg-primary" : "bg-white/40"
                }`}
                aria-label={`Image ${idx + 1}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
