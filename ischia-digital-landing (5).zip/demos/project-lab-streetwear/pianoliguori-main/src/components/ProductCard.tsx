import { Link } from "@tanstack/react-router";
import type { Product } from "@/data/products";
import { triggerSecretAdmin } from "@/components/SiteHeader";

type ProductCardProps = {
  product: Product;
};

export function ProductCard({ product }: ProductCardProps) {
  const isSoldOut =
    product.status === "soldout" || product.sizes.every((s) => s.stock === 0);
  const isTeaser = product.status === "teaser";
  const price = product.discountPrice ?? product.price;
  const hasDiscount = !!product.discountPrice;
  const cover = product.images?.[0];

  return (
    <Link
      to="/product/$slug"
      params={{ slug: product.slug }}
      className="group block product-card"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-muted">
        {cover ? (
          <img
            src={cover}
            alt={product.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-charcoal to-background">
            <span className="font-display text-4xl font-bold text-border opacity-40">
              {product.title.split(" ")[0]}
            </span>
          </div>
        )}

        {product.limited && !isSoldOut && !isTeaser && (
          <span className="absolute left-2 top-2 bg-primary px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
            Limited
          </span>
        )}

        {isTeaser && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <span className="border border-primary px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-primary">
              Locked
            </span>
          </div>
        )}

        {/* Badge only — does NOT cover the whole card, so click opens PDP / waitlist */}
        {isSoldOut && !isTeaser && (
          <span
            role="button"
            tabIndex={0}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              const el = e.currentTarget as HTMLSpanElement & { _clicks?: number };
              el._clicks = (el._clicks || 0) + 1;
              if (el._clicks >= 3) {
                el._clicks = 0;
                triggerSecretAdmin();
              }
              window.setTimeout(() => {
                el._clicks = 0;
              }, 800);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") e.preventDefault();
            }}
            className="absolute bottom-2 left-2 z-10 cursor-pointer border border-white/40 bg-black/80 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-white"
          >
            Sold Out
          </span>
        )}
      </div>

      <div className="mt-3 space-y-1">
        <h3 className="text-sm font-medium uppercase tracking-wide transition-colors group-hover:text-primary">
          {product.title}
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold">€{price}</span>
          {hasDiscount && (
            <span className="text-xs text-muted-foreground line-through">
              €{product.price}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
