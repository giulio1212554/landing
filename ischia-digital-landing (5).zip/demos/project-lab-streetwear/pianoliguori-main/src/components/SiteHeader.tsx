import { Link, useNavigate } from "@tanstack/react-router";
import { Search, ShoppingBag, Menu, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { CartDrawer } from "@/components/CartDrawer";
import { loadCart, cartCount, type CartItem } from "@/lib/cart";

const LINKS = [
  { to: "/drops", label: "Calendario drop" },
  { to: "/shop", label: "Shop" },
  { to: "/collections", label: "Collezioni" },
  { to: "/about", label: "Informazioni" },
  { to: "/returns", label: "Resi" },
] as const;

type SiteHeaderProps = {
  onAdminUnlock?: () => void;
};

export function triggerSecretAdmin() {
  const fn = (window as unknown as { __plabTriggerSecret?: () => void })
    .__plabTriggerSecret;
  fn?.();
}

export function SiteHeader({ onAdminUnlock }: SiteHeaderProps) {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);
  const [passInput, setPassInput] = useState("");
  const [denied, setDenied] = useState(false);
  const [glitch, setGlitch] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const [items, setItems] = useState<CartItem[]>([]);
  const clickTimes = useRef<number[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setItems(loadCart());
    const onStorage = () => setItems(loadCart());
    window.addEventListener("storage", onStorage);
    window.addEventListener("plab-cart-updated", onStorage);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("plab-cart-updated", onStorage);
    };
  }, []);

  const triggerSecret = useCallback(() => {
    setGlitch(true);
    window.setTimeout(() => {
      setGlitch(false);
      setShowTerminal(true);
      window.setTimeout(() => inputRef.current?.focus(), 50);
    }, 400);
  }, []);

  const handleLogoClick = useCallback(() => {
    const now = Date.now();
    clickTimes.current = [
      ...clickTimes.current.filter((t) => now - t < 800),
      now,
    ];
    if (clickTimes.current.length >= 3) {
      clickTimes.current = [];
      triggerSecret();
    }
  }, [triggerSecret]);

  useEffect(() => {
    (window as unknown as { __plabTriggerSecret?: () => void }).__plabTriggerSecret =
      triggerSecret;
    return () => {
      delete (window as unknown as { __plabTriggerSecret?: () => void })
        .__plabTriggerSecret;
    };
  }, [triggerSecret]);

  useEffect(() => {
    if (!showTerminal) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setShowTerminal(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [showTerminal]);

  const handlePassSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDenied(false);
    try {
      const res = await fetch("/api/admin-login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ password: passInput }),
      });
      if (!res.ok) {
        setDenied(true);
        window.setTimeout(() => setDenied(false), 1800);
        setPassInput("");
        return;
      }
      setShowTerminal(false);
      onAdminUnlock?.();
      window.location.href = "/admin";
    } catch {
      setDenied(true);
      window.setTimeout(() => setDenied(false), 1800);
      setPassInput("");
    }
  };

  const count = cartCount(items);

  return (
    <>
      {glitch && (
        <div className="pointer-events-none fixed inset-0 z-[100] bg-black">
          <div
            className="glitch absolute inset-0 opacity-80"
            style={{
              background:
                "linear-gradient(transparent 50%, rgba(0,255,0,0.03) 50%)",
              backgroundSize: "100% 4px",
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="animate-pulse font-mono text-sm tracking-widest text-primary">
              SYSTEM OVERRIDE...
            </span>
          </div>
        </div>
      )}

      {showTerminal && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black">
          <div
            className="absolute inset-0 opacity-20"
            style={{
              background:
                "linear-gradient(transparent 50%, rgba(0,255,0,0.05) 50%)",
              backgroundSize: "100% 3px",
            }}
          />
          <div className="relative w-full max-w-lg px-6 font-mono text-sm">
            <div className="mb-6 text-primary">
              <pre className="leading-relaxed">{`[PROJECT LAB OS - SYSTEM OVERRIDE]
> INITIALIZING ADMIN CLEARANCE...
> ADMIN PASSWORD:`}</pre>
            </div>
            <form onSubmit={handlePassSubmit} className="flex items-center gap-2">
              <span className="text-primary">{">"}</span>
              <input
                ref={inputRef}
                type="password"
                value={passInput}
                onChange={(e) => setPassInput(e.target.value)}
                className="caret-primary flex-1 border-none bg-transparent font-mono tracking-widest text-primary outline-none"
                autoComplete="off"
                spellCheck={false}
              />
              <span className="animate-pulse text-primary">_</span>
            </form>
            {denied && (
              <div className="glitch mt-6 font-bold tracking-wider text-red-500">
                ACCESSO NEGATO
              </div>
            )}
            <button
              type="button"
              onClick={() => setShowTerminal(false)}
              className="mt-10 text-xs text-muted-foreground transition-colors hover:text-primary"
            >
              [ ESC / CHIUDI ]
            </button>
          </div>
        </div>
      )}

      <header className="fixed left-0 right-0 top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <button
            type="button"
            onClick={handleLogoClick}
            className="flex shrink-0 cursor-pointer select-none items-center gap-2"
            aria-label="PROJECT LAB logo"
          >
            <img
              src="/logo-project-lab.jpg"
              alt="PROJECT LAB"
              className="h-8 w-8 rounded-sm object-cover sm:h-9 sm:w-9"
            />
            <span className="font-display text-[15px] font-extrabold uppercase tracking-[0.18em] text-foreground">
              PROJECT LAB
            </span>
          </button>

          <nav className="hidden items-center gap-6 md:flex">
            {LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="text-[12px] font-medium uppercase tracking-wider text-muted-foreground transition-colors hover:text-primary"
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label="Cerca"
              onClick={() => setSearchOpen(true)}
              className="p-2 text-muted-foreground transition-colors hover:text-foreground"
            >
              <Search className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Carrello"
              onClick={() => setCartOpen(true)}
              className="relative p-2 text-muted-foreground transition-colors hover:text-foreground"
            >
              <ShoppingBag className="h-4 w-4" />
              {count > 0 && (
                <span className="absolute right-0 top-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground">
                  {count}
                </span>
              )}
            </button>
            <button
              type="button"
              className="p-2 text-muted-foreground md:hidden"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <nav className="border-t border-border px-4 py-3 md:hidden">
            {LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setMobileOpen(false)}
                className="block py-2 text-xs font-medium uppercase tracking-wider text-muted-foreground hover:text-primary"
              >
                {l.label}
              </Link>
            ))}
          </nav>
        )}
      </header>

      {searchOpen && (
        <div className="fixed inset-0 z-[80] flex items-start justify-center bg-black/70 px-4 pt-24">
          <form
            className="w-full max-w-md rounded-sm border border-border bg-card p-4"
            onSubmit={(e) => {
              e.preventDefault();
              const q = searchQ.trim();
              setSearchOpen(false);
              if (q) {
                void navigate({ to: "/shop", search: { q } });
              } else {
                void navigate({ to: "/shop" });
              }
            }}
          >
            <input
              autoFocus
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Cerca prodotti…"
              className="w-full border border-border bg-input px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="flex-1 border border-border py-2 text-xs font-bold uppercase"
              >
                Annulla
              </button>
              <button
                type="submit"
                className="flex-1 bg-primary py-2 text-xs font-bold uppercase text-primary-foreground"
              >
                Cerca
              </button>
            </div>
          </form>
        </div>
      )}

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={items}
        onChange={() => setItems(loadCart())}
      />
    </>
  );
}
