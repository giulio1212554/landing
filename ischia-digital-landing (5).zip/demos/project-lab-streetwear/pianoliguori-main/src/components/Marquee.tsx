type MarqueeProps = {
  text: string;
  className?: string;
};

export function Marquee({ text, className = "" }: MarqueeProps) {
  const content = `${text}  ·  ${text}  ·  `;
  return (
    <div className={`overflow-hidden border-y border-border bg-card py-2.5 ${className}`}>
      <div className="marquee whitespace-nowrap font-display text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">
        <span>{content}</span>
        <span>{content}</span>
      </div>
    </div>
  );
}
