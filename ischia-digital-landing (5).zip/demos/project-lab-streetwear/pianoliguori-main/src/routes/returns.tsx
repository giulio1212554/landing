import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { createReturnRequest } from "@/lib/payment.functions";

export const Route = createFileRoute("/returns")({
  head: () => ({ meta: [{ title: "Returns — PROJECT LAB" }] }),
  component: ReturnsPage,
});

function ReturnsPage() {
  const [form, setForm] = useState({
    orderId: "",
    email: "",
    reason: "",
    items: "",
  });
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />
      <div className="mx-auto max-w-lg px-4 py-12">
        <h1 className="font-display text-3xl font-bold uppercase">Returns / RMA</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Request a return within 14 days. Order ID and the email used at checkout
          must match a paid order.
        </p>
        {done ? (
          <div className="mt-8 rounded-sm border border-primary/40 bg-card p-6">
            <p className="text-xs uppercase text-primary">Request submitted</p>
            <p className="mt-2 font-mono text-lg">{done}</p>
            <Link to="/" className="mt-4 inline-block text-xs text-primary">
              ← Home
            </Link>
          </div>
        ) : (
          <form
            className="mt-8 space-y-3"
            onSubmit={async (e) => {
              e.preventDefault();
              setError(null);
              setLoading(true);
              try {
                const r = await createReturnRequest({ data: form });
                setDone(r.id);
              } catch (err: unknown) {
                setError(err instanceof Error ? err.message : "Request failed");
              } finally {
                setLoading(false);
              }
            }}
          >
            <input
              required
              placeholder="Order ID (e.g. PL-…)"
              value={form.orderId}
              onChange={(e) => setForm((f) => ({ ...f, orderId: e.target.value }))}
              className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm"
            />
            <input
              required
              type="email"
              placeholder="Email used at checkout"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm"
            />
            <input
              required
              placeholder="Items (title + size)"
              value={form.items}
              onChange={(e) => setForm((f) => ({ ...f, items: e.target.value }))}
              className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm"
            />
            <textarea
              required
              placeholder="Reason"
              value={form.reason}
              onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))}
              rows={3}
              className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm"
            />
            {error && <p className="text-xs text-destructive">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-sm bg-primary py-3.5 text-sm font-bold uppercase text-primary-foreground disabled:opacity-50"
            >
              {loading ? "Sending…" : "Submit request"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
