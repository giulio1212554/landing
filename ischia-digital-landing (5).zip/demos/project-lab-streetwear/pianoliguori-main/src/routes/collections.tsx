import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { fetchCatalog } from "@/lib/catalog-client";
import type { Product, SiteSettings } from "@/data/products";
import { DEFAULT_SETTINGS } from "@/data/products";

export const Route = createFileRoute("/collections")({
  head: () => ({ meta: [{ title: "Lookbook — PROJECT LAB" }] }),
  component: CollectionsPage,
});

function CollectionsPage() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    void fetchCatalog().then(({ settings: s, products: p }) => {
      setSettings(s);
      setProducts(
        p.filter((x) => x.status === "live" || x.status === "soldout").slice(0, 8),
      );
    });
  }, []);

  const lookbook = settings.lookbookImages?.filter(Boolean) ?? [];
  const social = settings.social || { instagram: "", tiktok: "" };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-primary">
          PROJECT LAB
        </p>
        <h1 className="mt-2 font-display text-3xl font-bold uppercase tracking-tight">
          Lookbook
        </h1>
        <div className="mt-4 flex gap-4 text-xs font-bold uppercase tracking-wider">
          {social.instagram && (
            <a
              href={social.instagram}
              target="_blank"
              rel="noreferrer"
              className="text-primary"
            >
              Instagram
            </a>
          )}
          {social.tiktok && (
            <a
              href={social.tiktok}
              target="_blank"
              rel="noreferrer"
              className="text-primary"
            >
              TikTok
            </a>
          )}
        </div>

        {lookbook.length === 0 ? (
          <p className="mt-12 text-sm text-muted-foreground">
            Nessuna foto nel lookbook. Aggiungile da Admin → Impostazioni.
          </p>
        ) : (
          <div className="mt-10 columns-1 gap-4 sm:columns-2 lg:columns-3">
            {lookbook.map((src, i) => (
              <div
                key={i}
                className="mb-4 break-inside-avoid overflow-hidden rounded-sm border border-border bg-muted"
              >
                <img
                  src={src}
                  alt={`Lookbook ${i + 1}`}
                  className="w-full object-cover"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        )}

        <h2 className="mt-16 font-display text-xl font-bold uppercase">Shop</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((pr) => (
            <Link
              key={pr.id}
              to="/product/$slug"
              params={{ slug: pr.slug }}
              className="group block"
            >
              <div className="aspect-[3/4] overflow-hidden bg-muted">
                {pr.images?.[0] ? (
                  <img
                    src={pr.images[0]}
                    alt={pr.title}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                ) : null}
              </div>
              <p className="mt-2 text-xs font-medium uppercase">{pr.title}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
