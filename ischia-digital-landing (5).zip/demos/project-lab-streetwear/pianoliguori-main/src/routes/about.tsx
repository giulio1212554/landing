import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { DEFAULT_SETTINGS, type SiteSettings } from "@/data/products";
import { fetchCatalog } from "@/lib/catalog-client";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "Informazioni — PROJECT LAB" }] }),
  component: AboutPage,
});

function AboutPage() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    void fetchCatalog().then(({ settings: s }) => setSettings(s));
  }, []);

  const title = settings.aboutTitle || "Informazioni";
  const body =
    settings.aboutBody ||
    "PROJECT LAB è un label streetwear indipendente.";
  const footer = settings.aboutFooter || "Limited Drops. No Restocks.";

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-primary">
          PROJECT LAB
        </p>
        <h1 className="mt-3 font-display text-4xl font-bold uppercase tracking-tight">
          {title}
        </h1>
        <div className="mt-8 space-y-4 text-left text-sm leading-relaxed text-muted-foreground whitespace-pre-wrap">
          {body}
        </div>
        <p className="mt-10 text-sm font-medium text-foreground">{footer}</p>
      </div>
    </div>
  );
}
