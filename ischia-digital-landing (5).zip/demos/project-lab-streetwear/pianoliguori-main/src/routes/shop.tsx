import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { ProductCard } from "@/components/ProductCard";
import type { Product } from "@/data/products";
import { loadProducts } from "@/lib/store";
import { fetchCatalog } from "@/lib/catalog-client";

export const Route = createFileRoute("/shop")({
  validateSearch: (s: Record<string, unknown>) => ({
    q: typeof s.q === "string" ? s.q : undefined,
  }),
  head: () => ({
    meta: [{ title: "Shop All — PROJECT LAB" }],
  }),
  component: ShopPage,
});

const CATEGORIES = ["all", "hoodies", "tees", "cargo", "accessories"] as const;

function ShopPage() {
  const { q: qParam } = Route.useSearch();
  const [category, setCategory] = useState<string>("all");
  const [sizeFilter, setSizeFilter] = useState<string>("all");
  const [query, setQuery] = useState(qParam ?? "");
  const [all, setAll] = useState<Product[]>([]);

  useEffect(() => {
    void fetchCatalog().then(({ products }) => {
      setAll(products.filter((p) => p.status === "live" || p.status === "soldout"));
    });
  }, []);

  useEffect(() => {
    if (qParam != null) setQuery(qParam);
  }, [qParam]);

  const items = useMemo(() => {
    let list = all;
    if (category !== "all") list = list.filter((p) => p.category === category);
    if (sizeFilter !== "all") {
      list = list.filter((p) =>
        p.sizes.some((s) => s.size === sizeFilter && s.stock > 0),
      );
    }
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.slug.toLowerCase().includes(q),
      );
    }
    return list;
  }, [all, category, sizeFilter, query]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <h1 className="font-display text-3xl font-bold uppercase tracking-tight">Shop All</h1>

        <div className="mt-6">
          <label className="sr-only" htmlFor="shop-search">
            Cerca prodotti
          </label>
          <input
            id="shop-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title, category…"
            className="w-full max-w-md rounded-sm border border-border bg-input px-3 py-2.5 text-sm outline-none focus:border-primary"
          />
        </div>

        <div className="mt-8 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={`rounded-sm px-4 py-2 text-xs font-bold uppercase tracking-wider transition ${
                category === c
                  ? "bg-primary text-primary-foreground"
                  : "border border-border text-muted-foreground hover:border-primary hover:text-primary"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {["all", "S", "M", "L", "XL"].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSizeFilter(s)}
              className={`rounded-sm px-3 py-1.5 text-xs font-medium uppercase tracking-wider transition ${
                sizeFilter === s
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {s === "all" ? "All sizes" : s}
            </button>
          ))}
        </div>

        <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        {items.length === 0 && (
          <p className="mt-12 text-center text-sm text-muted-foreground">
            No products match your filters.
          </p>
        )}
      </div>
    </div>
  );
}
