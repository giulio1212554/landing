import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import type { Product, ProductStatus, SiteSettings } from "@/data/products";
import {
  loadProducts,
  saveProducts,
  loadSettings,
  saveSettings,
  loadSubscribers,
  resetToSeed,
} from "@/lib/store";
import {
  loadOrders,
  updateOrderShipping,
  ordersToShip,
  ordersShipped,
  type StoreOrder,
} from "@/lib/orders";
import {
  loadReservations,
  updateReservationStatus,
  type StoreReservation,
} from "@/lib/reservations";
import {
  loadWaitlist,
  loadDropPhones,
  loadRmas,
  updateRmaStatus,
} from "@/lib/commerce-extras";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Console — PROJECT LAB" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const TABS = [
  "dashboard",
  "products",
  "pos",
  "store",
  "orders",
  "waitlist",
  "rma",
  "codes",
  "drops",
  "settings",
  "analytics",
] as const;

type Tab = (typeof TABS)[number];

function AdminPage() {
  const [unlocked, setUnlocked] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [subscribers, setSubscribers] = useState<string[]>([]);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [editing, setEditing] = useState<Product | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [loginPass, setLoginPass] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [pendingReset, setPendingReset] = useState(false);
  const [adminToast, setAdminToast] = useState<string | null>(null);
  const [liveNotices, setLiveNotices] = useState<string[]>([]);
  const [bootError, setBootError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // Session check is best-effort — never crash the login screen
        const mod = await import("@/lib/admin.functions");
        const s = await mod.adminCheckSession();
        if (cancelled) return;
        if (s.authenticated) {
          setUnlocked(true);
          try {
            const { adminGetCatalog } = await import("@/lib/admin.functions");
            const cat = await adminGetCatalog();
            setProducts(cat.products);
            setSettings(cat.settings);
            try {
              saveProducts(cat.products);
              saveSettings(cat.settings);
            } catch { /* ignore */ }
          } catch {
            setProducts(loadProducts());
            setSettings(loadSettings());
          }
          setSubscribers(loadSubscribers());
        }
      } catch (e) {
        if (!cancelled) {
          setBootError(e instanceof Error ? e.message : "Session check failed");
          setUnlocked(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!unlocked) return;
    const KEY = "plab-admin-seen-orders";
    const tick = () => {
      try {
        const orders = loadOrders();
        let seen: string[] = [];
        try {
          seen = JSON.parse(sessionStorage.getItem(KEY) || "[]") as string[];
        } catch {
          seen = [];
        }
        const paid = orders.filter((o) => o.status === "paid");
        const fresh = paid.filter((o) => !seen.includes(o.id));
        if (fresh.length) {
          setLiveNotices((prev) =>
            [
              ...fresh.map(
                (o) =>
                  `Payment: ${o.id} · €${Number(o.total).toFixed(2)} · ${o.customer?.name || ""}`,
              ),
              ...prev,
            ].slice(0, 8),
          );
          sessionStorage.setItem(
            KEY,
            JSON.stringify([...seen, ...fresh.map((o) => o.id)].slice(-100)),
          );
        }
      } catch {
        /* ignore */
      }
    };
    tick();
    const id = window.setInterval(tick, 8000);
    return () => window.clearInterval(id);
  }, [unlocked]);

  const flashSaved = () => {
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 1500);
  };

  const persistProducts = (next: Product[]) => {
    setProducts(next);
    try {
      saveProducts(next);
    } catch {
      setAdminToast("Local cache full — saved to server only (use image URLs)");
      setTimeout(() => setAdminToast(null), 4000);
    }
    void (async () => {
      try {
        const { adminSaveProducts } = await import("@/lib/admin.functions");
        await adminSaveProducts({ data: { products: next } });
        flashSaved();
      } catch (e) {
        setAdminToast(
          e instanceof Error ? `Server save failed: ${e.message}` : "Server save failed",
        );
        setTimeout(() => setAdminToast(null), 4000);
      }
    })();
  };

  const persistSettings = (next: SiteSettings) => {
    setSettings(next);
    saveSettings(next);
    flashSaved();
    void (async () => {
      try {
        const { adminSaveSettings } = await import("@/lib/admin.functions");
        await adminSaveSettings({ data: { settings: next } });
      } catch (e) {
        setAdminToast(
          e instanceof Error ? `Settings save failed: ${e.message}` : "Settings save failed",
        );
        setTimeout(() => setAdminToast(null), 4000);
      }
    })();
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setLoginBusy(true);
    try {
      const res = await fetch("/api/admin-login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ password: loginPass }),
      });
      const body = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setAuthError(body.error ?? "Login failed");
        return;
      }
      setUnlocked(true);
      try {
        const { adminGetCatalog } = await import("@/lib/admin.functions");
        const cat = await adminGetCatalog();
        setProducts(cat.products);
        setSettings(cat.settings);
        try {
          saveProducts(cat.products);
          saveSettings(cat.settings);
        } catch { /* ignore */ }
      } catch {
        setProducts(loadProducts());
        setSettings(loadSettings());
      }
      setSubscribers(loadSubscribers());
    } catch {
      setAuthError("Login failed — is the server running?");
    } finally {
      setLoginBusy(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/admin-logout", { method: "POST", credentials: "include" });
    } catch {
      /* ignore */
    }
    setUnlocked(false);
  };

  if (!unlocked) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black px-4 font-mono text-primary">
        <form onSubmit={handleAdminLogin} className="w-full max-w-sm space-y-4 text-center">
          <p className="text-xs tracking-widest">PROJECT LAB // ADMIN</p>
          <input
            type="password"
            value={loginPass}
            onChange={(e) => setLoginPass(e.target.value)}
            placeholder="Admin password"
            autoComplete="current-password"
            className="w-full border border-primary/40 bg-transparent px-3 py-2 text-sm text-primary outline-none"
          />
          {authError && <p className="text-xs text-red-500">{authError}</p>}
          {bootError && (
            <p className="text-[10px] text-muted-foreground">Note: {bootError}</p>
          )}
          <button
            type="submit"
            disabled={loginBusy}
            className="w-full border border-primary py-2 text-xs font-bold uppercase tracking-wider disabled:opacity-50"
          >
            {loginBusy ? "…" : "Enter"}
          </button>
          <p className="text-[10px] text-muted-foreground">
            Password from ADMIN_PASSWORD in your .env file
          </p>
        </form>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black font-mono text-primary">
        <p className="text-sm">Loading…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <p className="font-display text-sm font-bold tracking-[0.2em] text-primary">
            PROJECT LAB // ADMIN {savedFlash ? "· saved" : ""}
          </p>
          <button
            type="button"
            onClick={() => void handleLogout()}
            className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground hover:text-primary"
          >
            Logout
          </button>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-3 overflow-x-auto px-4 pb-3 text-[10px] font-bold uppercase tracking-wider">
          {TABS.map((tname) => (
            <button
              key={tname}
              type="button"
              onClick={() => setTab(tname)}
              className={
                tab === tname
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }
            >
              {tname}
            </button>
          ))}
        </nav>
      </header>

      {adminToast && (
        <div className="fixed bottom-4 right-4 z-50 rounded-sm border border-border bg-card px-4 py-2 text-xs shadow-lg">
          {adminToast}
        </div>
      )}

      {liveNotices.length > 0 && (
        <div className="border-b border-primary/40 bg-primary/10 px-4 py-2">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-2">
            <p className="text-xs font-bold uppercase tracking-wider text-primary">
              New activity
            </p>
            <button
              type="button"
              className="text-[10px] uppercase text-muted-foreground"
              onClick={() => setLiveNotices([])}
            >
              Dismiss
            </button>
          </div>
          <ul className="mx-auto mt-1 max-w-6xl space-y-1">
            {liveNotices.map((n, i) => (
              <li key={i} className="text-xs">
                {n}
              </li>
            ))}
          </ul>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 py-8">
        {tab === "dashboard" && <DashboardPanel products={products} />}
        {tab === "pos" && settings && (
          <PosPanel
            products={products}
            settings={settings}
            onProducts={persistProducts}
            onSettings={persistSettings}
            setToast={setAdminToast}
          />
        )}
        {tab === "store" && <StoreReservationsPanel />}
        {tab === "waitlist" && <WaitlistPanel />}
        {tab === "rma" && <RmaPanel />}
        {tab === "codes" && (
          <CodesPanel settings={settings} onSave={persistSettings} />
        )}
        {tab === "products" && (
          <div>
            <div className="flex items-center justify-between gap-4">
              <h1 className="font-display text-xl font-bold uppercase">Products</h1>
              <button
                type="button"
                className="text-xs font-bold uppercase text-primary"
                onClick={() => {
                  const id = `pl-${Date.now().toString(36)}`;
                  setEditing({
                    id,
                    slug: id,
                    title: "NEW PIECE",
                    price: 100,
                    category: "tees",
                    sizes: [
                      { size: "S", stock: 0 },
                      { size: "M", stock: 0 },
                      { size: "L", stock: 0 },
                      { size: "XL", stock: 0 },
                    ],
                    description: "",
                    materials: "",
                    status: "draft",
                    images: [],
                  });
                }}
              >
                + Add
              </button>
            </div>
            <ul className="mt-6 space-y-2">
              {products.map((pr) => (
                <li
                  key={pr.id}
                  className="flex flex-wrap items-center justify-between gap-2 border border-border p-3 text-sm"
                >
                  <span className="flex items-center gap-3 font-medium">
                    {pr.images?.[0] ? (
                      <img
                        src={pr.images[0]}
                        alt=""
                        className="h-10 w-10 rounded-sm object-cover"
                      />
                    ) : null}
                    {pr.title} <StatusBadge status={pr.status} />
                  </span>
                  <button
                    type="button"
                    className="text-[10px] font-bold uppercase text-primary"
                    onClick={() => setEditing(pr)}
                  >
                    Edit
                  </button>
                </li>
              ))}
            </ul>
            {editing && (
              <ProductEditor
                product={editing}
                existingSlugs={products.map((p) => p.slug)}
                onCancel={() => setEditing(null)}
                onSave={(next) => {
                  const exists = products.some((x) => x.id === next.id);
                  const list = exists
                    ? products.map((x) => (x.id === next.id ? next : x))
                    : [...products, next];
                  persistProducts(list);
                  setEditing(null);
                }}
              />
            )}
          </div>
        )}
        {tab === "orders" && (
          <div>
            <h1 className="font-display text-xl font-bold uppercase">Orders</h1>
            <OrdersList setToast={setAdminToast} />
          </div>
        )}
        {tab === "drops" && (
          <div>
            <h1 className="font-display text-xl font-bold uppercase">Drops</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Next drop: {settings.nextDropDate}
            </p>
            <label className="mt-4 block text-xs uppercase text-muted-foreground">
              Drop date (ISO)
            </label>
            <input
              value={settings.nextDropDate}
              onChange={(e) =>
                persistSettings({ ...settings, nextDropDate: e.target.value })
              }
              className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm font-mono"
            />
            <label className="mt-4 block text-xs uppercase text-muted-foreground">
              Banner
            </label>
            <input
              value={settings.bannerMessage}
              onChange={(e) =>
                persistSettings({ ...settings, bannerMessage: e.target.value })
              }
              className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm"
            />
            <label className="mt-4 block text-xs uppercase text-muted-foreground">
              Marquee
            </label>
            <textarea
              value={settings.marqueeText}
              onChange={(e) =>
                persistSettings({ ...settings, marqueeText: e.target.value })
              }
              rows={2}
              className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm"
            />
          </div>
        )}
        {tab === "settings" && (
          <div className="space-y-4">
            <h1 className="font-display text-xl font-bold uppercase">Impostazioni</h1>
            <p className="text-xs text-muted-foreground">
              Le chiavi Stripe restano solo nel file <code className="text-primary">.env</code>.
              Riavvia <code className="text-primary">npm run dev</code> dopo le modifiche.
            </p>
            <label className="block text-xs uppercase text-muted-foreground">
              Free shipping threshold (€)
            </label>
            <input
              type="number"
              value={settings.freeShippingThreshold}
              onChange={(e) =>
                persistSettings({
                  ...settings,
                  freeShippingThreshold: Number(e.target.value),
                })
              }
              className="w-32 border border-border bg-input px-3 py-2 text-sm"
            />
            <label className="block text-xs uppercase text-muted-foreground">
              Store address
            </label>
            <input
              value={settings.store?.address ?? ""}
              onChange={(e) =>
                persistSettings({
                  ...settings,
                  store: { ...settings.store, address: e.target.value },
                })
              }
              className="w-full border border-border bg-input px-3 py-2 text-sm"
            />
            <label className="block text-xs uppercase text-muted-foreground">
              Hours
            </label>
            <input
              value={settings.store?.hours ?? ""}
              onChange={(e) =>
                persistSettings({
                  ...settings,
                  store: { ...settings.store, hours: e.target.value },
                })
              }
              className="w-full border border-border bg-input px-3 py-2 text-sm"
            />
            <label className="block text-xs uppercase text-muted-foreground">
              Staff WhatsApp
            </label>
            <input
              value={settings.store?.staffWhatsApp ?? ""}
              onChange={(e) =>
                persistSettings({
                  ...settings,
                  store: { ...settings.store, staffWhatsApp: e.target.value },
                })
              }
              className="w-full border border-border bg-input px-3 py-2 font-mono text-sm"
            />
            <label className="block text-xs uppercase text-muted-foreground">
              Instagram URL
            </label>
            <input
              value={settings.social?.instagram ?? ""}
              onChange={(e) =>
                persistSettings({
                  ...settings,
                  social: { ...settings.social, instagram: e.target.value },
                })
              }
              className="w-full border border-border bg-input px-3 py-2 text-sm"
            />

            <div className="border-t border-border pt-4">
              <h2 className="font-display text-sm font-bold uppercase text-primary">
                Pagamenti
              </h2>
              <label className="mt-3 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={Boolean(settings.payment?.testMode)}
                  onChange={(e) =>
                    persistSettings({
                      ...settings,
                      payment: {
                        ...settings.payment,
                        testMode: e.target.checked,
                      },
                    })
                  }
                />
                <span>
                  <strong>Solo debug</strong> — pagamento finto (non usare in negozio reale)
                </span>
              </label>
              <p className="mt-1 text-[10px] text-muted-foreground">
                Lascia disattivo. Per test reali usa chiavi Stripe sk_test_ nel file .env
              </p>
              <label className="mt-4 block text-xs uppercase text-muted-foreground">
                Metodo (stripe / bank / both)
              </label>
              <select
                value={settings.payment?.method ?? "stripe"}
                onChange={(e) =>
                  persistSettings({
                    ...settings,
                    payment: {
                      ...settings.payment,
                      method: e.target.value as typeof settings.payment.method,
                    },
                  })
                }
                className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm"
              >
                <option value="stripe">stripe</option>
                <option value="card">card</option>
                <option value="both">both</option>
                <option value="bank">bank</option>
              </select>
            </div>

            <div className="border-t border-border pt-4">
              <h2 className="font-display text-sm font-bold uppercase text-primary">
                Lookbook foto
              </h2>
              <p className="mt-1 text-[10px] text-muted-foreground">
                Immagini della pagina Collezioni / Lookbook (URL o upload compresso)
              </p>
              <input
                type="file"
                accept="image/*"
                multiple
                className="mt-2 block w-full text-xs"
                onChange={(e) => {
                  const files = Array.from(e.target.files || []);
                  files.forEach((file) => {
                    const reader = new FileReader();
                    reader.onload = () => {
                      const dataUrl = String(reader.result || "");
                      if (!dataUrl) return;
                      const imgs = [...(settings.lookbookImages || []), dataUrl];
                      persistSettings({ ...settings, lookbookImages: imgs });
                    };
                    reader.readAsDataURL(file);
                  });
                  e.target.value = "";
                }}
              />
              <input
                placeholder="Incolla URL immagine e premi Invio"
                className="mt-2 w-full border border-border bg-input px-3 py-2 text-sm"
                onKeyDown={(e) => {
                  if (e.key !== "Enter") return;
                  e.preventDefault();
                  const el = e.currentTarget;
                  const url = el.value.trim();
                  if (!url) return;
                  persistSettings({
                    ...settings,
                    lookbookImages: [...(settings.lookbookImages || []), url],
                  });
                  el.value = "";
                }}
              />
              <div className="mt-3 flex flex-wrap gap-2">
                {(settings.lookbookImages || []).map((src, idx) => (
                  <div key={idx} className="relative h-20 w-20 overflow-hidden rounded-sm border border-border">
                    <img src={src} alt="" className="h-full w-full object-cover" />
                    <button
                      type="button"
                      className="absolute right-0 top-0 bg-black/70 px-1 text-[10px] text-white"
                      onClick={() =>
                        persistSettings({
                          ...settings,
                          lookbookImages: (settings.lookbookImages || []).filter(
                            (_, i) => i !== idx,
                          ),
                        })
                      }
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border pt-4">
              <h2 className="font-display text-sm font-bold uppercase text-primary">
                Pagina Informazioni
              </h2>
              <p className="mt-1 text-[10px] text-muted-foreground">
                Testi della pagina /about — il brand resta &quot;PROJECT LAB&quot;
              </p>
              <label className="mt-3 block text-xs uppercase text-muted-foreground">
                Titolo
              </label>
              <input
                value={settings.aboutTitle ?? ""}
                onChange={(e) =>
                  persistSettings({ ...settings, aboutTitle: e.target.value })
                }
                className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm"
              />
              <label className="mt-3 block text-xs uppercase text-muted-foreground">
                Testo principale
              </label>
              <textarea
                value={settings.aboutBody ?? ""}
                onChange={(e) =>
                  persistSettings({ ...settings, aboutBody: e.target.value })
                }
                rows={8}
                className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm leading-relaxed"
              />
              <label className="mt-3 block text-xs uppercase text-muted-foreground">
                Riga finale
              </label>
              <input
                value={settings.aboutFooter ?? ""}
                onChange={(e) =>
                  persistSettings({ ...settings, aboutFooter: e.target.value })
                }
                className="mt-1 w-full border border-border bg-input px-3 py-2 text-sm"
              />
            </div>

            <button
              type="button"
              className="text-xs font-bold uppercase text-destructive"
              onClick={() => setPendingReset(true)}
            >
              Reset catalogo seed
            </button>
            {pendingReset && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
                <div className="max-w-sm rounded-sm border border-border bg-card p-6">
                  <p className="text-sm font-medium">Reset catalog to seed?</p>
                  <div className="mt-4 flex gap-2">
                    <button
                      type="button"
                      className="flex-1 border border-border py-2 text-xs font-bold uppercase"
                      onClick={() => setPendingReset(false)}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="flex-1 bg-destructive py-2 text-xs font-bold uppercase text-white"
                      onClick={() => {
                        resetToSeed();
                        setProducts(loadProducts());
                        setSettings(loadSettings());
                        setPendingReset(false);
                      }}
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        {tab === "analytics" && (
          <div>
            <h1 className="font-display text-xl font-bold uppercase">Analytics</h1>
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              <StatCard label="Products" value={String(products.length)} />
              <StatCard label="Subscribers" value={String(subscribers.length)} />
              <StatCard
                label="Live"
                value={String(products.filter((x) => x.status === "live").length)}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}


function DashboardPanel({ products }: { products: Product[] }) {
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [reservations, setReservations] = useState<StoreReservation[]>([]);

  useEffect(() => {
    void (async () => {
      try {
        const { adminGetCatalog } = await import("@/lib/admin.functions");
        const cat = await adminGetCatalog();
        setOrders(
          cat.orders
            .filter((o) => o.status === "paid" || o.status === "pending_payment")
            .map((o) => ({
              id: o.id,
              createdAt: o.createdAt,
              items: o.items.map((i) => ({
                productId: i.productId,
                slug: i.slug,
                title: i.title,
                size: i.size,
                qty: i.qty,
                price: i.unitPrice,
              })),
              subtotal: o.subtotal,
              shipping: o.shipping,
              total: o.total,
              discount: o.discountAmount,
              customer: o.customer,
              status: o.status === "paid" ? "paid" : "pending",
              shippingStatus: o.shippingStatus,
              paymentMethod: o.paymentMethod,
            })) as StoreOrder[],
        );
        setReservations(
          (cat.holds || []).map((h) => ({
            id: h.id,
            createdAt: h.createdAt,
            productId: h.productId,
            productTitle: h.productTitle,
            slug: h.slug,
            size: h.size,
            customerName: h.customerName,
            phone: h.phone,
            email: h.email,
            note: h.note,
            status: h.status,
            holdUntil: h.holdUntil,
          })) as StoreReservation[],
        );
      } catch {
        setOrders(loadOrders());
        setReservations(loadReservations());
      }
    })();
  }, []);

  const totalPieces = products.reduce(
    (n, p) => n + p.sizes.reduce((a, s) => a + s.stock, 0),
    0,
  );
  const toShip = ordersToShip(orders);
  const shipped = ordersShipped(orders);
  const pendingRes = reservations.filter(
    (r) => r.status === "pending" || r.status === "ready",
  );

  const byCategory = useMemo(() => {
    const m = new Map<string, number>();
    for (const pr of products) {
      const n = pr.sizes.reduce((s, x) => s + x.stock, 0);
      m.set(pr.category, (m.get(pr.category) || 0) + n);
    }
    return Array.from(m.entries());
  }, [products]);

  const maxCat = Math.max(1, ...byCategory.map(([, v]) => v));

  return (
    <div>
      <h1 className="font-display text-xl font-bold uppercase">Dashboard</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Pezzi disponibili" value={String(totalPieces)} />
        <StatCard label="Pacchi da inviare" value={String(toShip.length)} />
        <StatCard label="Pacchi inviati" value={String(shipped.length)} />
        <StatCard label="Prenotazioni store" value={String(pendingRes.length)} />
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <div className="rounded-sm border border-border bg-card p-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-primary">
            Stock by category
          </h2>
          <ul className="mt-4 space-y-3">
            {byCategory.length === 0 && (
              <li className="text-xs text-muted-foreground">No stock</li>
            )}
            {byCategory.map(([name, value]) => (
              <li key={name}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="uppercase">{name}</span>
                  <span className="font-bold">{value}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-sm bg-muted">
                  <div
                    className="h-full bg-primary"
                    style={{ width: `${(value / maxCat) * 100}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-sm border border-border bg-card p-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-primary">
            Orders snapshot
          </h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li className="flex justify-between">
              <span>To ship</span>
              <span className="font-bold text-primary">{toShip.length}</span>
            </li>
            <li className="flex justify-between">
              <span>Shipped</span>
              <span className="font-bold">{shipped.length}</span>
            </li>
            <li className="flex justify-between">
              <span>Store holds</span>
              <span className="font-bold">{pendingRes.length}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function OrdersList({ setToast }: { setToast?: (msg: string | null) => void }) {
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [loadErr, setLoadErr] = useState<string | null>(null);

  const refresh = async () => {
    try {
      const { adminListOrders } = await import("@/lib/admin.functions");
      const res = await adminListOrders();
      // Map server PlabOrder → StoreOrder shape used by UI
      setOrders(
        res.orders.map((o) => ({
          id: o.id,
          createdAt: o.createdAt,
          items: o.items.map((i) => ({
            productId: i.productId,
            slug: i.slug,
            title: i.title,
            size: i.size,
            qty: i.qty,
            price: i.unitPrice,
          })),
          subtotal: o.subtotal,
          shipping: o.shipping,
          total: o.total,
          discount: o.discountAmount,
          discountCode: o.discountCode ?? undefined,
          customer: o.customer,
          status: o.status === "paid" ? "paid" : o.status === "pending_payment" ? "pending" : o.status,
          shippingStatus: o.shippingStatus,
          paymentMethod: o.paymentMethod,
          trackingCode: undefined,
          receiptToken: o.receiptToken,
        })) as StoreOrder[],
      );
      setLoadErr(null);
    } catch (e) {
      setLoadErr(e instanceof Error ? e.message : "Failed to load orders");
      setOrders(loadOrders());
    }
  };

  useEffect(() => {
    void refresh();
  }, []);

  if (orders.length === 0) {
    return <p className="mt-8 text-sm text-muted-foreground">No orders yet.</p>;
  }

  return (
    <div className="mt-6 space-y-4">
      {orders.map((o) => (
        <div key={o.id} className="rounded-sm border border-border bg-card p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-mono text-sm font-bold text-primary">{o.id}</span>
            <span className="text-xs text-muted-foreground">
              {new Date(o.createdAt).toLocaleString()}
            </span>
          </div>
          <p className="mt-1 text-sm">
            {o.customer?.name} · {o.customer?.email}
          </p>
          <p className="mt-1 text-sm font-medium">
            €{Number(o.total).toFixed(2)} · {o.status} ·{" "}
            <span className="text-primary">{o.shippingStatus ?? "to_ship"}</span>
          </p>
          <ul className="mt-2 text-xs text-muted-foreground">
            {o.items?.map((i, idx) => (
              <li key={idx}>
                {i.title} · {i.size} × {i.qty}
              </li>
            ))}
          </ul>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              className="text-[10px] font-bold uppercase text-primary"
              onClick={() => setOrders(updateOrderShipping(o.id, "to_ship"))}
            >
              To ship
            </button>
            <button
              type="button"
              className="text-[10px] font-bold uppercase text-primary"
              onClick={() => {
                const code = window.prompt("Tracking (optional)") ?? "";
                setOrders(updateOrderShipping(o.id, "shipped", code || undefined));
                const phone = (o.customer?.phone || "").replace(/\D/g, "");
                if (phone) {
                  const body = encodeURIComponent(
                    `PROJECT LAB: order ${o.id} shipped` +
                      (code ? ` · tracking ${code}` : ""),
                  );
                  // Opens device SMS app (customer notified). Works on mobile.
                  window.open(`sms:${phone}?body=${body}`, "_blank");
                }
                setToast?.(`Marked shipped${phone ? " · SMS opened" : ""}`);
                setTimeout(() => setToast?.(null), 2500);
              }}
            >
              Shipped
            </button>
            <button
              type="button"
              className="text-[10px] font-bold uppercase text-primary"
              onClick={() => setOrders(updateOrderShipping(o.id, "delivered"))}
            >
              Delivered
            </button>
            <button
              type="button"
              className="text-[10px] font-bold uppercase text-primary"
              onClick={async () => {
                try {
                  const { adminMarkOrderPaid } = await import("@/lib/admin.functions");
                  await adminMarkOrderPaid({ data: { orderId: o.id } });
                  setOrders(loadOrders());
                } catch (e: unknown) {
                  setToast?.(e instanceof Error ? e.message : "Failed");
                  setTimeout(() => setToast?.(null), 3000);
                }
              }}
            >
              Mark paid (server)
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}



function StoreReservationsPanel() {
  const [list, setList] = useState<StoreReservation[]>([]);
  useEffect(() => {
    void (async () => {
      try {
        const { listAdminStoreHolds } = await import("@/lib/payment.functions");
        const holds = await listAdminStoreHolds();
        setList(holds as unknown as StoreReservation[]);
      } catch {
        setList(loadReservations());
      }
    })();
  }, []);

  useEffect(() => {
    setList(loadReservations());
  }, []);

  const active = list.filter((r) => r.status === "pending" || r.status === "ready");
  const past = list.filter((r) => r.status !== "pending" && r.status !== "ready");

  return (
    <div>
      <h1 className="font-display text-xl font-bold uppercase">Prenotazioni negozio</h1>
      <p className="mt-1 text-xs text-muted-foreground">
        Capi riservati per ritiro in store (hold 48h)
      </p>

      <h2 className="mt-8 text-sm font-bold uppercase tracking-wider text-primary">Attive</h2>
      <div className="mt-3 space-y-3">
        {active.length === 0 && (
          <p className="text-sm text-muted-foreground">Nessuna prenotazione attiva.</p>
        )}
        {active.map((r) => (
          <div key={r.id} className="rounded-sm border border-border bg-card p-4">
            <div className="flex flex-wrap justify-between gap-2">
              <span className="font-mono text-xs text-primary">{r.id}</span>
              <span className="text-[10px] uppercase text-muted-foreground">
                fino al {new Date(r.holdUntil).toLocaleString("it-IT")}
              </span>
            </div>
            <p className="mt-1 font-medium text-sm">
              {r.productTitle} · {r.size}
            </p>
            <p className="text-xs text-muted-foreground">
              {r.customerName} · {r.phone}
              {r.email ? ` · ${r.email}` : ""}
            </p>
            {r.note && <p className="mt-1 text-xs italic text-muted-foreground">{r.note}</p>}
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="rounded-sm border border-border px-2 py-1 text-[10px] font-bold uppercase"
                onClick={() => {
                  void (async () => {
                    try {
                      const { adminUpdateHold } = await import("@/lib/admin.functions");
                      const res = await adminUpdateHold({ data: { id: r.id, status: "ready" } });
                      setList(res.holds as StoreReservation[]);
                    } catch {
                      setList(updateReservationStatus(r.id, "ready"));
                    }
                  })();
                }}
              >
                Pronto in store
              </button>
              <button
                type="button"
                className="rounded-sm bg-primary px-2 py-1 text-[10px] font-bold uppercase text-primary-foreground"
                onClick={() => {
                  void (async () => {
                    try {
                      const { adminUpdateHold } = await import("@/lib/admin.functions");
                      const res = await adminUpdateHold({ data: { id: r.id, status: "picked_up" } });
                      setList(res.holds as StoreReservation[]);
                    } catch {
                      setList(updateReservationStatus(r.id, "picked_up"));
                    }
                  })();
                }}
              >
                Ritirato
              </button>
              <button
                type="button"
                className="rounded-sm border border-border px-2 py-1 text-[10px] font-bold uppercase text-muted-foreground"
                onClick={() => {
                  void (async () => {
                    try {
                      const { adminUpdateHold } = await import("@/lib/admin.functions");
                      const res = await adminUpdateHold({ data: { id: r.id, status: "cancelled" } });
                      setList(res.holds as StoreReservation[]);
                    } catch {
                      setList(updateReservationStatus(r.id, "cancelled"));
                    }
                  })();
                }}
              >
                Annulla
              </button>
            </div>
          </div>
        ))}
      </div>

      {past.length > 0 && (
        <>
          <h2 className="mt-10 text-sm font-bold uppercase tracking-wider text-muted-foreground">
            Storico
          </h2>
          <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
            {past.slice(0, 30).map((r) => (
              <li key={r.id}>
                {r.id} · {r.productTitle} {r.size} · {r.status}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}


function WaitlistPanel() {
  const [list, setList] = useState(() => loadWaitlist());
  const phones = loadDropPhones();
  return (
    <div>
      <h1 className="font-display text-xl font-bold uppercase">Waitlist & SMS drop</h1>
      <div className="mt-6 space-y-3">
        {list.length === 0 && <p className="text-sm text-muted-foreground">Nessuna iscrizione restock.</p>}
        {list.map((w) => (
          <div key={w.id} className="border border-border rounded-sm p-3 text-sm">
            <p className="font-medium">{w.productTitle} · {w.size}</p>
            <p className="text-xs text-muted-foreground">{w.email} {w.phone || ""}</p>
          </div>
        ))}
      </div>
      <h2 className="mt-8 text-sm font-bold uppercase text-primary">Telefoni SMS drop ({phones.length})</h2>
      <ul className="mt-2 text-xs text-muted-foreground space-y-1">
        {phones.map((ph) => (
          <li key={ph}>{ph}</li>
        ))}
      </ul>
    </div>
  );
}

function RmaPanel() {
  const [list, setList] = useState(() => loadRmas());
  return (
    <div>
      <h1 className="font-display text-xl font-bold uppercase">Resi / RMA</h1>
      <div className="mt-6 space-y-3">
        {list.length === 0 && <p className="text-sm text-muted-foreground">Nessun reso.</p>}
        {list.map((r) => (
          <div key={r.id} className="border border-border rounded-sm p-4 text-sm">
            <p className="font-mono text-primary text-xs">{r.id}</p>
            <p>Ordine {r.orderId} · {r.email}</p>
            <p className="text-xs text-muted-foreground">{r.items} — {r.reason}</p>
            <p className="mt-1 text-xs uppercase">{r.status}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {(["approved", "label_sent", "received", "refunded", "rejected"] as const).map((s) => (
                <button key={s} type="button" className="text-[10px] font-bold uppercase text-primary" onClick={() => setList(updateRmaStatus(r.id, s))}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CodesPanel({ settings, onSave }: { settings: SiteSettings; onSave: (s: SiteSettings) => void }) {
  const [codes, setCodes] = useState(settings.discountCodes || []);
  const [newCode, setNewCode] = useState({ code: "", percent: 10, earlyAccess: false });
  return (
    <div>
      <h1 className="font-display text-xl font-bold uppercase">Codici sconto & early access</h1>
      <ul className="mt-6 space-y-2 text-sm">
        {codes.map((c, i) => (
          <li key={i} className="flex flex-wrap items-center gap-2 border border-border p-3 rounded-sm">
            <span className="font-mono font-bold">{c.code}</span>
            <span>{c.percent}%</span>
            {c.earlyAccess && <span className="text-primary text-xs">EARLY</span>}
            <span className="text-xs text-muted-foreground">
              used {c.used ?? 0}/{c.maxUses ?? "∞"}
            </span>
            <button
              type="button"
              className="text-xs text-destructive ml-auto"
              onClick={() => {
                const next = codes.filter((_, j) => j !== i);
                setCodes(next);
                onSave({ ...settings, discountCodes: next });
              }}
            >
              Elimina
            </button>
          </li>
        ))}
      </ul>
      <div className="mt-6 flex flex-wrap gap-2 items-end">
        <input
          placeholder="CODE"
          value={newCode.code}
          onChange={(e) => setNewCode((n) => ({ ...n, code: e.target.value.toUpperCase() }))}
          className="border border-border bg-input px-2 py-2 text-sm rounded-sm w-28"
        />
        <input
          type="number"
          value={newCode.percent}
          onChange={(e) => setNewCode((n) => ({ ...n, percent: Number(e.target.value) }))}
          className="border border-border bg-input px-2 py-2 text-sm rounded-sm w-20"
        />
        <label className="text-xs flex items-center gap-1">
          <input
            type="checkbox"
            checked={newCode.earlyAccess}
            onChange={(e) => setNewCode((n) => ({ ...n, earlyAccess: e.target.checked }))}
          />{" "}
          Early access
        </label>
        <button
          type="button"
          className="bg-primary text-primary-foreground px-4 py-2 text-xs font-bold uppercase rounded-sm"
          onClick={() => {
            if (!newCode.code) return;
            const next = [...codes, { ...newCode, active: true, used: 0, maxUses: 100 }];
            setCodes(next);
            onSave({ ...settings, discountCodes: next });
            setNewCode({ code: "", percent: 10, earlyAccess: false });
          }}
        >
          Aggiungi
        </button>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: ProductStatus }) {
  const colors: Record<ProductStatus, string> = {
    draft: "bg-muted text-muted-foreground",
    teaser: "bg-amber-500/20 text-amber-400",
    live: "bg-primary/20 text-primary",
    soldout: "bg-red-500/20 text-red-400",
  };
  return (
    <span
      className={`inline-block rounded-sm px-2 py-0.5 text-[10px] font-bold uppercase ${colors[status]}`}
    >
      {status}
    </span>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-sm border border-border bg-card p-4">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold">{value}</p>
    </div>
  );
}


function PosPanel({
  products,
  settings,
  onProducts,
  onSettings,
  setToast,
}: {
  products: Product[];
  settings: SiteSettings;
  onProducts: (p: Product[]) => void;
  onSettings: (s: SiteSettings) => void;
  setToast: (msg: string | null) => void;
}) {
  const [live, setLive] = useState(true);
  const [log, setLog] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const keys = settings.posHotkeys || [];

  const setKey = (productId: string, size: string, key: string) => {
    const k = key.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 1);
    let next = keys.filter(
      (h) => !(h.productId === productId && h.size === size),
    );
    // remove same letter from others
    if (k) {
      next = next.filter((h) => h.key !== k);
      const pr = products.find((p) => p.id === productId);
      next = [
        ...next,
        {
          key: k,
          productId,
          size,
          label: pr ? `${pr.title} · ${size}` : size,
        },
      ];
    }
    onSettings({ ...settings, posHotkeys: next });
  };

  const sell = async (productId: string, size: string, via: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const { adminPosSale } = await import("@/lib/admin.functions");
      const res = await adminPosSale({
        data: { productId, size, qty: 1 },
      });
      onProducts(res.products);
      const line = `[${new Date().toLocaleTimeString()}] −1 ${res.title} · ${size} (restano ${res.remaining}) · tasto ${via}`;
      setLog((prev) => [line, ...prev].slice(0, 40));
      setToast(line);
      setTimeout(() => setToast(null), 2000);
      // beep soft
      try {
        const ctx = new AudioContext();
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = res.remaining === 0 ? 220 : 880;
        g.gain.value = 0.05;
        o.start();
        o.stop(ctx.currentTime + 0.08);
      } catch {
        /* ignore */
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Errore vendita";
      setToast(msg);
      setTimeout(() => setToast(null), 3000);
      setLog((prev) => [`ERR ${msg}`, ...prev].slice(0, 40));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!live) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const k = e.key.toLowerCase();
      if (!/^[a-z0-9]$/.test(k)) return;
      const hit = keys.find((h) => h.key === k);
      if (!hit) return;
      e.preventDefault();
      void sell(hit.productId, hit.size, k.toUpperCase());
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [live, keys, busy, products]);

  const liveProducts = products.filter(
    (p) => p.status === "live" || p.status === "soldout" || p.status === "draft",
  );

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-xl font-bold uppercase">
            Magazzino / POS negozio
          </h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Assegna una lettera a prodotto + taglia. Con la modalità attiva, premi
            quel tasto per scalare <strong>1 pezzo</strong> dallo stock (vendita
            fisica). Lo stock online si aggiorna subito.
          </p>
        </div>
        <label className="flex items-center gap-2 rounded-sm border border-border px-3 py-2 text-xs font-bold uppercase">
          <input
            type="checkbox"
            checked={live}
            onChange={(e) => setLive(e.target.checked)}
          />
          {live ? "Tastiera attiva" : "Tastiera spenta"}
        </label>
      </div>

      {live && (
        <div className="mt-4 rounded-sm border border-primary/40 bg-primary/10 px-3 py-2 text-xs text-primary">
          Premi le lettere assegnate (non mentre scrivi in un campo). Stock
          condiviso con lo shop online.
        </div>
      )}

      <div className="mt-6 overflow-x-auto rounded-sm border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-muted/50 text-[10px] uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Prodotto</th>
              <th className="px-3 py-2">Taglia</th>
              <th className="px-3 py-2">Stock</th>
              <th className="px-3 py-2">Tasto</th>
              <th className="px-3 py-2">Vendita</th>
            </tr>
          </thead>
          <tbody>
            {liveProducts.flatMap((pr) =>
              pr.sizes.map((s) => {
                const assigned =
                  keys.find(
                    (h) => h.productId === pr.id && h.size === s.size,
                  )?.key ?? "";
                return (
                  <tr key={pr.id + s.size} className="border-t border-border/50">
                    <td className="px-3 py-2 font-medium">{pr.title}</td>
                    <td className="px-3 py-2">{s.size}</td>
                    <td
                      className={`px-3 py-2 font-bold ${s.stock <= 0 ? "text-destructive" : s.stock <= 3 ? "text-primary" : ""}`}
                    >
                      {s.stock}
                    </td>
                    <td className="px-3 py-2">
                      <input
                        maxLength={1}
                        value={assigned}
                        placeholder="—"
                        onChange={(e) =>
                          setKey(pr.id, s.size, e.target.value)
                        }
                        className="w-10 border border-border bg-input px-1 py-1 text-center font-mono text-sm uppercase"
                      />
                    </td>
                    <td className="px-3 py-2">
                      <button
                        type="button"
                        disabled={s.stock <= 0 || busy}
                        onClick={() => void sell(pr.id, s.size, "click")}
                        className="text-[10px] font-bold uppercase text-primary disabled:opacity-40"
                      >
                        −1
                      </button>
                    </td>
                  </tr>
                );
              }),
            )}
          </tbody>
        </table>
      </div>

      <h2 className="mt-8 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Log vendite negozio
      </h2>
      <ul className="mt-2 max-h-48 space-y-1 overflow-y-auto font-mono text-[11px] text-muted-foreground">
        {log.length === 0 && <li>Nessuna vendita in questa sessione</li>}
        {log.map((line, i) => (
          <li key={i}>{line}</li>
        ))}
      </ul>
    </div>
  );
}

function ProductEditor({
  product,
  onSave,
  onCancel,
  existingSlugs = [],
}: {
  product: Product;
  onSave: (p: Product) => void;
  onCancel: () => void;
  existingSlugs?: string[];
}) {
  const isNew = !existingSlugs.includes(product.slug) && product.title === "NEW PIECE";
  const slugLocked = !isNew && Boolean(product.id);
  const [form, setForm] = useState({
    ...product,
    dropDate: product.dropDate ?? "",
    materials: product.materials ?? "",
    discountPrice: product.discountPrice,
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [imgWarning, setImgWarning] = useState<string | null>(null);

  const totalImageBytes = (images: string[]) =>
    images.reduce((n, s) => n + (s?.length || 0), 0);

  const compressFile = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("read failed"));
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const maxW = 1200;
          const scale = Math.min(1, maxW / img.width);
          const w = Math.round(img.width * scale);
          const h = Math.round(img.height * scale);
          const canvas = document.createElement("canvas");
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(String(reader.result));
            return;
          }
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL("image/jpeg", 0.72));
        };
        img.onerror = () => resolve(String(reader.result));
        img.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });

  const validateAndSave = () => {
    if (!form.title.trim()) {
      setFormError("Title is required");
      return;
    }
    const slug = (form.slug || "").trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    if (!slug || slug.length < 2) {
      setFormError("Slug is required (min 2 chars, a-z 0-9 -)");
      return;
    }
    if (
      existingSlugs.some(
        (s) => s === slug && s !== product.slug,
      )
    ) {
      setFormError("Slug already used by another product");
      return;
    }
    if (!Number.isFinite(Number(form.price)) || Number(form.price) < 0) {
      setFormError("Price must be a non-negative number");
      return;
    }
    if (
      form.discountPrice != null &&
      form.discountPrice !== ("" as unknown) &&
      (!Number.isFinite(Number(form.discountPrice)) || Number(form.discountPrice) < 0)
    ) {
      setFormError("Discount price must be a non-negative number");
      return;
    }
    if (
      form.sizes.some(
        (s) =>
          !Number.isFinite(Number(s.stock)) ||
          Number(s.stock) < 0 ||
          !Number.isInteger(Number(s.stock)),
      )
    ) {
      setFormError("Stock must be non-negative integers");
      return;
    }
    // Past drop date only blocks if still set — user can clear the field
    if (form.status === "live" && form.dropDate && String(form.dropDate).trim()) {
      const d = new Date(form.dropDate);
      if (!Number.isNaN(d.getTime()) && d.getTime() < Date.now() - 60_000) {
        setFormError(
          "Drop date is in the past — clear the field or set a future date to GO LIVE",
        );
        return;
      }
    }
    if (form.status === "live" && form.sizes.every((s) => Number(s.stock) <= 0)) {
      setFormError("Cannot set Live with zero stock on all sizes");
      return;
    }
    const images = form.images || [];
    if (totalImageBytes(images) > 4_500_000) {
      setFormError(
        "Images too large for save (~4.5MB limit). Remove some or use external URLs.",
      );
      return;
    }
    setFormError(null);
    const discRaw = form.discountPrice;
    const discNum =
      discRaw === undefined || discRaw === null || (discRaw as unknown) === ""
        ? undefined
        : Number(discRaw);
    onSave({
      ...form,
      slug: slugLocked ? product.slug : slug,
      price: Number(form.price),
      discountPrice: discNum !== undefined && Number.isFinite(discNum) ? discNum : undefined,
      dropDate: form.dropDate && String(form.dropDate).trim() ? String(form.dropDate) : undefined,
      materials: form.materials?.trim() || undefined,
      sizes: form.sizes.map((s) => ({
        ...s,
        stock: Math.max(0, Math.trunc(Number(s.stock) || 0)),
      })),
      images,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-sm border border-border bg-card p-6">
        <h2 className="font-display text-lg font-bold uppercase">
          {product.title && product.title !== "NEW PIECE" ? "Edit Product" : "New Product"}
        </h2>
        <div className="mt-4 space-y-3">
          <input
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
          />
          <div>
            <label className="text-[10px] font-bold uppercase text-muted-foreground">
              Slug {slugLocked ? "(locked — keeps cart links)" : ""}
            </label>
            <input
              placeholder="slug"
              value={form.slug}
              disabled={slugLocked}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-"),
                }))
              }
              className="mt-1 w-full rounded-sm border border-border bg-input px-3 py-2 font-mono text-sm disabled:opacity-60"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] uppercase text-muted-foreground">Price €</label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={form.price}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    price: e.target.value === "" ? 0 : Number(e.target.value),
                  }))
                }
                className="mt-1 w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase text-muted-foreground">
                Discount € (empty = none)
              </label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={form.discountPrice ?? ""}
                onChange={(e) => {
                  const v = e.target.value;
                  setForm((f) => ({
                    ...f,
                    discountPrice: v === "" ? undefined : Number(v),
                  }));
                }}
                className="mt-1 w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
              />
            </div>
          </div>
          <select
            value={form.category}
            onChange={(e) =>
              setForm((f) => ({
                ...f,
                category: e.target.value as Product["category"],
              }))
            }
            className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
          >
            <option value="hoodies">hoodies</option>
            <option value="tees">tees</option>
            <option value="cargo">cargo</option>
            <option value="accessories">accessories</option>
          </select>
          <select
            value={form.status}
            onChange={(e) =>
              setForm((f) => ({
                ...f,
                status: e.target.value as ProductStatus,
              }))
            }
            className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
          >
            <option value="draft">draft</option>
            <option value="teaser">teaser</option>
            <option value="live">live</option>
            <option value="soldout">soldout</option>
          </select>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">
              Drop date (optional — clear to unlock past products)
            </label>
            <div className="mt-1 flex gap-2">
              <input
                type="datetime-local"
                value={
                  form.dropDate
                    ? (() => {
                        try {
                          const d = new Date(form.dropDate);
                          if (Number.isNaN(d.getTime())) return "";
                          const pad = (n: number) => String(n).padStart(2, "0");
                          return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
                        } catch {
                          return "";
                        }
                      })()
                    : ""
                }
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    dropDate: e.target.value
                      ? new Date(e.target.value).toISOString()
                      : "",
                  }))
                }
                className="flex-1 rounded-sm border border-border bg-input px-3 py-2 text-sm"
              />
              <button
                type="button"
                className="rounded-sm border border-border px-3 text-[10px] font-bold uppercase"
                onClick={() => setForm((f) => ({ ...f, dropDate: "" }))}
              >
                Clear
              </button>
            </div>
          </div>
          <textarea
            placeholder="Description"
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            rows={3}
            className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
          />
          <input
            placeholder="Materials (e.g. 450gsm cotton)"
            value={form.materials ?? ""}
            onChange={(e) => setForm((f) => ({ ...f, materials: e.target.value }))}
            className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
          />
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Product photos (compressed; prefer URLs for large files)
            </label>
            <input
              type="file"
              accept="image/*"
              multiple
              className="mt-1 block w-full text-xs text-muted-foreground file:mr-3 file:rounded-sm file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-xs file:font-bold file:uppercase file:text-primary-foreground"
              onChange={(e) => {
                const files = Array.from(e.target.files || []);
                void (async () => {
                  for (const file of files) {
                    try {
                      const dataUrl = await compressFile(file);
                      setForm((f) => {
                        const next = [...(f.images || []), dataUrl];
                        if (totalImageBytes(next) > 4_500_000) {
                          setImgWarning("Images near size limit — save may fail. Use URLs.");
                        }
                        return { ...f, images: next };
                      });
                    } catch {
                      setImgWarning("Could not read image");
                    }
                  }
                })();
                e.target.value = "";
              }}
            />
            {imgWarning && (
              <p className="mt-1 text-[10px] text-primary">{imgWarning}</p>
            )}
            <div className="mt-2 flex flex-wrap gap-2">
              {(form.images || []).map((src, idx) => (
                <div
                  key={idx}
                  className="relative h-16 w-16 overflow-hidden rounded-sm border border-border"
                >
                  <img src={src} alt="" className="h-full w-full object-cover" />
                  <button
                    type="button"
                    className="absolute right-0 top-0 bg-black/70 px-1 text-[10px] text-white"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        images: (f.images || []).filter((_, i) => i !== idx),
                      }))
                    }
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            <input
              placeholder="Or paste image URL and press Enter"
              className="mt-2 w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
              onKeyDown={(e) => {
                if (e.key !== "Enter") return;
                e.preventDefault();
                const el = e.currentTarget;
                const url = el.value.trim();
                if (!url) return;
                setForm((f) => ({ ...f, images: [...(f.images || []), url] }));
                el.value = "";
              }}
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {form.sizes.map((s, i) => (
              <div key={s.size}>
                <label className="text-[10px] uppercase text-muted-foreground">{s.size}</label>
                <input
                  type="number"
                  min={0}
                  value={s.stock}
                  onChange={(e) => {
                    const sizes = [...form.sizes];
                    sizes[i] = {
                      ...sizes[i],
                      stock: e.target.value === "" ? 0 : Number(e.target.value),
                    };
                    setForm((f) => ({ ...f, sizes }));
                  }}
                  className="w-full rounded-sm border border-border bg-input px-2 py-1.5 text-sm"
                />
              </div>
            ))}
          </div>
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-end gap-2">
          {formError && (
            <p className="mr-auto max-w-[60%] text-xs text-destructive">{formError}</p>
          )}
          <button
            type="button"
            onClick={onCancel}
            className="rounded-sm border border-border px-4 py-2 text-xs font-medium uppercase"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={validateAndSave}
            className="rounded-sm bg-primary px-4 py-2 text-xs font-bold uppercase text-primary-foreground"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
