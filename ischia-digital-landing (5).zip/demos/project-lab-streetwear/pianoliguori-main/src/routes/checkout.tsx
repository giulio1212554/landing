import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import {
  loadCart,
  clearCart,
  type CartItem,
} from "@/lib/cart";
import type { StoreOrder } from "@/lib/orders";
import { loadSettings } from "@/lib/store";
import type { SiteSettings } from "@/data/products";
import {
  createStripeCheckoutSession,
  createBankTransferOrder,
  createTestPaymentOrder,
  quoteCheckout,
} from "@/lib/payment.functions";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [{ title: "Checkout — PROJECT LAB" }],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [done, setDone] = useState<StoreOrder | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    zip: "",
    country: "Italy",
  });
  const [promo, setPromo] = useState("");
  const [promoMsg, setPromoMsg] = useState("");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [referralCode, setReferralCode] = useState("");
  const [quoteTotales, setQuoteTotales] = useState<{
    subtotal: number;
    discountAmount: number;
    shipping: number;
    total: number;
  } | null>(null);
  const [quoteError, setQuoteError] = useState<string | null>(null);

  useEffect(() => {
    setItems(loadCart());
    void import("@/lib/catalog-client").then(({ fetchCatalog }) =>
      fetchCatalog().then(({ settings: st }) => setSettings(st)),
    );
    // fallback local
    setSettings(loadSettings());
  }, []);

  // Invalidate quoted totals when cart changes
  useEffect(() => {
    setQuoteTotales(null);
    setDiscountPercent(0);
    setPromoMsg("");
    setQuoteError(null);
  }, [items]);

  if (!settings) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="h-14" />
      </div>
    );
  }

  const pay = settings.payment;
  const testMode = Boolean(pay.testMode);
  // stripe | card | both → Stripe Checkout; bank only → bank transfer
  const useStripe =
    !testMode &&
    (pay.method === "stripe" || pay.method === "card" || pay.method === "both");
  // Provisional display; authoritative totals always come from the server at pay time
  const subtotal =
    quoteTotales?.subtotal ?? items.reduce((n, i) => n + i.price * i.qty, 0);
  const disc = quoteTotales?.discountAmount ?? 0;
  const shipping =
    quoteTotales?.shipping ??
    (subtotal >= settings.freeShippingThreshold || subtotal === 0 ? 0 : 12);
  const total = quoteTotales?.total ?? Math.max(0, subtotal - disc) + shipping;

  const handlePlace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    setError(null);
    setLoading(true);

    try {
      if (testMode) {
        const test = await createTestPaymentOrder({
          data: {
            items: items.map((i) => ({
              productId: i.productId,
              size: i.size,
              qty: i.qty,
            })),
            customer: { ...form },
            discountCode: promo || undefined,
            referralCode: referralCode || undefined,
          },
        });
        clearCart();
        setItems([]);
        window.location.href = `/checkout/success?test=1&order=${encodeURIComponent(test.orderId)}&token=${encodeURIComponent(test.receiptToken)}`;
        return;
      }
      if (useStripe) {
        const origin = window.location.origin;
        const result = await createStripeCheckoutSession({
          data: {
            items: items.map((i) => ({
              productId: i.productId,
              size: i.size,
              qty: i.qty,
            })),
            customer: { ...form },
            discountCode: promo || undefined,
            referralCode: referralCode || undefined,
            successUrl: `${origin}/checkout/success`,
            cancelUrl: `${origin}/checkout`,
          },
        });
        // Keep cart until success page — if customer cancels Stripe, items remain
        window.location.href = result.url;
        return;
      }

      // Bank transfer — server creates pending order, reserves stock 48h
      const bank = await createBankTransferOrder({
        data: {
          items: items.map((i) => ({
            productId: i.productId,
            size: i.size,
            qty: i.qty,
          })),
          customer: { ...form },
          discountCode: promo || undefined,
          referralCode: referralCode || undefined,
        },
      });
      clearCart();
      setItems([]);
      setDone({
        id: bank.orderId,
        createdAt: new Date().toISOString(),
        items: [...items],
        total: bank.total,
        customer: { ...form },
        status: "pending_payment",
        shippingStatus: "to_ship",
        paymentMethod: "bank",
        receiptToken: bank.receiptToken,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Payment failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="h-14" />
        <div className="mx-auto max-w-lg px-4 py-16">
          <p className="text-xs font-medium uppercase tracking-widest text-primary">Order placed</p>
          <h1 className="mt-2 font-display text-3xl font-bold uppercase">Thank you</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Order <span className="font-mono text-foreground">{done.id}</span> · €
            {done.total.toFixed(2)}
          </p>

          <div className="mt-8 rounded-sm border border-primary/40 bg-card p-6">
            <h2 className="font-display text-sm font-bold uppercase tracking-wide text-primary">
              Payment instructions
            </h2>
            <p className="mt-2 text-xs text-muted-foreground">
              Complete payment using the details below. Your order ships after confirmation.
            </p>

            {(pay.method === "bank" || pay.method === "both") && pay.iban && (
              <div className="mt-4 space-y-1 text-sm">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  Bank transfer
                </p>
                {pay.accountHolder && (
                  <p>
                    Holder: <strong>{pay.accountHolder}</strong>
                  </p>
                )}
                {pay.bankName && <p>Bank: {pay.bankName}</p>}
                <p className="font-mono text-xs sm:text-sm break-all">IBAN: {pay.iban}</p>
                {pay.bic && <p className="font-mono text-xs">BIC/SWIFT: {pay.bic}</p>}
                <p className="text-xs text-muted-foreground mt-2">
                  Reference: <span className="font-mono text-foreground">{done.id}</span>
                </p>
              </div>
            )}

            {pay.notes && (
              <p className="mt-4 text-xs text-muted-foreground border-t border-border pt-3">
                {pay.notes}
              </p>
            )}
          </div>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              to="/receipt"
              search={{
                id: done.id,
                token: done.receiptToken,
                email: done.customer.email,
              }}
              className="text-xs font-bold uppercase tracking-wider text-primary"
            >
              Receipt / PDF
            </Link>
            <Link to="/" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              ← Store
            </Link>
            <Link to="/returns" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Reso
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="h-14" />
        <div className="mx-auto max-w-lg px-4 py-16 text-center">
          <p className="text-sm text-muted-foreground">Your cart is empty.</p>
          <Link to="/shop" className="mt-4 inline-block text-xs font-bold uppercase text-primary">
            Shop now
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />

      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:grid lg:grid-cols-2 lg:gap-12">
        <form onSubmit={handlePlace} className="space-y-4">
          <h1 className="font-display text-2xl font-bold uppercase tracking-tight">Checkout</h1>

          {testMode && (
            <div className="rounded-sm border border-primary/50 bg-primary/10 px-3 py-2 text-xs text-primary">
              <p className="font-bold uppercase tracking-wider text-[10px]">Modalità test pagamento</p>
              <p>Nessun addebito reale. L&apos;ordine viene segnato pagato subito (solo per prove).</p>
            </div>
          )}
          {useStripe && !testMode && (
            <div className="rounded-sm border border-primary/30 bg-primary/5 px-3 py-2 text-xs text-primary space-y-1">
              <p className="font-bold uppercase tracking-wider text-[10px]">Paga con Stripe</p>
              <p>Card · PayPal · Google Pay · Apple Pay (where available)</p>
            </div>
          )}

          {(
            [
              ["name", "Nome completo"],
              ["email", "Email"],
              ["phone", "Telefono"],
              ["address", "Indirizzo"],
              ["city", "Città"],
              ["zip", "CAP"],
              ["country", "Paese"],
            ] as const
          ).map(([key, label]) => (
            <div key={key}>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
                {label}
              </label>
              <input
                required
                type={key === "email" ? "email" : "text"}
                value={form[key]}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                className="mt-1 w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>
          ))}

          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Codice sconto / early access</label>
            <div className="flex gap-2">
              <input value={promo} onChange={(e) => setPromo(e.target.value)} placeholder="LAB10" className="flex-1 rounded-sm border border-border bg-input px-3 py-2 text-sm" />
              <button
                type="button"
                className="rounded-sm border border-border px-3 text-xs font-bold uppercase"
                onClick={async () => {
                  try {
                    setQuoteError(null);
                    setQuoteTotales(null);
                    setDiscountPercent(0);
                    const q = await quoteCheckout({
                      data: {
                        items: items.map((i) => ({
                          productId: i.productId,
                          size: i.size,
                          qty: i.qty,
                        })),
                        discountCode: promo || undefined,
                        referralCode: referralCode || undefined,
                        customerEmail: form.email || undefined,
                      },
                    });
                    setQuoteTotales({
                      subtotal: q.subtotal,
                      discountAmount: q.discountAmount,
                      shipping: q.shipping,
                      total: q.total,
                    });
                    setDiscountPercent(q.appliedPercent);
                    setPromoMsg(
                      q.discountAmount > 0
                        ? `Discount applied (−€${q.discountAmount.toFixed(2)})`
                        : "Code accepted",
                    );
                  } catch (e: unknown) {
                    setPromoMsg("");
                    setQuoteError(e instanceof Error ? e.message : "Invalid code");
                    setDiscountPercent(0);
                    setQuoteTotales(null);
                  }
                }}
              >
                Apply
              </button>
            </div>
            {promoMsg && <p className="text-xs text-primary">{promoMsg}</p>}
            {quoteError && <p className="text-xs text-destructive">{quoteError}</p>}
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Codice referral
            </label>
            <input
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              placeholder="REFxxxxx"
              className="w-full rounded-sm border border-border bg-input px-3 py-2 text-sm"
            />
            <p className="text-[10px] text-muted-foreground">
              Promo and referral never stack; promo wins. You cannot use your own referral.
            </p>
          </div>

          {error && (
            <p className="rounded-sm border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-sm bg-primary py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            {loading
              ? testMode
                ? "Pagamento test…"
                : useStripe
                  ? "Reindirizzamento a Stripe…"
                  : "Invio ordine…"
              : testMode
                ? `Paga in test · €${total.toFixed(2)}`
                : useStripe
                  ? `Paga · €${total.toFixed(2)}`
                  : `Conferma ordine · €${total.toFixed(2)}`}
          </button>
        </form>

        <div className="mt-10 lg:mt-0">
          <h2 className="font-display text-sm font-bold uppercase tracking-wide">Riepilogo</h2>
          <ul className="mt-4 space-y-3 border-b border-border pb-4">
            {items.map((i) => (
              <li key={`${i.productId}-${i.size}`} className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {i.title} · {i.size} × {i.qty}
                </span>
                <span>€{(i.price * i.qty).toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotale</span>
              <span>€{subtotal.toFixed(2)}</span>
            </div>
            {disc > 0 && (
              <div className="flex justify-between text-primary">
                <span>Sconto</span>
                <span>-€{disc.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-muted-foreground">Spedizione</span>
              <span>{shipping === 0 ? "Free" : `€${shipping.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between font-bold text-base pt-2">
              <span>Totale</span>
              <span>€{total.toFixed(2)}</span>
            </div>
          </div>

          <div className="mt-6 rounded-sm border border-border bg-card p-4 text-xs text-muted-foreground">
            <p className="font-medium text-foreground uppercase tracking-wider text-[10px] mb-2">
              Payment
            </p>
            {useStripe ? (
              <ul className="space-y-1 list-disc list-inside">
                <li>Card (Visa, Mastercard, Amex…)</li>
                <li>PayPal</li>
                <li>Google Pay</li>
                <li>Apple Pay</li>
              </ul>
            ) : pay.iban ? (
              <p className="font-mono break-all">IBAN {pay.iban}</p>
            ) : (
              <p className="text-amber-400">
                Configure Stripe keys in .env or bank details in Admin → Settings
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
