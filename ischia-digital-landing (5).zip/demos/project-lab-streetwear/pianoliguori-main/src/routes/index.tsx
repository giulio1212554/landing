import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { Marquee } from "@/components/Marquee";
import { Countdown } from "@/components/Countdown";
import { ProductCard } from "@/components/ProductCard";
import type { Product, SiteSettings } from "@/data/products";
import { DEFAULT_SETTINGS } from "@/data/products";
import { loadProducts, loadSettings } from "@/lib/store";
import { fetchCatalog } from "@/lib/catalog-client";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PROJECT LAB — Limited Drops. No Restocks." },
      {
        name: "description",
        content:
          "Urban uniform. Exclusive releases. Worldwide shipping. Limited drops. No restocks.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const [live, setLive] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    const products = loadProducts().filter((p) => p.status === "live").slice(0, 4);
    setLive(products);
    setSettings(loadSettings());
  }, []);

  return (
    <div className="min-h-screen bg-background noise">
      <SiteHeader />
      <div className="h-14" />

      <section className="relative flex min-h-[85vh] flex-col items-center justify-center px-4 text-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/20 to-background" />
        <div className="relative z-10 max-w-4xl">
          <p className="mb-4 text-xs font-medium uppercase tracking-[0.3em] text-primary">
            Limited Drops · No Restocks
          </p>
          <h1 className="font-display text-5xl font-extrabold leading-[0.95] tracking-tight sm:text-7xl md:text-8xl">
            URBAN
            <br />
            UNIFORM
          </h1>
          <p className="mx-auto mt-6 max-w-md text-sm text-muted-foreground">
            Exclusive streetwear releases. Built for the city. Designed to disappear.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 rounded-sm bg-primary px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground transition hover:bg-primary/90"
            >
              Shop Latest Drop
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/drops"
              className="inline-flex items-center gap-2 rounded-sm border border-border px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-foreground transition hover:border-primary hover:text-primary"
            >
              Join Next Drop
            </Link>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-card px-4 py-8">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-6 sm:flex-row">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
              Next Collection Drop
            </p>
            <p className="mt-1 font-display text-lg font-bold uppercase tracking-wide">
              {settings.bannerMessage}
            </p>
          </div>
          <Countdown target={settings.nextDropDate} />
        </div>
      </section>

      <Marquee text={settings.marqueeText} />

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-primary">In evidenza</p>
            <h2 className="mt-1 font-display text-3xl font-bold uppercase tracking-tight">
              Latest Drop
            </h2>
          </div>
          <Link
            to="/shop"
            className="hidden text-xs font-medium uppercase tracking-wider text-muted-foreground hover:text-primary sm:block"
          >
            Vedi tutto →
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {live.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-card/50 px-4 py-20">
        <div className="mx-auto max-w-7xl text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-primary">Editorial</p>
          <h2 className="mt-2 font-display text-4xl font-bold uppercase tracking-tight sm:text-5xl">
            Lookbook
          </h2>
          <p className="mx-auto mt-4 max-w-md text-sm text-muted-foreground">
            Campaign imagery and street shots. Coming soon.
          </p>
          <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-[3/4] bg-muted flex items-center justify-center">
                <span className="text-xs uppercase tracking-widest text-border">Shot {i}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border px-4 py-12">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 sm:flex-row">
          <span className="font-display text-sm font-bold tracking-[0.2em] uppercase">
            PROJECT LAB
          </span>
          <p className="text-xs text-muted-foreground">© 2026 Project Lab. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
