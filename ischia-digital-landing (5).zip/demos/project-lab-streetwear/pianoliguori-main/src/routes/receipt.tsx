import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { getReceiptOrder } from "@/lib/payment.functions";

export const Route = createFileRoute("/receipt")({
  validateSearch: (s: Record<string, unknown>) => ({
    id: typeof s.id === "string" ? s.id : undefined,
    token: typeof s.token === "string" ? s.token : undefined,
    email: typeof s.email === "string" ? s.email : undefined,
  }),
  head: () => ({
    meta: [{ title: "Receipt — PROJECT LAB" }],
  }),
  component: ReceiptPage,
});

function ReceiptPage() {
  const { id, token, email } = Route.useSearch();
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");
  const [order, setOrder] = useState<{
    id: string;
    total: number;
    createdAt: string;
    status: string;
    items: { title: string; size: string; qty: number; unitPrice: number }[];
    customer: { name: string; email: string };
  } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (!id || (!token && !email)) {
        setState("error");
        setErr("Receipt requires order id and token (or email).");
        return;
      }
      try {
        const res = await getReceiptOrder({
          data: { orderId: id, token, email },
        });
        if (cancelled) return;
        if (!res.found) {
          setState("error");
          setErr("Receipt not found or access denied.");
          return;
        }
        setOrder(res.order);
        setState("ok");
      } catch (e: unknown) {
        if (cancelled) return;
        setState("error");
        setErr(e instanceof Error ? e.message : "Failed to load receipt");
      }
    }
    void run();
    return () => {
      cancelled = true;
    };
  }, [id, token, email]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />
      <div className="mx-auto max-w-md px-4 py-10">
        {state === "loading" && (
          <p className="text-center text-sm text-muted-foreground">Loading…</p>
        )}
        {state === "error" && (
          <p className="text-center text-sm text-destructive">{err}</p>
        )}
        {state === "ok" && order && (
          <>
            <div className="rounded-sm border border-border bg-card p-6 print:border-0">
              <p className="font-display text-lg font-bold tracking-widest uppercase">
                PROJECT LAB
              </p>
              <hr className="my-4 border-border" />
              <p className="font-mono text-sm">{order.id}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(order.createdAt).toLocaleString()}
              </p>
              <p className="mt-2 text-sm">{order.customer.name}</p>
              <p className="text-xs text-muted-foreground">{order.customer.email}</p>
              <ul className="mt-4 space-y-2 border-y border-border py-4 text-sm">
                {order.items.map((i, idx) => (
                  <li key={idx} className="flex justify-between gap-2">
                    <span>
                      {i.title} {i.size} ×{i.qty}
                    </span>
                    <span>€{(i.unitPrice * i.qty).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-4 flex justify-between font-bold">
                <span>Total</span>
                <span>€{order.total.toFixed(2)}</span>
              </p>
              <p className="mt-2 text-[10px] uppercase text-muted-foreground">
                {order.status}
              </p>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="mt-6 w-full rounded-sm bg-primary py-3 text-xs font-bold uppercase text-primary-foreground print:hidden"
            >
              Print / Save PDF
            </button>
          </>
        )}
      </div>
    </div>
  );
}
