import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { clearCart } from "@/lib/cart";
import { getOrderBySession } from "@/lib/payment.functions";

export const Route = createFileRoute("/checkout/success")({
  validateSearch: (search: Record<string, unknown>) => ({
    session_id: typeof search.session_id === "string" ? search.session_id : undefined,
    test: search.test === "1" || search.test === true ? "1" : undefined,
    order: typeof search.order === "string" ? search.order : undefined,
    token: typeof search.token === "string" ? search.token : undefined,
  }),
  head: () => ({
    meta: [{ title: "Payment — PROJECT LAB" }],
  }),
  component: SuccessPage,
});

function SuccessPage() {
  const { session_id, test, order: orderQ, token: tokenQ } = Route.useSearch();
  const [state, setState] = useState<"loading" | "paid" | "pending" | "error">("loading");
  const [orderId, setOrderId] = useState<string | null>(null);
  const [receiptToken, setReceiptToken] = useState<string | null>(null);
  const [amount, setAmount] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let attempts = 0;

    async function run() {
      if (test === "1" && orderQ) {
        setState("paid");
        setOrderId(orderQ);
        setReceiptToken(tokenQ ?? null);
        clearCart();
        return;
      }
      if (!session_id) {
        setState("error");
        setErr("Sessione pagamento mancante");
        return;
      }
      try {
        const result = await getOrderBySession({ data: { sessionId: session_id } });
        if (cancelled) return;
        if (!result.found) {
          setState("error");
          setErr("Order not found");
          return;
        }
        setOrderId(result.order.id);
        setReceiptToken(result.order.receiptToken ?? null);
        setAmount(result.order.total);
        if (result.order.status === "paid") {
          setState("paid");
          clearCart();
        } else if (result.order.status === "pending_payment") {
          setState("pending");
        } else {
          setState("error");
          setErr(`Order status: ${result.order.status}`);
        }
      } catch (e: unknown) {
        if (cancelled) return;
        setState("error");
        setErr(e instanceof Error ? e.message : "Verification failed");
      }
    }

    void run();
    const id = window.setInterval(() => {
      attempts += 1;
      if (attempts > 20) {
        window.clearInterval(id);
        return;
      }
      void run();
    }, 2500);

    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [session_id, test, orderQ, tokenQ]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        {state === "loading" && (
          <p className="text-sm text-muted-foreground">Confirming payment…</p>
        )}

        {state === "pending" && (
          <>
            <h1 className="font-display text-2xl font-bold uppercase">Payment processing</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              Waiting for bank confirmation. This page refreshes automatically.
            </p>
            {orderId && (
              <p className="mt-2 font-mono text-xs text-primary">{orderId}</p>
            )}
          </>
        )}

        {state === "paid" && (
          <>
            <h1 className="font-display text-2xl font-bold uppercase">Payment confirmed</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              Thanks. Your order is paid
              {amount != null ? ` · €${amount.toFixed(2)}` : ""}.
            </p>
            {orderId && (
              <p className="mt-2 font-mono text-xs text-primary">{orderId}</p>
            )}
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              {orderId && receiptToken && (
                <Link
                  to="/receipt"
                  search={{ id: orderId, token: receiptToken }}
                  className="text-xs font-bold uppercase tracking-wider text-primary"
                >
                  View receipt
                </Link>
              )}
              <Link
                to="/shop"
                className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
              >
                Continue shopping
              </Link>
            </div>
          </>
        )}

        {state === "error" && (
          <>
            <h1 className="font-display text-2xl font-bold uppercase">Payment issue</h1>
            <p className="mt-3 text-sm text-destructive">{err}</p>
            <Link
              to="/checkout"
              className="mt-8 inline-block text-xs font-bold uppercase tracking-wider text-primary"
            >
              Try again
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
