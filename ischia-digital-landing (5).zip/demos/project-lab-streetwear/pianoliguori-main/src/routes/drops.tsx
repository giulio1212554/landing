import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { Countdown } from "@/components/Countdown";
import type { Product, SiteSettings } from "@/data/products";
import { DEFAULT_SETTINGS } from "@/data/products";
import { loadSettings, getTeaserProductsFromStore, addSubscriber } from "@/lib/store";
import { addDropPhone } from "@/lib/commerce-extras";

export const Route = createFileRoute("/drops")({
  head: () => ({
    meta: [{ title: "Drop Calendar — PROJECT LAB" }],
  }),
  component: DropsPage,
});

function DropsPage() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [teasers, setTeasers] = useState<Product[]>([]);
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    setSettings(loadSettings());
    setTeasers(getTeaserProductsFromStore());
  }, []);

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) addSubscriber(email);
    if (phone) addDropPhone(phone);
    if (email || phone) setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />

      <section className="mx-auto max-w-3xl px-4 py-16 text-center sm:px-6">
        <p className="text-xs font-medium uppercase tracking-[0.3em] text-primary">Upcoming</p>
        <h1 className="mt-3 font-display text-4xl font-extrabold uppercase tracking-tight sm:text-5xl">
          Next Drop
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">{settings.bannerMessage}</p>

        <div className="mt-10 flex justify-center">
          <Countdown target={settings.nextDropDate} />
        </div>

        <div className="mt-14 rounded-sm border border-border bg-card p-6 sm:p-8">
          <h2 className="font-display text-lg font-bold uppercase tracking-wide">Notify Me</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Get alerted the moment the drop goes live.
          </p>
          {submitted ? (
            <p className="mt-6 text-sm font-medium text-primary">
              You&apos;re on the list. Saved locally.
            </p>
          ) : (
            <form onSubmit={handleNotify} className="mt-6 flex flex-col gap-3 sm:flex-row">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="flex-1 rounded-sm border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Telefono SMS alert"
                className="flex-1 rounded-sm border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
              <button
                type="submit"
                className="rounded-sm bg-primary px-6 py-3 text-sm font-bold uppercase tracking-wider text-primary-foreground transition hover:bg-primary/90"
              >
                Join Waitlist
              </button>
            </form>
          )}
        </div>
      </section>

      {teasers.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
          <h2 className="mb-8 font-display text-xl font-bold uppercase tracking-wide">Teasers</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {teasers.map((p) => (
              <div key={p.id} className="relative aspect-[3/4] overflow-hidden bg-muted">
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 p-4 text-center backdrop-blur-sm">
                  <span className="text-xs font-bold uppercase tracking-widest text-primary">
                    Locked until
                  </span>
                  <span className="mt-2 font-display text-sm font-bold uppercase">
                    {p.dropDate
                      ? new Date(p.dropDate).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })
                      : "TBA"}
                  </span>
                  <span className="mt-4 text-xs text-muted-foreground">{p.title}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
