import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { QrTicket } from "@/components/QrTicket";
import type { Product } from "@/data/products";
import {
  getProductBySlugFromStore,
    loadSettings,
} from "@/lib/store";
import { addToCart } from "@/lib/cart";
import { addToWaitlist } from "@/lib/commerce-extras";
import { createStoreReservation } from "@/lib/payment.functions";
import { ProductCarousel } from "@/components/ProductCarousel";
import { createReservation } from "@/lib/reservations";

export const Route = createFileRoute("/product/$slug")({
  head: ({ params }) => ({
    meta: [{ title: `${params.slug} — PROJECT LAB` }],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const [product, setProduct] = useState<Product | null | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [added, setAggiunto] = useState(false);
  const [reserveOpen, setReserveOpen] = useState(false);
  const [reserveDone, setReserveDone] = useState<string | null>(null);
  const [rForm, setRForm] = useState({ name: "", phone: "", email: "", note: "" });
  const [rError, setRError] = useState<string | null>(null);
  const [waitOpen, setWaitOpen] = useState(false);
  const [waitEmail, setWaitEmail] = useState("");
  const [waitPhone, setWaitPhone] = useState("");
  const [waitOk, setWaitOk] = useState(false);
  const [storeNote, setStoreNote] = useState("");

  const refresh = () => setProduct(getProductBySlugFromStore(slug) ?? null);

  useEffect(() => {
    refresh();
    const s = loadSettings();
    setStoreNote(s.store?.pickupNote || "");
  }, [slug]);

  if (product === undefined) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex min-h-[60vh] items-center justify-center text-sm text-muted-foreground">
          Loading…
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex min-h-[60vh] items-center justify-center">
          <p className="text-muted-foreground">Product not found.</p>
        </div>
      </div>
    );
  }

  const isSoldOut = product.status === "soldout" || product.sizes.every((s) => s.stock === 0);
  const isTeaser = product.status === "teaser";
  const price = product.discountPrice ?? product.price;
  const sizeStock = selectedSize
    ? product.sizes.find((s) => s.size === selectedSize)?.stock ?? 0
    : 0;
  const lowStock =
    selectedSize && sizeStock > 0 && sizeStock <= 3 ? sizeStock : null;

  const handleAdd = () => {
    if (!selectedSize || sizeStock <= 0) return;
    try {
      addToCart(
        {
          productId: product.id,
          slug: product.slug,
          title: product.title,
          price,
          size: selectedSize,
          qty: 1,
        },
        sizeStock,
      );
    } catch (e: unknown) {
      setRError(e instanceof Error ? e.message : "Cannot add to cart");
      return;
    }
    setAggiunto(true);
    setTimeout(() => setAggiunto(false), 2000);
  };

  const handleReserve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSize) return;
    if (rForm.name.trim().length < 2 || rForm.phone.trim().length < 6) {
      setRError("Nome e telefono obbligatori");
      return;
    }
    // Server is source of truth for stock (holds already decrement server stock).
    // Do not subtract localStorage holds again or available stock is double-counted.
    if (sizeStock <= 0) {
      setRError("Taglia non più disponibile");
      refresh();
      return;
    }
    try {
      setRError(null);
      const r = await createStoreReservation({
        data: {
          productId: product.id,
          size: selectedSize,
          customerName: rForm.name,
          phone: rForm.phone,
          email: rForm.email || undefined,
          note: rForm.note || undefined,
        },
      });
      // Mirror to localStorage so admin Store tab & device persist like waitlist
      try {
        createReservation({
          productId: product.id,
          productTitle: product.title,
          slug: product.slug,
          size: selectedSize,
          customerName: rForm.name,
          phone: rForm.phone,
          email: rForm.email || "",
          note: rForm.note,
        });
      } catch {
        /* ignore mirror errors */
      }
      setReserveDone(r.id);
      refresh();
    } catch (err: unknown) {
      setRError(err instanceof Error ? err.message : "Reservation failed");
      refresh();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="h-14" />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:grid lg:grid-cols-2 lg:gap-12">
        <ProductCarousel images={product.images || []} alt={product.title} />

        <div className="mt-8 lg:mt-0 pb-24 lg:pb-0">
          <p className="text-xs font-medium uppercase tracking-widest text-primary">
            {product.category}
          </p>
          <h1 className="mt-2 font-display text-3xl font-bold uppercase tracking-tight">
            {product.title}
          </h1>
          <div className="mt-4 flex items-center gap-3">
            {product.discountPrice && (
              <span className="text-lg text-muted-foreground line-through">€{product.price}</span>
            )}
            <span className="text-2xl font-bold">€{price}</span>
          </div>

          <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
            {product.description}
          </p>
          {product.materials && (
            <p className="mt-3 text-xs uppercase tracking-wider text-muted-foreground">
              <span className="font-bold text-foreground">Materiali:</span> {product.materials}
            </p>
          )}

          {storeNote && (
            <p className="mt-4 rounded-sm border border-border bg-card px-3 py-2 text-[11px] text-muted-foreground">
              {storeNote}
            </p>
          )}

          {!isTeaser && (
            <div className="mt-8">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Seleziona taglia
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s.size}
                    type="button"
                    disabled={s.stock === 0}
                    onClick={() => setSelectedSize(s.size)}
                    className={`min-w-[3rem] rounded-sm border px-4 py-2.5 text-sm font-medium transition ${
                      selectedSize === s.size
                        ? "border-primary bg-primary text-primary-foreground"
                        : s.stock === 0
                          ? "border-border text-muted-foreground line-through opacity-50 cursor-not-allowed"
                          : "border-border hover:border-primary"
                    }`}
                  >
                    {s.size}
                  </button>
                ))}
              </div>
              {lowStock != null && (
                <p className="mt-3 text-xs font-medium text-primary">
                  Only {lowStock} left in {selectedSize}!
                </p>
              )}
            </div>
          )}

          {isTeaser ? (
            <div className="mt-10 rounded-sm border border-primary/40 bg-primary/5 p-4 text-center">
              <p className="text-sm font-bold uppercase tracking-wider text-primary">
                Locked until drop
              </p>
              <Link to="/drops" className="mt-2 inline-block text-xs text-muted-foreground underline">
                Lista d’attesa / SMS alert →
              </Link>
            </div>
          ) : isSoldOut || (selectedSize && sizeStock <= 0) ? (
            <div className="mt-10 space-y-3">
              <button
                type="button"
                disabled
                className="w-full rounded-sm border border-border py-4 text-sm font-bold uppercase tracking-wider text-muted-foreground"
              >
                Esaurito
              </button>
              <button
                type="button"
                onClick={() => {
                  setWaitOpen(true);
                  setWaitOk(false);
                }}
                className="w-full rounded-sm border border-primary py-3 text-sm font-bold uppercase tracking-wider text-primary"
              >
                Lista d&apos;attesa
              </button>
            </div>
          ) : (
            <div className="mt-10 space-y-3">
              <button
                type="button"
                disabled={!selectedSize}
                onClick={handleAdd}
                className="w-full rounded-sm bg-primary py-4 text-sm font-bold uppercase tracking-wider text-primary-foreground transition hover:bg-primary/90 disabled:opacity-40"
              >
                {added ? "Aggiunto to cart ✓" : "Add to Cart"}
              </button>
              <button
                type="button"
                disabled={!selectedSize}
                onClick={() => {
                  setReserveOpen(true);
                  setReserveDone(null);
                  setRError(null);
                }}
                className="w-full rounded-sm border border-border py-3.5 text-sm font-bold uppercase tracking-wider hover:border-primary hover:text-primary disabled:opacity-40"
              >
                Prenota in negozio
              </button>
            </div>
          )}

          <Link to="/shop" className="mt-6 inline-block text-xs text-muted-foreground hover:text-primary">
            ← Back to shop
          </Link>
        </div>
      </div>

      {/* Reserve modal */}
      {reserveOpen && (
        <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-md rounded-sm border border-border bg-card p-6 max-h-[90vh] overflow-y-auto">
            {reserveDone ? (
              <div className="text-center">
                <p className="text-xs uppercase tracking-widest text-primary">Prenotato</p>
                <h3 className="mt-2 font-display text-lg font-bold uppercase">Capo riservato</h3>
                <p className="mt-2 font-mono text-sm">{reserveDone}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {product.title} · {selectedSize} · 48h
                </p>
                <div className="mx-auto mt-4 max-w-[200px]">
                  <QrTicket value={reserveDone} label={reserveDone} />
                </div>
                <p className="mt-3 text-[11px] text-muted-foreground">{storeNote}</p>
                <button
                  type="button"
                  onClick={() => setReserveOpen(false)}
                  className="mt-6 w-full rounded-sm bg-primary py-3 text-xs font-bold uppercase text-primary-foreground"
                >
                  Chiudi
                </button>
              </div>
            ) : (
              <form onSubmit={handleReserve} className="space-y-3">
                <h3 className="font-display text-lg font-bold uppercase">Prenota in negozio</h3>
                <p className="text-xs text-muted-foreground">
                  {product.title} · {selectedSize} — lo stock viene scalato subito
                </p>
                <input required placeholder="Nome" value={rForm.name} onChange={(e) => setRForm((f) => ({ ...f, name: e.target.value }))} className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm" />
                <input required placeholder="Telefono" value={rForm.phone} onChange={(e) => setRForm((f) => ({ ...f, phone: e.target.value }))} className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm" />
                <input type="email" placeholder="Email" value={rForm.email} onChange={(e) => setRForm((f) => ({ ...f, email: e.target.value }))} className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm" />
                <textarea placeholder="Note" value={rForm.note} onChange={(e) => setRForm((f) => ({ ...f, note: e.target.value }))} rows={2} className="w-full rounded-sm border border-border bg-input px-3 py-2.5 text-sm" />
                {rError && <p className="text-xs text-destructive">{rError}</p>}
                <div className="flex gap-2">
                  <button type="button" onClick={() => setReserveOpen(false)} className="flex-1 border border-border py-3 text-xs font-bold uppercase rounded-sm">Annulla</button>
                  <button type="submit" className="flex-1 bg-primary py-3 text-xs font-bold uppercase text-primary-foreground rounded-sm">Conferma</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Waitlist modal */}
      {waitOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-sm rounded-sm border border-border bg-card p-6">
            {waitOk ? (
              <p className="text-sm text-primary text-center">Sei in lista. Ti avvisiamo al restock.</p>
            ) : (
              <form
                className="space-y-3"
                onSubmit={(e) => {
                  e.preventDefault();
                  addToWaitlist({
                    productId: product.id,
                    productTitle: product.title,
                    slug: product.slug,
                    size: selectedSize || "any",
                    email: waitEmail,
                    phone: waitPhone || undefined,
                  });
                  setWaitOk(true);
                }}
              >
                <h3 className="font-display font-bold uppercase">Lista d&apos;attesa</h3>
                <input required type="email" placeholder="Email" value={waitEmail} onChange={(e) => setWaitEmail(e.target.value)} className="w-full border border-border bg-input px-3 py-2 text-sm rounded-sm" />
                <input placeholder="Telefono / SMS (opz.)" value={waitPhone} onChange={(e) => setWaitPhone(e.target.value)} className="w-full border border-border bg-input px-3 py-2 text-sm rounded-sm" />
                <button type="submit" className="w-full bg-primary py-3 text-xs font-bold uppercase text-primary-foreground rounded-sm">Iscriviti</button>
              </form>
            )}
            <button type="button" className="mt-4 w-full text-xs text-muted-foreground" onClick={() => setWaitOpen(false)}>Chiudi</button>
          </div>
        </div>
      )}
    </div>
  );
}
