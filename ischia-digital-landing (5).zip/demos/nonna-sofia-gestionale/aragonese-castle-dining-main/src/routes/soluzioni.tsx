import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { SiteHeader } from "@/components/SiteHeader";
import { opsListSolutions } from "@/lib/staff-ops.functions";

const WHATSAPP_LINK = "https://wa.me/39081989062";

export const Route = createFileRoute("/soluzioni")({
  head: () => ({
    meta: [
      { title: "Soluzioni — Nonna Sofia" },
      {
        name: "description",
        content: "Menu speciali, pacchetti e soluzioni su misura al Nonna Sofia.",
      },
    ],
  }),
  component: SoluzioniPage,
});

function SoluzioniPage() {
  const q = useQuery({
    queryKey: ["public-solutions"],
    queryFn: () => opsListSolutions({ data: { activeOnly: true } }),
    retry: 1,
  });

  const list = q.data?.solutions ?? [];

  return (
    <div className="min-h-screen pb-16">
      <SiteHeader active="soluzioni" />
      <main className="mx-auto max-w-lg px-4 py-6">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Su misura
        </p>
        <h1 className="mt-1 text-[28px] font-semibold leading-tight">Soluzioni</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
          Pacchetti e proposte pensate per pranzi, gruppi e occasioni speciali.
          Il dirigente può aggiungerne di nuove dall&apos;area staff.
        </p>

        <div className="mt-6 space-y-4">
          {q.isPending ? (
            <p className="text-[13px] text-muted-foreground">Caricamento…</p>
          ) : list.length === 0 ? (
            <p className="bento p-5 text-[13px] text-muted-foreground">
              Nessuna soluzione pubblicata al momento. Contattaci su WhatsApp.
            </p>
          ) : (
            list.map((s) => (
              <article key={s.id} className="bento p-5">
                <h2 className="text-[16px] font-semibold">{s.title}</h2>
                <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
                  {s.description}
                </p>
                <p className="mt-3 text-[14px] font-medium text-wine">{s.price}</p>
              </article>
            ))
          )}
        </div>

        <div className="mt-8 flex flex-col gap-2">
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ink block w-full py-3 text-center text-[14px]"
          >
            Chiedi info su WhatsApp
          </a>
          <Link to="/prenota" className="chip block w-full py-3 text-center">
            Prenota un tavolo
          </Link>
        </div>
      </main>
    </div>
  );
}
