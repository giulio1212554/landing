import { createFileRoute, Link } from "@tanstack/react-router";
import { HomeHeader } from "@/components/home/HomeHeader";
import { ScrollIntro, BRAND_NAME } from "@/components/home/ScrollIntro";
import { DishesShowcase } from "@/components/home/DishesShowcase";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { QrTicket } from "@/components/QrTicket";
import {
  ALL_SLOTS,
  LUNCH_SLOTS,
  type ReservationTicket,
  describeParty,
  formatDateIt,
  toISODate,
} from "@/lib/booking";
import {
  createReservation,
  getAvailability,
  getTicket,
  guestCancelReservation,
  guestUpdateReservation,
} from "@/lib/booking.functions";
import { MENU_NOTE, MENU_SECTIONS } from "@/data/menu";

const WHATSAPP_NUMBER = "39081989062"; // 081 989062 senza zero iniziale dopo 39
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nonna Sofia — Ristorante a Ischia" },
      {
        name: "description",
        content:
          "Prenotazioni online immediate al Nonna Sofia: disponibilità in tempo reale, tavolo assegnato automaticamente e ticket QR per l'accoglienza in sala.",
      },
      { property: "og:title", content: "Nonna Sofia — Ristorante a Ischia" },
      {
        property: "og:description",
        content:
          "Disponibilità in tempo reale, assegnazione automatica dei tavoli e ticket QR da mostrare all'arrivo.",
      },
    ],
  }),
  component: HomePage,
});


function HomePage() {
  const today = toISODate(new Date());
  const [date, setDate] = useState(today);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [showParty, setShowParty] = useState(false);
  const [slot, setSlot] = useState<string | null>(null);
  const [guestName, setGuestName] = useState("");
  const [phone, setPhone] = useState("");
  const [ticket, setTicket] = useState<ReservationTicket | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Gestione prenotazione cliente
  const [manageCode, setManageCode] = useState("");
  const [manageName, setManageName] = useState("");
  const [manageTicket, setManageTicket] = useState<ReservationTicket | null>(null);
  const [manageError, setManageError] = useState<string | null>(null);
  const [manageMsg, setManageMsg] = useState<string | null>(null);
  const [manageEdit, setManageEdit] = useState(false);
  const [mDate, setMDate] = useState(today);
  const [mTime, setMTime] = useState(LUNCH_SLOTS[2] ?? "12:00");
  const [mAdults, setMAdults] = useState(2);
  const [mChildren, setMChildren] = useState(0);

  const availability = useQuery({
    queryKey: ["availability", date, adults, children],
    queryFn: () => getAvailability({ data: { date, adults, children } }),
  });

  const booking = useMutation({
    mutationFn: () =>
      createReservation({
        data: { date, time: slot!, adults, children, guestName, phone },
      }),
    onSuccess: (result) => {
      setTicket(result);
      setError(null);
      availability.refetch();
    },
    onError: (err: Error) => setError(err.message),
  });

  const lookupTicket = useMutation({
    mutationFn: () => getTicket({ data: { code: manageCode } }),
    onSuccess: (result) => {
      if (!result) {
        setManageTicket(null);
        setManageError("Nessuna prenotazione con questo codice");
        return;
      }
      setManageTicket(result);
      setManageError(null);
      setManageMsg(null);
      setMDate(result.resDate);
      setMTime(result.resTime);
      setMAdults(result.adults);
      setMChildren(result.children);
      setManageEdit(false);
    },
    onError: (err: Error) => setManageError(err.message),
  });

  const cancelGuest = useMutation({
    mutationFn: () =>
      guestCancelReservation({
        data: { code: manageCode, guestName: manageName },
      }),
    onSuccess: () => {
      setManageMsg("Prenotazione annullata");
      setManageTicket(null);
      setManageEdit(false);
    },
    onError: (err: Error) => setManageError(err.message),
  });

  const updateGuest = useMutation({
    mutationFn: () =>
      guestUpdateReservation({
        data: {
          code: manageCode,
          guestName: manageName,
          date: mDate,
          time: mTime,
          adults: mAdults,
          children: mChildren,
        },
      }),
    onSuccess: (result) => {
      setManageTicket(result);
      setManageMsg("Prenotazione aggiornata");
      setManageEdit(false);
      setManageError(null);
    },
    onError: (err: Error) => setManageError(err.message),
  });

  const slots = availability.data?.slots ?? [];
  const slotState = (time: string) => slots.find((s) => s.time === time);
  const canSubmit = Boolean(slot) && guestName.trim().length >= 2 && phone.trim().length >= 6;

  const renderSlots = (list: readonly string[], title: string) => (
    <>
      <p className="mt-5 text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">
        {title}
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {list.map((time) => {
          const state = slotState(time);
          const pending = availability.isPending;
          return (
            <button
              key={time}
              type="button"
              disabled={pending || !state?.available}
              onClick={() => setSlot(time)}
              className={`chip ${pending ? "chip-pending" : ""} ${slot === time ? "chip-active" : ""}`}
            >
              {time}
            </button>
          );
        })}
      </div>
    </>
  );

  return (
    <div className="theme-noir min-h-screen pb-12">
      <HomeHeader />
      <ScrollIntro />
      <DishesShowcase />

      <div id="prenota" className="mx-auto max-w-2xl scroll-mt-20 pt-20">
        <div className="mb-8 px-4 text-center">
          <p className="noir-eyebrow">Prenotazione</p>
          <h2 className="noir-title mt-3 text-4xl md:text-5xl">Il tuo tavolo</h2>
          <div className="gold-rule mx-auto mt-5" />
        </div>

      <section className="bento mx-4 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Prenotazione
        </p>
        <h2 className="mt-1 text-[22px] leading-tight font-semibold text-balance">
          Cerca disponibilità
        </h2>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <label className="block">
            <span className="text-[11px] font-medium text-muted-foreground">Data</span>
            <div className="field mt-1 flex items-center justify-between px-3 py-2.5">
              <input
                type="date"
                value={date}
                min={today}
                onChange={(event) => {
                  setDate(event.target.value || today);
                  setSlot(null);
                }}
                className="w-full bg-transparent text-[14px] font-medium outline-none"
              />
            </div>
          </label>

          <div className="block">
            <span className="text-[11px] font-medium text-muted-foreground">Persone</span>
            <button
              type="button"
              onClick={() => setShowParty((open) => !open)}
              className="field mt-1 flex w-full items-center justify-between px-3 py-2.5 text-left"
            >
              <span className="truncate text-[14px] font-medium">
                {adults} · {children} bimbi
              </span>
              <span className="text-[10px] tracking-wider text-muted-foreground uppercase">
                ▾
              </span>
            </button>
          </div>
        </div>

        {showParty ? (
          <div className="rise mt-3 grid grid-cols-2 gap-3">
            <Stepper
              label="Adulti"
              value={adults}
              min={1}
              max={20}
              onChange={(value) => {
                setAdults(value);
                setSlot(null);
              }}
            />
            <Stepper
              label="Bambini"
              value={children}
              min={0}
              max={10}
              onChange={(value) => {
                setChildren(value);
                setSlot(null);
              }}
            />
          </div>
        ) : null}

        {renderSlots(LUNCH_SLOTS, "Orari pranzo · 11:00 – 15:00")}

        <div className="mt-5 grid gap-3">
          <label className="field flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Nome
            </span>
            <input
              value={guestName}
              onChange={(event) => setGuestName(event.target.value)}
              maxLength={80}
              placeholder="Mario Esposito"
              className="bg-transparent text-[14px] font-medium outline-none placeholder:text-muted-foreground/60"
            />
          </label>
          <label className="field flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Telefono
            </span>
            <input
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              maxLength={30}
              inputMode="tel"
              placeholder="333 000 0000"
              className="bg-transparent text-[14px] font-medium outline-none placeholder:text-muted-foreground/60"
            />
          </label>
        </div>

        {error ? (
          <p className="mt-3 text-[12px] font-medium text-destructive">{error}</p>
        ) : null}

        <button
          type="button"
          disabled={!canSubmit || booking.isPending}
          onClick={() => booking.mutate()}
          className="btn-ink mt-5 w-full py-3 text-[14px]"
        >
          {booking.isPending
            ? "Confermo…"
            : slot
              ? `Conferma ${slot}`
              : "Scegli un orario"}
        </button>
      </section>

      {/* Contatto & Mappe */}
      <section className="bento mx-4 mt-6 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Contatti & Come arrivare
        </p>
        <h2 className="mt-1 text-[22px] leading-tight font-semibold">
          Nonna Sofia
        </h2>
        <div className="mt-4 space-y-3 text-[13px]">
          <p className="flex items-start gap-2">
            <span className="text-wine">📍</span>
            <span>
              Nonna Sofia, 80077 Ischia (NA), Italia
            </span>
          </p>
          <p className="flex items-center gap-2">
            <span className="text-wine">📞</span>
            <a href="tel:+39081989062" className="font-medium underline decoration-border underline-offset-4">
              081 989062
            </a>
          </p>
          <p className="flex items-center gap-2">
            <span className="text-wine">💬</span>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium underline decoration-border underline-offset-4"
            >
              WhatsApp · scrivici
            </a>
          </p>
          <p className="flex items-center gap-2">
            <span className="text-wine">🕐</span>
            <span>Aperto a pranzo · 11:00 – 15:00</span>
          </p>
        </div>
        <div className="mt-4 overflow-hidden rounded-xl shadow-[0_0_0_1px_var(--color-border)]">
          <iframe
            title="Mappa Nonna Sofia"
            src="https://maps.google.com/maps?q=Piano+Liguori,+80077+Ischia+(NA),+Italia&t=&z=15&ie=UTF8&iwloc=&output=embed"
            width="100%"
            height="220"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
        <a
          href="https://www.google.com/maps/search/?api=1&query=Piano+Liguori,+80077+Ischia+(NA),+Italia"
          target="_blank"
          rel="noopener noreferrer"
          className="btn-ink mt-4 block w-full py-2.5 text-center text-[13px]"
        >
          Apri in Google Maps
        </a>
      </section>

      {/* Menu — contenuti da src/data/menu.ts */}
      <section className="bento mx-4 mt-6 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          La carta
        </p>
        <h2 className="mt-1 text-[22px] leading-tight font-semibold">Menu</h2>
        <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">{MENU_NOTE}</p>
        <div className="mt-4 space-y-5">
          {MENU_SECTIONS.map((section) => (
            <div key={section.title}>
              <p className="text-[11px] font-semibold tracking-[0.14em] text-wine uppercase">
                {section.title}
              </p>
              <ul className="mt-2 divide-y divide-border">
                {section.items.map((item) => (
                  <li
                    key={item.name}
                    className="flex items-start justify-between gap-3 py-2.5"
                  >
                    <div className="min-w-0">
                      <p className="text-[13px] font-medium">{item.name}</p>
                      {item.desc ? (
                        <p className="mt-0.5 text-[11px] text-muted-foreground">{item.desc}</p>
                      ) : null}
                    </div>
                    <span className="shrink-0 text-[13px] font-medium tabular-nums">
                      {item.price}
                      {/\d/.test(item.price) && !item.price.includes("€") ? " €" : ""}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Gestione prenotazione cliente */}
      <section className="bento mx-4 mt-6 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Hai già prenotato?
        </p>
        <h2 className="mt-1 text-[22px] leading-tight font-semibold">
          Gestisci la prenotazione
        </h2>
        <p className="mt-2 text-[12px] text-muted-foreground">
          Inserisci il codice del ticket e nome e cognome usati in prenotazione.
        </p>
        <div className="mt-3 grid gap-2">
          <label className="field flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Codice
            </span>
            <input
              value={manageCode}
              onChange={(e) => setManageCode(e.target.value.toUpperCase().slice(0, 12))}
              placeholder="PL-7Q4X"
              className="bg-transparent text-[14px] font-medium outline-none"
            />
          </label>
          <label className="field flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Telefono
            </span>
            <input
              value={manageName}
              onChange={(e) => setManageName(e.target.value)}
              placeholder="333 000 0000"
              inputMode="tel"
              className="bg-transparent text-[14px] font-medium outline-none"
            />
          </label>
          <button
            type="button"
            disabled={manageCode.trim().length < 4 || lookupTicket.isPending}
            onClick={() => lookupTicket.mutate()}
            className="btn-ink w-full py-2.5 text-[13px]"
          >
            {lookupTicket.isPending ? "Cerco…" : "Cerca prenotazione"}
          </button>
        </div>
        {manageError ? (
          <p className="mt-3 text-[12px] font-medium text-destructive">{manageError}</p>
        ) : null}
        {manageMsg ? (
          <p className="mt-3 text-[12px] font-medium text-mint">{manageMsg}</p>
        ) : null}
        {manageTicket ? (
          <div className="rise mt-4 rounded-xl bg-card p-3 shadow-[0_0_0_1px_var(--color-border)]">
            {!manageEdit ? (
              <>
                <p className="text-[13px] font-medium">
                  {manageTicket.guestName} · {manageTicket.tableLabels.join(" + ")}
                </p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">
                  {formatDateIt(manageTicket.resDate)} · {manageTicket.resTime} ·{" "}
                  {describeParty(manageTicket.adults, manageTicket.children)}
                </p>
                <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">
                  {manageTicket.code} · {manageTicket.status}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setManageEdit(true)}
                    className="chip flex-1 text-center"
                  >
                    Modifica
                  </button>
                  <button
                    type="button"
                    disabled={cancelGuest.isPending || manageName.trim().length < 2}
                    onClick={() => {
                      if (confirm("Annullare la prenotazione?")) cancelGuest.mutate();
                    }}
                    className="chip flex-1 text-center text-destructive"
                  >
                    {cancelGuest.isPending ? "Annullando…" : "Annulla"}
                  </button>
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <p className="text-[12px] font-medium text-wine">Modifica {manageTicket.code}</p>
                <label className="field flex flex-col px-3 py-2">
                  <span className="text-[10px] text-muted-foreground uppercase">Data</span>
                  <input
                    type="date"
                    min={today}
                    value={mDate}
                    onChange={(e) => setMDate(e.target.value || today)}
                    className="bg-transparent text-[13px] outline-none"
                  />
                </label>
                <label className="field flex flex-col px-3 py-2">
                  <span className="text-[10px] text-muted-foreground uppercase">Orario</span>
                  <select
                    value={mTime}
                    onChange={(e) => setMTime(e.target.value)}
                    className="bg-transparent text-[13px] outline-none"
                  >
                    {ALL_SLOTS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <label className="field flex flex-col px-3 py-2">
                    <span className="text-[10px] text-muted-foreground uppercase">Adulti</span>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={mAdults}
                      onChange={(e) => setMAdults(Number(e.target.value) || 1)}
                      className="bg-transparent text-[13px] outline-none"
                    />
                  </label>
                  <label className="field flex flex-col px-3 py-2">
                    <span className="text-[10px] text-muted-foreground uppercase">Bambini</span>
                    <input
                      type="number"
                      min={0}
                      max={10}
                      value={mChildren}
                      onChange={(e) => setMChildren(Number(e.target.value) || 0)}
                      className="bg-transparent text-[13px] outline-none"
                    />
                  </label>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    disabled={updateGuest.isPending || manageName.trim().length < 2}
                    onClick={() => updateGuest.mutate()}
                    className="btn-ink flex-1 py-2 text-[12px]"
                  >
                    {updateGuest.isPending ? "Salvo…" : "Salva"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setManageEdit(false)}
                    className="chip flex-1 text-center"
                  >
                    Chiudi
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </section>

      {/* Recensioni */}
      <section className="bento mx-4 mt-6 p-5">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Cosa dicono i clienti
        </p>
        <h2 className="mt-1 text-[22px] leading-tight font-semibold">
          Recensioni
        </h2>
        <div className="mt-4 space-y-4">
          <article className="rounded-xl bg-card p-4 shadow-[0_0_0_1px_var(--color-border)]">
            <p className="text-[14px] leading-none">⭐️⭐️⭐️⭐️⭐️</p>
            <p className="mt-1 text-[13px] font-medium">
              Un panorama da mozzafiato e cibo genuino
            </p>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
              Raggiungere Nonna Sofia richiede un minimo di sforzo, ma la vista ripaga di tutto! Abbiamo pranzato sulla terrazza panoramica con una vista spettacolare sul mare e su Capri. Piatti della tradizione ischitana ottimi e ingredienti freschissimi. Un&apos;esperienza autentica lontano dal caos turistico.
            </p>
            <p className="mt-2 text-[11px] font-medium text-foreground/70">— Marco T.</p>
          </article>
          <article className="rounded-xl bg-card p-4 shadow-[0_0_0_1px_var(--color-border)]">
            <p className="text-[14px] leading-none">⭐️⭐️⭐️⭐️⭐️</p>
            <p className="mt-1 text-[13px] font-medium">
              Il vero coniglio all&apos;ischitana
            </p>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
              Siamo stati qui su consiglio del posto per provare il famoso coniglio all&apos;ischitana e devo dire che ha superato le aspettative. Carne tenera e saporita, bucatini al sugo fantastici. Personale accogliente, gentile e ambiente molto familiare. Da non perdere!
            </p>
            <p className="mt-2 text-[11px] font-medium text-foreground/70">— Elena R.</p>
          </article>
          <article className="rounded-xl bg-card p-4 shadow-[0_0_0_1px_var(--color-border)]">
            <p className="text-[14px] leading-none">⭐️⭐️⭐️⭐️☆</p>
            <p className="mt-1 text-[13px] font-medium">
              Location incantevole e atmosfera rilassante
            </p>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
              Posto magico, immerso nella natura. Si respira un&apos;aria di pace e la cucina rispecchia la tradizione della terra. Ottimi anche gli antipasti della casa. Unica nota: conviene prenotare prima per assicurarsi i tavoli con la vista migliore!
            </p>
            <p className="mt-2 text-[11px] font-medium text-foreground/70">— Roberto S.</p>
          </article>
        </div>
      </section>

      {ticket ? (
        <section className="bento rise mx-4 mt-6 p-5">
          <p className="text-[10px] font-semibold tracking-[0.2em] text-mint uppercase">
            Confermato
          </p>
          <h2 className="mt-1 text-[22px] leading-tight font-semibold text-balance">
            Il tuo tavolo
          </h2>
          <div className="mt-4 grid grid-cols-5 gap-4">
            <div className="col-span-2">
              <QrTicket
                value={`${typeof window === "undefined" ? "" : window.location.origin}/staff?code=${ticket.code}`}
                label={ticket.code}
              />
            </div>
            <div className="col-span-3 flex flex-col justify-between">
              <div>
                <p className="text-[13px] font-medium">
                  {ticket.tableLabels.join(" + ")} · {ticket.zone}
                </p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">
                  {describeParty(ticket.adults, ticket.children)}
                </p>
              </div>
              <div className="mt-2 space-y-1 text-[12px] text-foreground/70">
                <p>
                  {formatDateIt(ticket.resDate)} · {ticket.resTime}
                </p>
                <p>{ticket.guestName}</p>
              </div>
              <div className="mt-2 flex items-center justify-between rounded-lg bg-mint/10 px-3 py-2 shadow-[0_0_0_1px_color-mix(in_oklab,var(--mint)_22%,transparent)]">
                <span className="text-[11px] font-medium text-mint">
                  {ticket.status === "seated" ? "In sala" : "In attesa"}
                </span>
                <span className="font-mono text-[10px] text-mint">{ticket.code}</span>
              </div>
            </div>
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">
            Prenotazione confermata. Mostra questo QR all&apos;arrivo: lo staff
            conferma il tuo ingresso in pochi secondi. Conserva il codice{" "}
            <span className="font-mono font-medium text-foreground">{ticket.code}</span>.
          </p>
          <div className="mt-3 grid gap-2">
            <a
              href={`${WHATSAPP_LINK}?text=${encodeURIComponent(
                `Ciao! Ho prenotato al Nonna Sofia.\nCodice: ${ticket.code}\n${formatDateIt(ticket.resDate)} alle ${ticket.resTime}\n${ticket.guestName} · ${describeParty(ticket.adults, ticket.children)}`,
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ink block w-full py-2.5 text-center text-[13px]"
            >
              Invia conferma su WhatsApp
            </a>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="chip block w-full py-2.5 text-center"
            >
              Scrivi al ristorante
            </a>
          </div>
        </section>
      ) : null}

      </div>

      <footer className="mx-auto mt-24 max-w-2xl px-4 text-center">
        <div className="gold-rule mx-auto" />
        <p className="noir-title mt-6 text-2xl">{BRAND_NAME}</p>
        <p className="noir-eyebrow mt-2">Nonna Sofia · Ischia</p>
        <p className="mt-4 text-[12px] font-light text-muted-foreground">
          081 989062 · Aperto a pranzo 11:00 – 15:00
        </p>
      </footer>

      {/* WhatsApp fisso in basso */}
      <a
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 right-5 z-40 flex size-14 items-center justify-center rounded-full bg-[#25D366] text-[22px] text-white shadow-lg"
        aria-label="WhatsApp"
      >
        💬
      </a>
    </div>
  );
}

function Stepper({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
}) {
  return (
    <div className="field px-3 py-2">
      <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
        {label}
      </span>
      <div className="mt-1 flex items-center justify-between">
        <button
          type="button"
          aria-label={`Meno ${label}`}
          disabled={value <= min}
          onClick={() => onChange(value - 1)}
          className="grid size-7 place-items-center rounded-lg text-[14px] shadow-[0_0_0_1px_var(--color-border)] disabled:opacity-40"
        >
          −
        </button>
        <span className="text-[14px] font-medium">{value}</span>
        <button
          type="button"
          aria-label={`Più ${label}`}
          disabled={value >= max}
          onClick={() => onChange(value + 1)}
          className="grid size-7 place-items-center rounded-lg bg-wine/10 text-[14px] text-wine shadow-[0_0_0_1px_color-mix(in_oklab,var(--wine)_35%,transparent)] disabled:opacity-40"
        >
          +
        </button>
      </div>
    </div>
  );
}
