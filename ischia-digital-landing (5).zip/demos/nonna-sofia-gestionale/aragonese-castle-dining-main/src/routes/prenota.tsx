import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { SiteHeader } from "@/components/SiteHeader";
import { QrTicket } from "@/components/QrTicket";
import {
  LUNCH_SLOTS,
  type ReservationTicket,
  describeParty,
  formatDateIt,
  toISODate,
} from "@/lib/booking";
import { createReservation, getAvailability } from "@/lib/booking.functions";

const WHATSAPP_LINK = "https://wa.me/39081989062";

export const Route = createFileRoute("/prenota")({
  head: () => ({
    meta: [
      { title: "Prenota — Nonna Sofia" },
      {
        name: "description",
        content: "Prenota online al Nonna Sofia: disponibilità in tempo reale e ticket QR.",
      },
    ],
  }),
  component: PrenotaPage,
});

function PrenotaPage() {
  const today = toISODate(new Date());
  const [date, setDate] = useState(today);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [showParty, setShowParty] = useState(false);
  const [slot, setSlot] = useState<string | null>(null);
  const [guestName, setGuestName] = useState("");
  const [phone, setPhone] = useState("");
  const [ticket, setTicket] = useState<ReservationTicket | null>(null);
  const [error, setError] = useState<string | null>(null);

  const availability = useQuery({
    queryKey: ["availability", date, adults, children],
    queryFn: () => getAvailability({ data: { date, adults, children } }),
  });

  const booking = useMutation({
    mutationFn: () =>
      createReservation({
        data: { date, time: slot!, adults, children, guestName, phone },
      }),
    onSuccess: (result) => {
      setTicket(result);
      setError(null);
      availability.refetch();
    },
    onError: (err: Error) => setError(err.message),
  });

  const slots = availability.data?.slots ?? [];
  const slotState = (time: string) => slots.find((s) => s.time === time);
  const canSubmit =
    Boolean(slot) && guestName.trim().length >= 2 && phone.trim().length >= 6;

  if (ticket) {
    return (
      <div className="min-h-screen pb-16">
        <SiteHeader active="prenota" />
        <main className="mx-auto max-w-lg px-4 py-6">
          <section className="bento rise p-5">
            <p className="text-[10px] font-semibold tracking-[0.2em] text-mint uppercase">
              Confermato
            </p>
            <h1 className="mt-1 text-[22px] font-semibold">Il tuo tavolo</h1>
            <div className="mt-4 grid grid-cols-5 gap-4">
              <div className="col-span-2">
                <QrTicket
                  value={`${typeof window === "undefined" ? "" : window.location.origin}/staff?code=${ticket.code}`}
                  label={ticket.code}
                />
              </div>
              <div className="col-span-3 space-y-1 text-[13px]">
                <p className="font-medium">
                  {ticket.tableLabels.join(" + ")} · {ticket.zone}
                </p>
                <p className="text-muted-foreground">
                  {describeParty(ticket.adults, ticket.children)}
                </p>
                <p>
                  {formatDateIt(ticket.resDate)} · {ticket.resTime}
                </p>
                <p>{ticket.guestName}</p>
                <p className="font-mono text-[11px] text-mint">{ticket.code}</p>
              </div>
            </div>
            <a
              href={`${WHATSAPP_LINK}?text=${encodeURIComponent(
                `Ciao! Ho prenotato al Nonna Sofia.\nCodice: ${ticket.code}\n${formatDateIt(ticket.resDate)} alle ${ticket.resTime}\n${ticket.guestName}`,
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ink mt-4 block w-full py-3 text-center text-[13px]"
            >
              Invia conferma su WhatsApp
            </a>
            <button
              type="button"
              className="chip mt-2 w-full py-2.5"
              onClick={() => setTicket(null)}
            >
              Nuova prenotazione
            </button>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-16">
      <SiteHeader active="prenota" />
      <main className="mx-auto max-w-lg px-4 py-6">
        <p className="text-[10px] font-semibold tracking-[0.2em] text-wine uppercase">
          Prenotazione
        </p>
        <h1 className="mt-1 text-[28px] font-semibold leading-tight">
          Prenota il tavolo
        </h1>
        <p className="mt-2 text-[13px] text-muted-foreground">
          Pranzo 11:00 – 15:00 · risposta immediata con ticket QR
        </p>

        <section className="bento mt-6 p-5">
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-[11px] font-medium text-muted-foreground">Data</span>
              <div className="field mt-1 px-3 py-2.5">
                <input
                  type="date"
                  value={date}
                  min={today}
                  onChange={(e) => {
                    setDate(e.target.value || today);
                    setSlot(null);
                  }}
                  className="w-full bg-transparent text-[14px] font-medium outline-none"
                />
              </div>
            </label>
            <div>
              <span className="text-[11px] font-medium text-muted-foreground">Persone</span>
              <button
                type="button"
                onClick={() => setShowParty((o) => !o)}
                className="field mt-1 flex w-full items-center justify-between px-3 py-2.5 text-left text-[14px] font-medium"
              >
                {adults} · {children} bimbi
                <span className="text-[10px] text-muted-foreground">▾</span>
              </button>
            </div>
          </div>

          {showParty ? (
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Stepper label="Adulti" value={adults} min={1} max={20} onChange={(v) => { setAdults(v); setSlot(null); }} />
              <Stepper label="Bambini" value={children} min={0} max={10} onChange={(v) => { setChildren(v); setSlot(null); }} />
            </div>
          ) : null}

          <p className="mt-5 text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">
            Orari pranzo · 11:00 – 15:00
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {LUNCH_SLOTS.map((time) => {
              const state = slotState(time);
              const pending = availability.isPending;
              return (
                <button
                  key={time}
                  type="button"
                  disabled={pending || !state?.available}
                  onClick={() => setSlot(time)}
                  className={`chip ${pending ? "chip-pending" : ""} ${slot === time ? "chip-active" : ""}`}
                >
                  {time}
                </button>
              );
            })}
          </div>

          <label className="field mt-4 flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Nome
            </span>
            <input
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Mario Esposito"
              className="bg-transparent text-[14px] font-medium outline-none"
            />
          </label>
          <label className="field mt-2 flex flex-col px-3 py-2.5">
            <span className="text-[10px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Telefono
            </span>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="333 000 0000"
              inputMode="tel"
              className="bg-transparent text-[14px] font-medium outline-none"
            />
          </label>

          {error ? (
            <p className="mt-3 text-[12px] font-medium text-destructive">{error}</p>
          ) : null}

          <button
            type="button"
            disabled={!canSubmit || booking.isPending}
            onClick={() => booking.mutate()}
            className="btn-ink mt-4 w-full py-3 text-[14px] disabled:opacity-40"
          >
            {booking.isPending ? "Prenoto…" : slot ? `Prenota alle ${slot}` : "Scegli un orario"}
          </button>
        </section>

        <p className="mt-4 text-center text-[12px] text-muted-foreground">
          Hai già un codice?{" "}
          <Link to="/" className="font-medium text-wine underline">
            Gestisci dalla home
          </Link>
        </p>
      </main>
    </div>
  );
}

function Stepper({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="field flex items-center justify-between px-3 py-2">
      <span className="text-[12px] font-medium">{label}</span>
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="size-7 rounded-full bg-card text-sm shadow-[0_0_0_1px_var(--color-border)]"
          onClick={() => onChange(Math.max(min, value - 1))}
        >
          −
        </button>
        <span className="w-5 text-center text-[14px] font-medium">{value}</span>
        <button
          type="button"
          className="size-7 rounded-full bg-card text-sm shadow-[0_0_0_1px_var(--color-border)]"
          onClick={() => onChange(Math.min(max, value + 1))}
        >
          +
        </button>
      </div>
    </div>
  );
}
