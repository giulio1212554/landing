import { useEffect, useRef, useState } from "react";

export type Slide = {
  src: string;
  alt: string;
  caption: string;
};

export function HeroCarousel({ slides }: { slides: Slide[] }) {
  const [index, setIndex] = useState(0);
  const startX = useRef<number | null>(null);

  const go = (next: number) => {
    setIndex(((next % slides.length) + slides.length) % slides.length);
  };

  // Auto-play ogni 4 secondi
  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setIndex((current) => (current + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div
      className="relative aspect-4/5 w-full overflow-hidden rounded-2xl bg-glass shadow-[0_0_0_1px_var(--color-border)]"
      onTouchStart={(event) => {
        startX.current = event.touches[0]?.clientX ?? null;
      }}
      onTouchEnd={(event) => {
        const from = startX.current;
        const to = event.changedTouches[0]?.clientX ?? null;
        if (from === null || to === null) return;
        if (Math.abs(to - from) > 42) go(index + (to < from ? 1 : -1));
        startX.current = null;
      }}
    >
      {slides.map((slide, i) => (
        <img
          key={slide.src}
          src={slide.src}
          alt={slide.alt}
          loading={i === 0 ? "eager" : "lazy"}
          className="carousel-slide absolute inset-0 h-full w-full object-cover"
          style={{
            opacity: i === index ? 1 : 0,
            transform: i === index ? "scale(1)" : "scale(1.04)",
          }}
        />
      ))}

      <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-linear-to-b from-black/55 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-48 bg-linear-to-t from-black/75 via-black/20 to-transparent" />

      <div className="absolute top-4 right-4 flex gap-1.5">
        {slides.map((slide, i) => (
          <button
            key={slide.src}
            type="button"
            aria-label={`Foto ${i + 1}`}
            onClick={() => go(i)}
            className="size-2 rounded-full transition-colors"
            style={{
              backgroundColor:
                i === index ? "rgb(255 255 255 / 0.9)" : "rgb(255 255 255 / 0.4)",
            }}
          />
        ))}
      </div>

      <button
        type="button"
        aria-label="Foto precedente"
        onClick={() => go(index - 1)}
        className="absolute top-1/2 left-2 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-black/40 text-lg text-white backdrop-blur-sm transition-colors hover:bg-black/60"
      >
        ‹
      </button>
      <button
        type="button"
        aria-label="Foto successiva"
        onClick={() => go(index + 1)}
        className="absolute top-1/2 right-2 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-black/40 text-lg text-white backdrop-blur-sm transition-colors hover:bg-black/60"
      >
        ›
      </button>

      <div className="absolute inset-x-0 bottom-0 p-5">
        <p className="text-[10px] font-medium tracking-[0.22em] text-white/60 uppercase">
          {slides[index]?.caption}
        </p>
        <h1 className="mt-2 font-display text-[42px] leading-[0.95] font-medium text-balance text-white">
          Piano
          <br />
          Liguori
        </h1>
        <p className="mt-3 max-w-[38ch] text-[13px] leading-relaxed text-pretty text-white/70">
          Cucina del territorio, cantina selezionata. Prenota il tuo tavolo in pochi
          secondi.
        </p>
      </div>
    </div>
  );
}
