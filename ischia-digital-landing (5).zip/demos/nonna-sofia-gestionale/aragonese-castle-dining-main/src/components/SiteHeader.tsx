import { Link } from "@tanstack/react-router";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/prenota", label: "Prenota" },
  { to: "/soluzioni", label: "Soluzioni" },
] as const;

export function SiteHeader({ active }: { active?: "home" | "menu" | "prenota" | "soluzioni" }) {
  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/90 backdrop-blur-md">
      <div className="flex items-center justify-between gap-2 px-4 py-3">
        <Link
          to="/"
          className="shrink-0 text-[14px] font-semibold tracking-[0.12em] uppercase"
        >
          Nonna Sofia
        </Link>
        <nav className="flex min-w-0 items-center gap-1 overflow-x-auto">
          {LINKS.map((l) => {
            const isActive =
              (active === "home" && l.to === "/") ||
              (active === "menu" && l.to === "/menu") ||
              (active === "prenota" && l.to === "/prenota") ||
              (active === "soluzioni" && l.to === "/soluzioni");
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`shrink-0 rounded-full px-2.5 py-1 text-[12px] font-medium transition-colors ${
                  isActive
                    ? "bg-wine/15 text-wine"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
          <Link
            to="/staff"
            search={{ code: undefined }}
            className="ml-1 shrink-0 text-[11px] font-medium text-muted-foreground underline decoration-border underline-offset-4"
          >
            Staff
          </Link>
        </nav>
      </div>
    </header>
  );
}
