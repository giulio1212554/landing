import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { BRAND_NAME } from "./ScrollIntro";

export function HomeHeader() {
  const [solid, setSolid] = useState(false);
  useEffect(() => {
    const on = () => setSolid(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <header className={`home-header fixed inset-x-0 top-0 z-40 ${solid ? "is-solid" : ""}`}>
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-4">
        <Link to="/" className="noir-title text-xl tracking-[0.08em] text-ivory">
          {BRAND_NAME}
        </Link>
        <nav className="flex items-center gap-4 text-[12px] font-light tracking-[0.14em] uppercase">
          <Link to="/menu" className="hidden text-ivory/80 hover:text-ivory sm:inline">
            Menu
          </Link>
          <Link to="/soluzioni" className="hidden text-ivory/80 hover:text-ivory sm:inline">
            Soluzioni
          </Link>
          <Link
            to="/staff"
            search={{ code: undefined }}
            className="hidden text-ivory/50 hover:text-ivory md:inline"
          >
            Staff
          </Link>
          <a href="#prenota" className="btn-gold">
            Prenota
          </a>
        </nav>
      </div>
    </header>
  );
}
