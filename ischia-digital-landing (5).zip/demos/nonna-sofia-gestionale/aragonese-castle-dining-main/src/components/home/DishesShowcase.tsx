import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { MENU_SECTIONS, type MenuItem } from "@/data/menu";

function featuredDishes(): MenuItem[] {
  return MENU_SECTIONS.flatMap((s) => s.items)
    .filter((i) => i.featured)
    .slice(0, 5);
}

const formatPrice = (p: string) => (/\d/.test(p) && !p.includes("€") ? `${p} €` : p);

function Dish({ item, index }: { item: MenuItem; index: number }) {
  const ref = useRef<HTMLElement>(null);
  const imgRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const reverse = index % 2 === 1;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => e?.isIntersecting && setVisible(true),
      { threshold: 0.2 },
    );
    io.observe(el);

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        if (!imgRef.current || reduced) return;
        const r = el.getBoundingClientRect();
        const p = (r.top + r.height / 2 - window.innerHeight / 2) / window.innerHeight;
        imgRef.current.style.transform = `translateY(${p * -40}px) scale(1.08)`;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <article
      ref={ref}
      className={`mx-auto flex min-h-[90vh] max-w-6xl flex-col items-center gap-10 px-6 py-16 md:gap-20 ${
        reverse ? "md:flex-row-reverse" : "md:flex-row"
      } ${visible ? "reveal-in" : "reveal-out"}`}
    >
      <div className="order-2 flex-1 md:order-none">
        <p className="noir-eyebrow">{String(index + 1).padStart(2, "0")}</p>
        <h3 className="noir-title mt-4 text-4xl leading-tight md:text-6xl">{item.name}</h3>
        <div className="gold-rule mt-6" />
        {item.desc ? (
          <p className="dish-desc mt-6 max-w-md text-xl md:text-2xl">{item.desc}</p>
        ) : null}
        <p className="mt-6 text-sm tracking-[0.2em] text-gold">{formatPrice(item.price)}</p>
      </div>
      <div className="order-1 w-full flex-1 md:order-none">
        <div className="dish-frame aspect-[4/5] w-full overflow-hidden md:aspect-[4/5]">
          {item.img ? (
            <div ref={imgRef} className="h-full w-full will-change-transform">
              <img
                src={item.img}
                alt={item.name}
                loading="lazy"
                width={1024}
                height={1024}
                className="h-full w-full object-cover"
              />
            </div>
          ) : (
            <div className="dish-placeholder flex h-full w-full items-center justify-center">
              <span className="noir-eyebrow">Foto in arrivo</span>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

export function DishesShowcase() {
  const dishes = featuredDishes();
  return (
    <section id="piatti" className="relative bg-background pt-24">
      <div className="px-6 text-center">
        <p className="noir-eyebrow">La cucina</p>
        <h2 className="noir-title mt-3 text-5xl md:text-7xl">I nostri piatti</h2>
        <div className="gold-rule mx-auto mt-6" />
      </div>
      {dishes.map((d, i) => (
        <Dish key={d.name} item={d} index={i} />
      ))}
      <div className="flex justify-center pt-8 pb-12">
        <Link to="/menu" className="btn-gold-outline">
          Vedi il menu completo
        </Link>
      </div>
    </section>
  );
}
