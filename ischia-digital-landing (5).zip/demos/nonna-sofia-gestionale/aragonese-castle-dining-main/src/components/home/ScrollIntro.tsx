import { useEffect, useRef, useState } from "react";

export const BRAND_NAME = "Nonna Sofia";
const VIDEO_SRC = "/videos/drone-intro.mp4";
const POSTER_SRC = "/videos/drone-intro-poster.jpg";

/** Fraction of the 300vh scroll used to scrub the video; the rest fades out. */
const VIDEO_END = 0.72;

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));

export function ScrollIntro() {
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const veilRef = useRef<HTMLDivElement>(null);
  const [reduced, setReduced] = useState(false);
  const [showTitle, setShowTitle] = useState(false);
  const [videoFailed, setVideoFailed] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const on = () => setReduced(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);

  useEffect(() => {
    if (reduced) {
      setShowTitle(true);
      return;
    }
    const section = sectionRef.current;
    const video = videoRef.current;
    if (!section) return;

    let raf = 0;
    let current = 0;
    let titleOn = false;

    // iOS: unlock seeking with a muted play/pause on first touch.
    const unlock = () => {
      if (!video) return;
      video
        .play()
        .then(() => video.pause())
        .catch(() => {});
    };
    window.addEventListener("touchstart", unlock, { once: true, passive: true });

    const tick = () => {
      const rect = section.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      const progress = clamp(total > 0 ? -rect.top / total : 0);
      const videoP = clamp(progress / VIDEO_END);
      const exitP = clamp((progress - VIDEO_END - 0.08) / (1 - VIDEO_END - 0.08));

      if (video && video.duration && !Number.isNaN(video.duration)) {
        const target = videoP * (video.duration - 0.05);
        current += (target - current) * 0.12;
        if (Math.abs(target - current) < 0.002) current = target;
        if (Math.abs(video.currentTime - current) > 0.01 && !video.seeking) {
          video.currentTime = current;
        }
      }

      const wantTitle = videoP >= 0.995;
      if (wantTitle !== titleOn) {
        titleOn = wantTitle;
        setShowTitle(wantTitle);
      }

      if (stageRef.current) {
        stageRef.current.style.opacity = String(1 - exitP);
        stageRef.current.style.transform = `scale(${1 - exitP * 0.08})`;
      }
      if (veilRef.current) veilRef.current.style.opacity = String(0.25 + exitP * 0.75);

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("touchstart", unlock);
    };
  }, [reduced]);

  const skip = () => {
    document.getElementById("piatti")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      ref={sectionRef}
      className={`relative w-full bg-background ${reduced ? "h-screen" : "h-[300vh]"}`}
      aria-label="Intro"
    >
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        <div ref={stageRef} className="intro-stage absolute inset-0 will-change-transform">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${POSTER_SRC}), var(--gradient-noir)` }}
          />
          {!reduced && !videoFailed ? (
            <video
              ref={videoRef}
              className="absolute inset-0 h-full w-full object-cover object-center"
              src={VIDEO_SRC}
              poster={POSTER_SRC}
              muted
              playsInline
              preload="auto"
              onError={() => setVideoFailed(true)}
            />
          ) : null}
          <div ref={veilRef} className="intro-veil absolute inset-0" />
        </div>

        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
          {showTitle ? (
            <>
              <h1 className="gold-title gold-text text-6xl sm:text-7xl md:text-8xl lg:text-9xl">
                {BRAND_NAME}
              </h1>
              <p className="gold-sub mt-6 text-[11px] text-ivory sm:text-xs">
                Nonna Sofia · Ischia · Ristorante
              </p>
            </>
          ) : null}
        </div>

        <button type="button" onClick={skip} className="skip-intro absolute top-20 right-5 z-10">
          Salta intro
        </button>

        {showTitle ? (
          <button
            type="button"
            onClick={skip}
            aria-label="Scorri verso i piatti"
            className="scroll-cue absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <svg width="22" height="38" viewBox="0 0 22 38" fill="none" aria-hidden>
              <path d="M11 1v34M2 27l9 9 9-9" stroke="currentColor" strokeWidth="1" />
            </svg>
          </button>
        ) : null}
      </div>
    </section>
  );
}
