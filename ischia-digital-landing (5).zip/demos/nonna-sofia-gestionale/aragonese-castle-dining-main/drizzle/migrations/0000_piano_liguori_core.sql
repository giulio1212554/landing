-- Impostazioni locale (incluso PIN area staff)
CREATE TABLE public.app_settings (
  id integer PRIMARY KEY DEFAULT 1,
  admin_pin text NOT NULL DEFAULT '2468',
  slot_duration_minutes integer NOT NULL DEFAULT 120,
  lead_time_minutes integer NOT NULL DEFAULT 120,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT app_settings_singleton CHECK (id = 1)
);

GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

INSERT INTO public.app_settings (id) VALUES (1);

-- Tavoli della sala
CREATE TABLE public.restaurant_tables (
  id integer PRIMARY KEY,
  label text NOT NULL,
  capacity integer NOT NULL,
  zone text NOT NULL DEFAULT 'Sala',
  adj_group text NOT NULL DEFAULT 'A',
  span integer NOT NULL DEFAULT 1,
  sort_order integer NOT NULL DEFAULT 0
);

GRANT ALL ON public.restaurant_tables TO service_role;
ALTER TABLE public.restaurant_tables ENABLE ROW LEVEL SECURITY;

INSERT INTO public.restaurant_tables (id, label, capacity, zone, adj_group, span, sort_order) VALUES
  (1,  'Tavolo 01', 6, 'Sala',     'A', 2, 1),
  (2,  'T02', 2, 'Sala',     'A', 1, 2),
  (3,  'T03', 2, 'Sala',     'A', 1, 3),
  (4,  'T04', 4, 'Sala',     'A', 1, 4),
  (5,  'T05', 4, 'Sala',     'A', 1, 5),
  (6,  'T06', 2, 'Sala',     'B', 1, 6),
  (7,  'T07', 2, 'Sala',     'B', 1, 7),
  (8,  'T08', 4, 'Sala',     'B', 1, 8),
  (9,  'T09', 4, 'Sala',     'B', 1, 9),
  (10, 'T10', 6, 'Sala',     'B', 2, 10),
  (11, 'T11', 2, 'Terrazza', 'C', 1, 11),
  (12, 'T12', 2, 'Terrazza', 'C', 1, 12),
  (13, 'T13', 4, 'Terrazza', 'C', 1, 13),
  (14, 'T14', 4, 'Terrazza', 'C', 1, 14),
  (15, 'T15', 6, 'Terrazza', 'C', 2, 15),
  (16, 'T16', 8, 'Terrazza', 'C', 2, 16);

-- Prenotazioni
CREATE TABLE public.reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  guest_name text NOT NULL,
  phone text NOT NULL,
  email text,
  notes text,
  res_date date NOT NULL,
  res_time time NOT NULL,
  adults integer NOT NULL DEFAULT 2,
  children integer NOT NULL DEFAULT 0,
  table_ids integer[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX reservations_date_idx ON public.reservations (res_date, res_time);

GRANT ALL ON public.reservations TO service_role;
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;