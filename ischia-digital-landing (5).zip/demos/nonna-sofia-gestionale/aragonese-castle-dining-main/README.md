# Nonna Sofia — Gestionale Ristorante

Prenotazioni online + area staff completa (cucina, cassa, ordini, cruscotto dirigente).

## Avvio

```bash
npm install
npm run dev
```

Apri http://localhost:3000

## Area staff

- URL: `/staff`
- PIN: `1234`
- Account demo: `dirigente` / `dirigente123` (e analoghi per cuoco, cassiere, cameriere)

### Ruoli

| Ruolo      | Accesso                                      |
|------------|----------------------------------------------|
| dirigente  | Cruscotto P&L, menu, team, soluzioni, tutto  |
| cuoco      | Cucina                                       |
| cassiere   | Cassa                                        |
| cameriere  | Ordini tavoli                                |

Il **cruscotto** (incassi, costi stimati, profitto, grafico trading giornaliero, equity curve, piatti top) è visibile **solo al dirigente**.

## Cliente

- Tema **nero + oro**
- Prenota online → ticket QR + WhatsApp
- Gestisci prenotazione: **codice + nome e cognome**

## Staff

- Tema **Matrix / terminal tattico** (verde su nero)
- Gestionale completa: ordini, cucina, cassa, chat, menu live

## Menu

Modifica in runtime dall'area dirigente, oppure seed in `src/lib/local-db.ts` (`DEFAULT_MENU`).
File pubblico di fallback: `src/data/menu.ts`.

## Dati

Salvati in `data/db.json` (creato al primo avvio). Nessuna dipendenza da Supabase o Lovable.

## WhatsApp

Numero: **081 989062** (modifica `WHATSAPP_NUMBER` in `src/routes/index.tsx`).
