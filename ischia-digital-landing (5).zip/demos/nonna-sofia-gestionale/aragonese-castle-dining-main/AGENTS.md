# Note per gli agenti

Progetto standalone di prenotazioni per Nonna Sofia (Ischia).

- Frontend: TanStack Start + React + Tailwind
- Backend: server functions + Supabase
- Area pubblica: `/`
- Area staff: `/staff` (PIN protetto)

Non introdurre dipendenze da piattaforme di hosting proprietarie.
