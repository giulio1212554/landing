#!/bin/bash
# Ischia Digital — Avvio demo locali
# Porte: Wheels 5173 | Project Lab 5174 | Nonna Sofia 5175

set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEMOS="$ROOT/demos"

echo "=========================================="
echo "  Ischia Digital — Avvio demo"
echo "=========================================="

start_one() {
  local name="$1"
  local dir="$2"
  local port="$3"
  local extra="$4"

  echo ""
  echo "→ $name  (porta $port)"
  if [ ! -d "$dir" ]; then
    echo "  ERRORE: cartella non trovata: $dir"
    return 1
  fi
  cd "$dir"
  if [ ! -d node_modules ]; then
    echo "  npm install in corso..."
    npm install --silent 2>/dev/null || npm install
  fi
  if [ -n "$extra" ]; then
    eval "$extra"
  fi
  # Avvia in background
  PORT=$port npm run dev -- --port $port --host 127.0.0.1 > /tmp/id-demo-$port.log 2>&1 &
  echo $! > /tmp/id-demo-$port.pid
  echo "  PID $(cat /tmp/id-demo-$port.pid) — log: /tmp/id-demo-$port.log"
  cd "$ROOT"
}

# 1. Wheels & Waves
start_one "Ischia Rent — Wheels & Waves" \
  "$DEMOS/ischia-wheels-and-waves" \
  5173

# 2. Project Lab (nested)
start_one "Project Lab" \
  "$DEMOS/project-lab-streetwear/pianoliguori-main" \
  5174 \
  'if [ ! -f .env ]; then cp .env.example .env 2>/dev/null || true; fi'

# 3. Nonna Sofia
start_one "Nonna Sofia" \
  "$DEMOS/nonna-sofia-gestionale/aragonese-castle-dining-main" \
  5175

echo ""
echo "=========================================="
echo "  Demo in avvio. Attendi 10-20 secondi."
echo "  Wheels & Waves : http://127.0.0.1:5173"
echo "  Project Lab    : http://127.0.0.1:5174"
echo "  Nonna Sofia    : http://127.0.0.1:5175"
echo "=========================================="
echo ""
echo "Per fermare: ./stop-demos.sh"
